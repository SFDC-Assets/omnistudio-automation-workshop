/* eslint-disable require-jsdoc */
/* eslint-disable no-underscore-dangle */
'use strict';

function getCurrentBasket() {
    var BasketMgr = require('dw/order/BasketMgr');
    return BasketMgr.currentBasket;
}

function VlocityBasket(currentBasket) {
    var basket = currentBasket || getCurrentBasket();

    Object.defineProperties(this, {
        _basket: {
            writable: false,
            value: basket
        },
        _customer: {
            writable: false,
            value: basket.customer
        },
        cartContextKey: {
            enumerable: true,
            get: this.getContextKey
        }
    });
}

VlocityBasket.prototype.isConnected = function () {
    return !empty(this.cartContextKey);
};

VlocityBasket.prototype.disconnect = function () {
    var Transaction = require('dw/system/Transaction');
    var currentBasket = this._basket;
    Transaction.wrap(function () {
        currentBasket.custom.vlocity_cmt_cartContextKey = null;
    });
};

VlocityBasket.prototype.getContextKey = function () {
    return this._basket.custom.vlocity_cmt_cartContextKey;
};

VlocityBasket.prototype.setContextKey = function (contextKey) {
    var Transaction = require('dw/system/Transaction');
    var basket = this._basket;

    Transaction.wrap(function () {
        basket.custom.vlocity_cmt_cartContextKey = contextKey;
    });

    return this;
};

function getProductLineItemByUUID(basket, lineItemUUID) {
    for (var i = 0; i < basket.productLineItems.length; i++) {
        var pli = basket.productLineItems[i];

        if (pli.UUID === lineItemUUID) {
            return pli;
        }
    }

    return null;
}

VlocityBasket.getProductLineItemByUUID = getProductLineItemByUUID;

VlocityBasket.prototype.getProductLineItemByUUID = function (lineItemUUID) {
    return getProductLineItemByUUID(this._basket, lineItemUUID);
};

VlocityBasket.prototype.getLineItem = function (apiLineItemOrUUID) {
    var LineItem = require('./lineItem');

    var lineItem;

    if (typeof apiLineItemOrUUID === 'string') {
        lineItem = this.getProductLineItemByUUID(apiLineItemOrUUID);
    } else {
        lineItem = apiLineItemOrUUID;
    }

    return lineItem ? new LineItem(lineItem) : null;
};

VlocityBasket.prototype.updateFromBasketResponse = function (basketResponse) {
    var Transaction = require('dw/system/Transaction');

    var basket = this._basket;

    Transaction.wrap(function () {
        basket.custom.vlocity_cmt_custAuthenticated = basket.customer.authenticated;
        basket.custom.vlocity_cmt_cartContextKey = basketResponse.cartContextKey || null;
        basket.custom.vlocity_cmt_BasketResponse = JSON.stringify(basketResponse, null, 4);
    });
};

VlocityBasket.prototype.createLineItem = function (product, quantity) {
    var apiProductLineItem = this._basket.createProductLineItem(
        product,
        null,
        this._basket.defaultShipment
    );

    if (quantity) {
        apiProductLineItem.setQuantityValue(quantity);
    }

    var LineItem = require('./lineItem');
    return new LineItem(apiProductLineItem);
};

VlocityBasket.prototype.getCatalogCode = function () {
    if (!this._basket) {
        return null;
    }

    if (this._basket.productLineItems.length) {
        var productHelper = require('../../scripts/helpers/vlocity/productHelper');

        for (var i = 0; i < this._basket.productLineItems.length; i++) {
            var pli = this._basket.productLineItems[i];

            if (pli.product) {
                var catalogCode = productHelper.getCatalogCode(pli.product);
                if (catalogCode) {
                    return catalogCode;
                }
            }
        }
    }

    if ('vlocity_cmt_assetContext' in this._basket.custom && this._basket.custom.vlocity_cmt_assetContext) {
        try {
            var allAssetLines = JSON.parse(this._basket.custom.vlocity_cmt_assetContext);
            var primaryCatalogCode = allAssetLines[0].primaryCatalogCode;
            return primaryCatalogCode;
        } catch (e) {
            return null;
        }
    }

    return null;
};

module.exports = VlocityBasket;
