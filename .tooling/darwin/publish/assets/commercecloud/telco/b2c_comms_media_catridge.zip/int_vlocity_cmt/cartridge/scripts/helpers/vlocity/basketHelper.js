/* eslint-disable require-jsdoc */
/* eslint-disable no-underscore-dangle */
'use strict';

var DCAPI = require('int_vlocity_cmt').VlocityService.DCAPI;

/**
 * This method processes the vlocity basket lineItems
 * @param {JSON.object} vOffer - offer to process
 * @param {*} currentBasket - offer to process
 * @param {*} validatedHierarchyPath - list of processed offers
 * */
function processOffer(vOffer, currentBasket, validatedHierarchyPath) {
    var Site = require('dw/system/Site');
    var DCAPI_NAMESPACE = Site.current.getCustomPreferenceValue('vlocity_cmt_NamespaceForDCAPI');
    var Transaction = require('dw/system/Transaction');
    var Logger = require('dw/system/Logger');
    var LOGGER = Logger.getLogger('int_vlocity_cmt', 'helpers.vlocity.basketHelper');

    if (vOffer) {
        // recursive call to process vlocity basket child offers
        if (vOffer.childProducts && vOffer.childProducts.records && vOffer.childProducts.records.length !== 0) {
            for (var i = 0; i < vOffer.childProducts.records.length; i++) {
                processOffer(vOffer.childProducts.records[i], currentBasket, validatedHierarchyPath);
            }
        }

        // recursive call to process vlocity basket child lineItems
        if (vOffer.lineItems && vOffer.lineItems.records && vOffer.lineItems.records.length !== 0) {
            for (var y = 0; y < vOffer.lineItems.records.length; y++) {
                processOffer(vOffer.lineItems.records[y], currentBasket, validatedHierarchyPath);
            }
        }

        // process vlocity basket offer
        if (vOffer.ProductCode) {
            // Magic Happens
            for (var z = 0; z < currentBasket.productLineItems.getLength(); z++) {
                // TODO: need logic to process new offers returned as result of repricing and add them to the basket
                // vlocity_cmt_pricingStatus ==> unchanged, priceChange, quantityChange, newOffer
                if (vOffer.productHierarchyPath === currentBasket.productLineItems[z].custom.vlocity_cmt_productHierarchyPath) {
                    validatedHierarchyPath.push(vOffer.productHierarchyPath);
                    // TODO: Do we want multiple markers, most important marker, or combination marker for type of change
                    // Found the matching lineItem, compare price and quantity
                    var vQuantity = (vOffer.Quantity ? vOffer.Quantity.value : vOffer.quantity.value);
                    if (vQuantity !== currentBasket.productLineItems[z].custom.vlocity_cmt_quantity) {
                        // eslint-disable-next-line no-loop-func
                        Transaction.wrap(function () {
                            currentBasket.productLineItems[z].custom.vlocity_cmt_pricingStatus = 'quantityChange';
                        });
                        LOGGER.warn('Offer: {0} in your basket has a quantity change from: {1} to {2}',
                                    currentBasket.productLineItems[z].ID,
                                    currentBasket.productLineItems[z].custom.vlocity_cmt_quantity,
                                    vQuantity);
                    }
                    var vOneTimePrice = vOffer[DCAPI_NAMESPACE + '__OneTimeCalculatedPrice__c'].value || 0;
                    if (vOneTimePrice !== currentBasket.productLineItems[z].custom.vlocity_cmt_oneTimePrice) {
                        // eslint-disable-next-line no-loop-func
                        Transaction.wrap(function () {
                            currentBasket.productLineItems[z].custom.vlocity_cmt_pricingStatus = 'priceChange';
                        });
                        LOGGER.warn('Offer: {0} in your basket has a price change from: {1} to {2}',
                                    currentBasket.productLineItems[z].ID,
                                    currentBasket.productLineItems[z].custom.vlocity_cmt_oneTimePrice,
                                    vOneTimePrice);
                    }
                    var vRecurringPrice = vOffer[DCAPI_NAMESPACE + '__RecurringCalculatedPrice__c'].value || 0;
                    if (vRecurringPrice !== currentBasket.productLineItems[z].custom.vlocity_cmt_recurringPrice) {
                        // eslint-disable-next-line no-loop-func
                        Transaction.wrap(function () {
                            currentBasket.productLineItems[z].custom.vlocity_cmt_pricingStatus = 'priceChange';
                        });
                        LOGGER.warn('Offer: {0} in your basket has a recurring price change from: {1} to {2}',
                                    currentBasket.productLineItems[z].ID,
                                    currentBasket.productLineItems[z].custom.vlocity_cmt_recurringPrice,
                                    vRecurringPrice);
                    }
                } else { // This is a new line item for CC Basket
                    validatedHierarchyPath.push(vOffer.productHierarchyPath);
                    // TODO: add line item to CC Basket
                    // var newLineItem = currentBasket.createProductLineItem(createCCLineItem(vOffer));
                    // Transaction.wrap(function () {
                    //     newLineItem.custom.vlocity_cmt_pricingStatus = 'newOffer';
                    // });

                    var oneTimePrice = vOffer[DCAPI_NAMESPACE + '__OneTimeCalculatedPrice__c'].value || 0;
                    LOGGER.warn('Offer: {0} will be added your basket - Quantity: {1} at a One-Time price {2}',
                                vOffer.ProductCode,
                                vOffer.Quantity.value,
                                oneTimePrice);
                }
            }
        }
    }
}

function checkBasketRepricing(modifyBasketResponse) {
    var Transaction = require('dw/system/Transaction');
    var BasketMgr = require('dw/order/BasketMgr');
    var Logger = require('dw/system/Logger');
    var LOGGER = Logger.getLogger('int_vlocity_cmt', 'helpers.vlocity.basketHelper');

    var validatedHierarchyPath = [];

    var currentBasket = BasketMgr.getCurrentBasket();
    if (currentBasket.custom.vlocity_cmt_basketContentChange) {
        Transaction.wrap(function () {
            currentBasket.custom.vlocity_cmt_basketContentChange = false;
        });
        for (var i = 0; i < modifyBasketResponse.result.records.length; i++) {
            var mBRLineItem = modifyBasketResponse.result.records[i];
            processOffer(mBRLineItem, currentBasket, validatedHierarchyPath);
        }
        // loop CC Basket for record updates
        // identify line items that no longer match V Basket line items
        var matchedLineitem = false;
        var allCCLineItems = currentBasket.getAllProductLineItems();
        for (var x = 0; x < allCCLineItems.getLength(); x++) {
            matchedLineitem = false;
            for (var z = 0; z < validatedHierarchyPath.length; z++) {
                if (allCCLineItems[x].custom.v_productHierarchyPath === validatedHierarchyPath[z]) {
                    // lineItem has already matched
                    matchedLineitem = true;
                    break;
                }
            }
            if (!matchedLineitem) {
                // TODO: delete lineItem from CC Basket but need to display element on page
                // currentBasket.removeProductLineItem(allCCLineItems[x])
                // possible to use basket custom attribute to hold removed line item for display purposes.
                LOGGER.warn('Offer: {0} will be removed from your basket',
                            allCCLineItems[x].ID);  // could be allCCLineItems[x].ProductId;
            }
        }
    }
}

function createBasketAndAddProduct(vlocityBasket, productOrId, quantity, productStructure) {
    var productHelper = require('./productHelper');
    var vlocityParameterHelper = require('./customParameterHelper');

    var customerContext = vlocityParameterHelper.getURLParametersAsString();
    var product = productHelper.getProduct(productOrId);
    var catalogCode = productHelper.getCatalogCode(product);

    var getOfferDetailsResponse = productHelper.getOfferDetails(product, customerContext);

    var getConfiguredOfferResponse = productHelper.getConfiguredOfferDetails(getOfferDetailsResponse, product, quantity, customerContext, productStructure);

    var createBasketPayload = {
        basketAction: 'AddAfterConfig',
        productConfig: getConfiguredOfferResponse
    };

    var createBasketResponse = DCAPI.createBasket(createBasketPayload, catalogCode, customerContext);

    vlocityBasket.updateFromBasketResponse(createBasketResponse);

    return {
        offerDetails: getOfferDetailsResponse,
        configuredOfferDetails: getConfiguredOfferResponse,
        basketResponse: createBasketResponse
    };
}

function addProductToExistingBasket(vlocityBasket, productOrId, quantity) {
    var productHelper = require('./productHelper');
    var vlocityParameterHelper = require('./customParameterHelper');

    var customerContext = vlocityParameterHelper.getURLParametersAsString();
    var product = productHelper.getProduct(productOrId);
    var catalogCode = productHelper.getCatalogCode(product);

    var offerDetailsResponse = productHelper.getOfferDetails(product, customerContext);

    var configuredOfferResponse = productHelper.getConfiguredOfferDetails(offerDetailsResponse, product, quantity, customerContext);

    var modifyBasketPayload = {
        basketAction: 'AddAfterConfig',
        productConfig: configuredOfferResponse
    };

    var modifyBasketResponse = DCAPI.modifyBasket(vlocityBasket.cartContextKey, modifyBasketPayload, catalogCode, customerContext);

    checkBasketRepricing(modifyBasketResponse);

    vlocityBasket.updateFromBasketResponse(modifyBasketResponse);

    return {
        offerDetails: offerDetailsResponse,
        configuredOfferDetails: configuredOfferResponse,
        basketResponse: modifyBasketResponse
    };
}

function addStructuredProductToExistingBasket(vlocityBasket, productOrId, quantity, productStructure) {
    var productHelper = require('./productHelper');
    var vlocityParameterHelper = require('./customParameterHelper');

    var customerContext = vlocityParameterHelper.getURLParametersAsString();
    var product = productHelper.getProduct(productOrId);
    var catalogCode = productHelper.getCatalogCode(product);

    var offerDetailsResponse = productHelper.getOfferDetails(product, customerContext);

    var configuredOfferResponse = productHelper.getConfiguredOfferDetails(offerDetailsResponse, product, quantity, customerContext, productStructure);

    var modifyBasketPayload = {
        basketAction: 'AddAfterConfig',
        productConfig: configuredOfferResponse
    };

    var modifyBasketResponse = DCAPI.modifyBasket(vlocityBasket.cartContextKey, modifyBasketPayload, catalogCode, customerContext);

    checkBasketRepricing(modifyBasketResponse);

    vlocityBasket.updateFromBasketResponse(modifyBasketResponse);

    return {
        offerDetails: offerDetailsResponse,
        configuredOfferDetails: configuredOfferResponse,
        basketResponse: modifyBasketResponse
    };
}

module.exports.checkBasketDetails = function (currentBasket) {
    var vlocityParameterHelper = require('./customParameterHelper');
    var BasketModel = require('~/cartridge/models/vlocity/basket');

    var customerContext = vlocityParameterHelper.getURLParametersAsString();
    var vlocityBasket = new BasketModel(currentBasket);
    var catalogCode;

    if (currentBasket.productLineItems && currentBasket.productLineItems.getLength() > 0) {
        catalogCode = vlocityBasket.getCatalogCode();
    }

    if (vlocityBasket.isConnected() && catalogCode) {
        var basketDetailsResponse = DCAPI.getBasketDetails(vlocityBasket.getContextKey(), catalogCode, customerContext);

        checkBasketRepricing(basketDetailsResponse);

        vlocityBasket.updateFromBasketResponse(basketDetailsResponse);
    }
};

module.exports.addProduct = function (productOrId, quantity) {
    var BasketMgr = require('dw/order/BasketMgr');
    var BasketModel = require('~/cartridge/models/vlocity/basket');

    var currentBasket = BasketMgr.currentOrNewBasket;
    var vlocityBasket = new BasketModel(currentBasket);

    if (vlocityBasket.isConnected()) {
        return addProductToExistingBasket(vlocityBasket, productOrId, quantity);
    }
    return createBasketAndAddProduct(vlocityBasket, productOrId, quantity);
};

module.exports.addStructuredProduct = function (productOrId, quantity, productStructure, childProducts) {
    var BasketMgr = require('dw/order/BasketMgr');
    var ProductMgr = require('dw/catalog/ProductMgr');
    var productHelper = require('./productHelper');
    var BasketModel = require('~/cartridge/models/vlocity/basket');

    var currentBasket = BasketMgr.currentOrNewBasket;
    var vlocityBasket = new BasketModel(currentBasket);
    var product = productHelper.getProduct(productOrId);
    var productQuantity = parseInt(quantity, 10);

    var addProductResult;
    if (vlocityBasket.isConnected()) {
        addProductResult = addStructuredProductToExistingBasket(vlocityBasket, productOrId, productQuantity, productStructure);
    } else {
        addProductResult = createBasketAndAddProduct(vlocityBasket, productOrId, productQuantity, productStructure);
    }

    var mainLineItem = vlocityBasket.createLineItem(product, productQuantity);

    mainLineItem.setUnconfiguredProductDetails(addProductResult.offerDetails);
    mainLineItem.setProductDetailResult(addProductResult.configuredOfferDetails);

    childProducts.forEach(function (child) {
        var childQty = child.quantity;
        childQty = parseInt(childQty, 10);

        if (childQty > 0) {
            var childProductId = child.productId;
            var childProduct = ProductMgr.getProduct(childProductId);
            mainLineItem.createChildLineItem(childProduct, childQty, child.childProductPath);
        }
    });

    mainLineItem.updateFromBasketResponse(addProductResult.basketResponse);

    return mainLineItem.UUID;
};

module.exports.updateStructuredProduct = function (lineItemUUID, productOrId, quantity, productStructure, childProducts) {
    var BasketMgr = require('dw/order/BasketMgr');
    var currentBasket = BasketMgr.currentOrNewBasket;
    var BasketModel = require('~/cartridge/models/vlocity/basket');

    var lineItemToUpdate = BasketModel.getProductLineItemByUUID(currentBasket, lineItemUUID);

    this.removeLine(lineItemUUID);
    this.removeChildLineItems(currentBasket, lineItemUUID);
    currentBasket.removeProductLineItem(lineItemToUpdate);
    if (currentBasket.productQuantityTotal === 0) {
        this.disconnectBasket();
    }

    return this.addStructuredProduct(productOrId, quantity, productStructure, childProducts);
};

module.exports.saveLineItemDetails = function (lineItemUUID, addProductResult) {
    var BasketModel = require('~/cartridge/models/vlocity/basket');

    var vlocityBasket = new BasketModel();
    var vlocityLineItem = vlocityBasket.getLineItem(lineItemUUID);

    vlocityLineItem.updateFromBasketResponse(addProductResult.basketResponse);
    vlocityLineItem.setUnconfiguredProductDetails(addProductResult.offerDetails);
    vlocityLineItem.setProductDetailResult(addProductResult.configuredOfferDetails);
};

module.exports.updateLineQuantity = function (lineItemUUID, quantity) {
    var BasketModel = require('~/cartridge/models/vlocity/basket');
    var productHelper = require('./productHelper');
    var vlocityParameterHelper = require('./customParameterHelper');

    var vlocityBasket = new BasketModel();
    var lineItem = vlocityBasket.getProductLineItemByUUID(lineItemUUID);
    var vlocityLineItem = vlocityBasket.getLineItem(lineItem);

    var lineItemKey = vlocityLineItem.lineItemKey;
    var bundleContextKey = vlocityLineItem.bundleContextKey;
    var catalogCode = productHelper.getCatalogCode(lineItem.product);
    var customerContext = vlocityParameterHelper.getURLParametersAsString();

    var updateBasketPayload = {
        basketAction: 'updateBasket',
        lineItemKey: lineItemKey,
        bundleContextKey: bundleContextKey,
        Quantity: '' + quantity
    };

    var updateBasketItemsResponse = DCAPI.updateBasketItems(vlocityBasket.cartContextKey, updateBasketPayload, catalogCode, customerContext);

    vlocityBasket.updateFromBasketResponse(updateBasketItemsResponse);
    vlocityLineItem.updateFromBasketResponse(updateBasketItemsResponse);
    vlocityLineItem.updateChildProductQuantities(quantity);

    return updateBasketItemsResponse;
};

module.exports.updateLineProduct = function (lineItem, product, quantity) {
    var BasketModel = require('~/cartridge/models/vlocity/basket');
    var productHelper = require('./productHelper');
    var vlocityParameterHelper = require('./customParameterHelper');

    var vlocityBasket = new BasketModel();
    var vlocityLineItem = vlocityBasket.getLineItem(lineItem);

    var lineItemKey = vlocityLineItem.lineItemKey;
    var bundleContextKey = vlocityLineItem.bundleContextKey;
    var catalogCode = productHelper.getCatalogCode(lineItem.product);
    var customerContext = vlocityParameterHelper.getURLParametersAsString();

    var originalConfig = vlocityLineItem.getUnconfiguredProductDetails();

    productHelper.appendProductConfiguration(product, originalConfig);

    var updateBasketPayload = {
        basketAction: 'updateBasket',
        lineItemKey: lineItemKey,
        bundleContextKey: bundleContextKey,
        Quantity: '' + quantity,
        attributeCategories: originalConfig.offerDetails.offer.AttributeCategory
    };

    var updateBasketItemsResponse = DCAPI.updateBasketItems(vlocityBasket.cartContextKey, updateBasketPayload, catalogCode, customerContext);

    vlocityBasket.updateFromBasketResponse(updateBasketItemsResponse);
    vlocityLineItem.updateFromBasketResponse(updateBasketItemsResponse);

    return updateBasketItemsResponse;
};

module.exports.removeLine = function (lineItemUUID) {
    var BasketModel = require('~/cartridge/models/vlocity/basket');
    var productHelper = require('./productHelper');
    var vlocityParameterHelper = require('./customParameterHelper');

    var vlocityBasket = new BasketModel();
    var lineItem = vlocityBasket.getProductLineItemByUUID(lineItemUUID);
    var vlocityLineItem = vlocityBasket.getLineItem(lineItem);

    var lineItemKey = vlocityLineItem.lineItemKey;
    var bundleContextKey = vlocityLineItem.bundleContextKey;
    if (!lineItemKey || !bundleContextKey) {
        return null;
    }

    var catalogCode = productHelper.getCatalogCode(lineItem.product);
    var customerContext = vlocityParameterHelper.getURLParametersAsString();

    var deleteItemPayload = {
        basketAction: 'DeleteFromBasket',
        lineItemKey: lineItemKey,
        bundleContextKey: bundleContextKey
    };

    var updateBasketResponse = DCAPI.modifyBasket(vlocityBasket.cartContextKey, deleteItemPayload, catalogCode, customerContext);

    vlocityBasket.updateFromBasketResponse(updateBasketResponse);

    return updateBasketResponse;
};

module.exports.disconnectBasket = function () {
    var BasketModel = require('~/cartridge/models/vlocity/basket');
    var vlocityBasket = new BasketModel();
    vlocityBasket.disconnect();
};

module.exports.getVlocityLineItem = function (apiProductLineItem) {
    var BasketModel = require('~/cartridge/models/vlocity/basket');
    var vlocityBasket = new BasketModel();
    return vlocityBasket.getLineItem(apiProductLineItem);
};

module.exports.removeChildLineItems = function (currentBasket, parentUUID) {
    currentBasket.productLineItems.toArray().forEach(function (lineItem) {
        if (('vlocity_cmt_parentItemUUID' in lineItem.custom) && lineItem.custom.vlocity_cmt_parentItemUUID === parentUUID) {
            currentBasket.removeProductLineItem(lineItem);
        }
    });
};

module.exports.repriceBasket = function () {
    var Transaction = require('dw/system/Transaction');
    var BasketMgr = require('dw/order/BasketMgr');

    var currentBasket = BasketMgr.getCurrentBasket();
    var lineItemChanged = false; // TODO: fix holder with correct value

    Transaction.wrap(function () {
        currentBasket.custom.vlocity_cmt_basketContentChange = false;

        for (var i = 0; i < currentBasket.productLineItems.getLength(); i++) {
            if (lineItemChanged) {
                currentBasket.productLineItems[i].custom.vlocity_cmt_pricingStatus = 'priceChange'; // unchanged, priceChange, quantityChange, newOffer, removedOffer
                currentBasket.custom.vlocity_cmt_basketContentChange = true;
            }
        }
    });
};

module.exports.basketChangeAcknowledged = function () {
    var Transaction = require('dw/system/Transaction');
    var BasketMgr = require('dw/order/BasketMgr');

    var currentBasket = BasketMgr.getCurrentBasket();

    Transaction.wrap(function () {
        currentBasket.custom.vlocity_cmt_basketContentChange = false;

        for (var i = 0; i < currentBasket.productLineItems.getLength(); i++) {
            currentBasket.productLineItems[i].custom.vlocity_cmt_pricingStatus = 'unchanged';
        }
    });
};

module.exports.addProductToAsset = function (userInput) {
    var BasketMgr = require('dw/order/BasketMgr');
    var currentBasket = BasketMgr.getCurrentBasket();
    var BasketModel = require('~/cartridge/models/vlocity/basket');
    var vlocityAssetHelper = require('int_vlocity_cmt').assetHelper;
    var vlocityBasket = new BasketModel();
    var vlocityParameterHelper = require('./customParameterHelper');

    var customerContext = vlocityParameterHelper.getURLParametersAsString();
    var catalogCode = userInput.primaryCatalogCode;
    var addChildBasketPayLoad = {
        basketAction: 'AddWithNoConfig',
        offer: userInput.offer,
        bundleContextKey: userInput.bundleContextKey,
        parentHierarchyPath: userInput.parentHierarchyPath,
        parentLineItemKey: userInput.parentLineItemKey

    };

    var addProductToAssetResponse = DCAPI.addProductToAsset(vlocityBasket.cartContextKey, addChildBasketPayLoad, catalogCode, customerContext);
    if (addProductToAssetResponse.error !== 'OK') {
        throw addProductToAssetResponse.error;
    }

    vlocityAssetHelper.updateAssetContext(addProductToAssetResponse, currentBasket);

    return addProductToAssetResponse;
};

module.exports.updateAssetLine = function (userInput) {
    var vlocityAssetHelper = require('int_vlocity_cmt').assetHelper;
    var BasketMgr = require('dw/order/BasketMgr');
    var lineItemKey = userInput.lineItemKey;
    var bundleContextKey = userInput.bundleContextKey;
    var catalogCode = userInput.primaryCatalogCode;
    var currentBasket = BasketMgr.getCurrentBasket();
    var vlocityParameterHelper = require('./customParameterHelper');
    var Logger = require('dw/system/Logger');
    var LOGGER = Logger.getLogger('int_vlocity_cmt', 'helpers.vlocity.basketHelper');

    var customerContext = vlocityParameterHelper.getURLParametersAsString();
    var updateAssetBasketItemsResponse;
    try {
        var vlocityAttributeCategories = vlocityAssetHelper.populateAttributeCategories(userInput.vlocityAttributeCategories, userInput);

        var updateBasketPayload = {
            basketAction: 'updateBasket',
            lineItemKey: lineItemKey,
            bundleContextKey: bundleContextKey,
            attributeCategories: vlocityAttributeCategories
        };

        updateAssetBasketItemsResponse = DCAPI.updateAssetBasketItems(currentBasket.custom.vlocity_cmt_cartContextKey,
                            updateBasketPayload, catalogCode, customerContext);

        LOGGER.info('Update asset basket request response {0}', JSON.stringify(updateAssetBasketItemsResponse, null, 4));
        if (updateAssetBasketItemsResponse.errorCode === 'INVOKE-500') {
            throw updateAssetBasketItemsResponse.error;
        }
        vlocityAssetHelper.updateAssetContext(updateAssetBasketItemsResponse, currentBasket);
    } catch (e) {
        throw e;
    }

    return updateAssetBasketItemsResponse;
};

module.exports.removeAssetLine = function (userInput) {
    var BasketMgr = require('dw/order/BasketMgr');
    var BasketModel = require('~/cartridge/models/vlocity/basket');
    var vlocityAssetHelper = require('int_vlocity_cmt').assetHelper;
    var currentBasket = BasketMgr.getCurrentBasket();
    var Logger = require('dw/system/Logger');
    var vlocityParameterHelper = require('./customParameterHelper');
    var vlocityBasket = new BasketModel();
    var lineItemKey = userInput.lineItemKey;// userInput.lineItemKey;//
    var bundleContextKey = userInput.bundleContextKey;// /userInput.bundleContextKey;//

    if (!lineItemKey || !bundleContextKey) {
        return null;
    }

    var catalogCode = userInput.primaryCatalogCode;
    if (!catalogCode) {
        Logger.getLogger('vlocity.asset').debug('Catalog code missing');
    }

    var customerContext = vlocityParameterHelper.getURLParametersAsString();

    var deleteItemPayload = {
        basketAction: 'deleteFromBasket',
        lineItemKey: lineItemKey,
        bundleContextKey: bundleContextKey
    };

    var deleteBasketResponse = DCAPI.modifyAssetBasket(vlocityBasket.cartContextKey, deleteItemPayload, catalogCode, customerContext);
    Logger.info('Delete asset basket request response {0}', JSON.stringify(deleteBasketResponse, null, 4));

    if (deleteBasketResponse.errorCode === 'INVOKE-200' && deleteBasketResponse.result.records) {
        vlocityAssetHelper.updateAssetContext(deleteBasketResponse, currentBasket);
    } else {
        var errorMsg;
        if (deleteBasketResponse.error) {
            errorMsg = deleteBasketResponse.error;
        }
        if (deleteBasketResponse && deleteBasketResponse.result && deleteBasketResponse.result.messages) {
            errorMsg = deleteBasketResponse.result.messages[0];
        }

        var Resource = require('dw/web/Resource');
        throw Resource.msg('disconnect.asset.failed,Reason : ' + JSON.stringify(errorMsg), 'asset', null);
    }

    return deleteBasketResponse;
};
