/* eslint-disable valid-jsdoc */
/* eslint-disable guard-for-in */
/* eslint-disable no-restricted-syntax */
/* eslint-disable no-mixed-operators */
/*
* VLOCITY, INC. CONFIDENTIAL
* __________________
*
*  2014-2020 Vlocity, Inc.
*  All Rights Reserved.
*
* NOTICE:  All information contained herein is, and remains
* the property of Vlocity, Inc. and its suppliers,
* if any. The intellectual and technical concepts contained
* herein are proprietary to Vlocity, Inc. and its suppliers and may be
* covered by U.S. and Foreign Patents, patents in process, and are
* protected by trade secret or copyright law. Dissemination of this
* information and reproduction, modification or reverse-engineering
* of this material, is prohibited unless prior written permission
* is obtained from Vlocity, Inc.
*
*
*/
'use strict';

var HashMap = require('dw/util/HashMap');
var Site = require('dw/system/Site');
var Logger = require('dw/system/Logger');
var CustomCache = require('dw/system/CacheMgr');
var RESOURCE = require('~/CustomCacheResource.json');
var LOGGER = Logger.getLogger('int_vlocity_cmt', 'helpers.customCacheHelper');
var StringUtils = require('dw/util/StringUtils');
var CACHE = CustomCache.getCache('VlocityAPIsVDC');
var BasketMgr = require('dw/order/BasketMgr');
var CustomObjectMgr = require('dw/object/CustomObjectMgr');
var customObjectName = 'VlocitySystemLog';
var ENDPOINTS = require('~/cartridge/config/vlocityServiceEndpoints.json');
var DCAPI_NAMESPACE = Site.current.getCustomPreferenceValue('vlocity_cmt_NamespaceForDCAPI');

/**
 * Retrieves Vlocity offers published date/time from custom object storage
 * @returns {String} Returns PublishedOn DateTime as ISO String
 */
function getCatalogPublishDate() {
    var queryMap = new HashMap();
    var latestPublishDate = '';

    queryMap.put('custom.LogKey', 'CatalogDataPublish*');

    try {
        var vslIterator = CustomObjectMgr.queryCustomObjects(customObjectName, queryMap, 'custom.PublishedOn desc');
        latestPublishDate = vslIterator.first().custom.PublishedOn.toISOString();
    } catch (e) {
        LOGGER.error(' ERROR in getCatalogPublishDate() - Error occurred retrieving PublishedOn of last catalog publish: {0}', e.message);
    }
    return latestPublishDate;
}

/**
 * Create a cacheKey from input String
 * Takes in a reliable string to base a cache key
 * return a cache key with minimal chance of key collision.
 * @param {String} keyBase string to use for key generation
 * @param {Integer} seed integer value to use for key generation - default 0
 * @return {String} returns cacheKey as a String
 */
function keyGen(keyBase, seedVal) {
    var seed = seedVal || 0;
    var h1 = 0xdeadbeef ^ seed;
    var h2 = 0x41c6ce57 ^ seed;

    // Cache synchronization with Vlocity using timestamp of last Data Publish
    // Vlocity Data Publish timestamp stored in VlocitySystemLog PublishedOn and used to build the cache key.
    if (RESOURCE.useCustomCacheTimestamp) {
        // eslint-disable-next-line no-param-reassign
        keyBase += getCatalogPublishDate();
    }

    // HACK^2 -- multiple work arounds as Math.imul() is not supported
    // Can't use if (!Math.imul) because Rhino doesn't support function replacement for sealed object
    // if (!Math.imul) Math.imul = function(a, b) {
    var base16 = function (a, b) {
        var aHi = (a >>> 16) & 0xffff;
        var aLo = a & 0xffff;
        var bHi = (b >>> 16) & 0xffff;
        var bLo = b & 0xffff;
        // the shift by 0 fixes the sign on the high part
        // the final |0 converts the unsigned value into a signed value
        return ((aLo * bLo) + (((aHi * bLo + aLo * bHi) << 16) >>> 0) | 0);
    };

    // Alternative for String.padStart(x,y) method
    var padStart = function (strVal, length) {
        var padLen = length - strVal.length;
        var result = '';
        for (var i = 0; i < padLen; i++) {
            result += '0';
        }
        return (result += strVal);
    };

    for (var i = 0, ch; i < keyBase.length; i++) {
        ch = keyBase.charCodeAt(i);
        h1 = base16(h1 ^ ch, 2654435761);
        h2 = base16(h2 ^ ch, 1597334677);
    }
    h1 = base16(h1 ^ h1 >>> 16, 2246822507) ^ base16(h2 ^ h2 >>> 13, 3266489909);
    h2 = base16(h2 ^ h2 >>> 16, 2246822507) ^ base16(h1 ^ h1 >>> 13, 3266489909);

    // return (h2>>>0).toString(16).padStart(8,0)+(h1>>>0).toString(16).padStart(8,0);
    return padStart((h2 >>> 0).toString(16), 8) + padStart((h1 >>> 0).toString(16), 8);
}

/**
 * addToCache
 * @param {string} cacheKey
 * @param {JSON.Object} content
 */
function addToCache(cacheKey, cacheContent) {
    var Transaction = require('dw/system/Transaction');
    var currentBasket = BasketMgr.getCurrentBasket();
    if (RESOURCE.useCustomCache === true &&
        currentBasket &&
        !currentBasket.custom.vlocity_cmt_assetContext) {
        // store Vlocity response object in CACHE

        CACHE.put(cacheKey, JSON.stringify(cacheContent));
        Transaction.wrap(function () {
            currentBasket.custom.vlocity_cmt_catalogPublishDate = getCatalogPublishDate();
        });
    }
    return null;
}

/**
 * fetchFromCache
 * @param {string} cacheKey
 * @param {string} cacheContent or null
 */
function fetchFromCache(cacheKey) {
    var Transaction = require('dw/system/Transaction');
    var currentBasket = BasketMgr.getCurrentBasket();
    var cacheContent;

    if (RESOURCE.useCustomCache === true &&
        currentBasket &&
        !currentBasket.custom.vlocity_cmt_assetContext) {
        // fetch the Vlocity response object from CACHE
        var cacheOut = CACHE.get(cacheKey);

        if (currentBasket.custom.vlocity_cmt_catalogPublishDate &&
            currentBasket.custom.vlocity_cmt_catalogPublishDate < getCatalogPublishDate() &&
            RESOURCE.useCustomCacheTimestamp) {
            var previousPublish = currentBasket.custom.vlocity_cmt_catalogPublishDate;
            var latestPublish = getCatalogPublishDate();

            LOGGER.warn('Product Pricing Updated - Basket pricing published: {0} - Pricing updated on: {1}', previousPublish, latestPublish);

            Transaction.wrap(function () {
                // Cache date has changed since basket priced last. Basket content needs to be compared for changes
                currentBasket.custom.vlocity_cmt_basketContentChange = true;
            });
        }

        if (cacheOut != null) {
            cacheContent = JSON.parse(cacheOut);
        }
    }
    return cacheContent;
}

/**
 * This method retrieves the product attributes and sorts them
 * @param {productLineItem} currentBasket - string to use for key generation
 * @return {string} returns values[]
 * */
function getSortedOfferAttributes(productAttributes) {
    if (productAttributes && productAttributes.records && productAttributes.records.length !== 0) {
        var sortedAttributes = {};
        var keyList = [];

        for (var i = 0; i < productAttributes.records.length; i++) {
            keyList.push(productAttributes.records[i].code);
        }

        keyList.sort();

        for (var y = 0; y < keyList.length; y++) {
            sortedAttributes[keyList[y]] = productAttributes.records[y].userValues;
        }

        return JSON.stringify(sortedAttributes);
    }

    return '';
}

/**
 * This method returns the lineItems sorted alphabetically
 * @param {dw.util.HashMap} AllLineItems
 * @return {string} returns JSON.Stringified(SortedLineItems)
 * */
function getSortedAttributeCategories(attributeCategory) {
    var sortedCategories = '';

    if (attributeCategory && attributeCategory.records && attributeCategory.records.length !== 0) {
        var keyList = [];
        var categoryMap = new HashMap();

        for (var i = 0; i < attributeCategory.records.length; i++) {
            keyList.push(attributeCategory.records[i].Code__c);
            categoryMap.put(attributeCategory.records[i].Code__c,
                            getSortedOfferAttributes(attributeCategory.records[i].productAttributes));
        }

        keyList.sort();

        for (var y = 0; y < keyList.length; y++) {
            sortedCategories += keyList[y] + categoryMap.get(keyList[y]);
        }
    }

    return sortedCategories;
}

/**
 * This method returns the lineItems sorted alphabetically
 * @param {HashMap} AllLineItems
 * @return {string} returns JSON.Stringified(SortedLineItems)
 * */
function processOffer(offer, keyList) {
    if (offer) {
        if (offer.childProducts && offer.childProducts.length !== 0) {
            for (var i = 0; i < offer.childProducts.length; i++) {
                processOffer(offer.childProducts[i], keyList);
            }
        }

        // TODO: Process child lineItems
        // Requires an example with child LineItems to build proper processing
        // might be able to use the processOffer approach used for child offers

        if (offer.ProductCode) {
            keyList.push(offer.ProductCode + offer.Quantity + getSortedAttributeCategories(offer.AttributeCategory));
        }
    }
}

/**
 * This method returns the lineItems sorted alphabetically
 * @param {dw.util.HashMap} AllLineItems
 * @return {string} returns JSON.Stringified(SortedLineItems)
 * */
function getSortedOfferConfiguration(offerConfiguration) {
    var keyList = [];

    if (offerConfiguration &&
        offerConfiguration.result &&
        offerConfiguration.result.offerDetails &&
        offerConfiguration.result.offerDetails.offer) {
        var offer = offerConfiguration.result.offerDetails.offer;

        if (offer) {
            processOffer(offer, keyList);
            keyList.sort();
        }
    }
    return keyList.toString();
}

/**
 * This method retrieves the product attributes and sorts them
 * @param {productLineItem} currentBasket - string to use for key generation
 * @return {string} returns values[]
 * */
function getSortedAttributes(LineItem) {
    var sortedAttributes = {};
    if (LineItem.product && LineItem.product.custom) {
        var keyList = [];
        for (var key in LineItem.product.custom) {
            keyList.push(key);
        }

        // add quantity to keyList
        keyList.push('quantity');

        keyList.sort();

        for (var i = 0; i < keyList.length; i++) {
            if (keyList[i] === 'quantity') {
                sortedAttributes[keyList[i]] = LineItem.quantity.value.toString();
            } else {
                sortedAttributes[keyList[i]] = LineItem.product.custom[keyList[i]];
            }
        }
    }
    return JSON.stringify(sortedAttributes);
}

/**
 * This method returns the lineItems sorted alphabetically
 * @param {HashMap} AllLineItems
 * @return {string} returns JSON.Stringified(SortedLineItems)
 * */
function getSortedLineItems(AllLineItems) {
    // Need to get keys and values from userAttrMap and sort them for consistent cacheKey generation
    var sortedLineItems = '';
    if (AllLineItems) {
        var keyList = [];
        for (var i = 0; i < AllLineItems.getLength(); i++) {
            var ccLineItem = AllLineItems[i];

            if (ccLineItem.custom.vlocity_cmt_productCode) { // pricing already from Vlocity
                keyList.push(ccLineItem.custom.vlocity_cmt_productCode + getSortedAttributes(ccLineItem));
            } else if (ccLineItem.product.product && !ccLineItem.product.master) { // product is an attribute version
                keyList.push(ccLineItem.product.masterProduct.ID + getSortedAttributes(ccLineItem));
            } else if (ccLineItem.product.product && ccLineItem.product.master) { // this is the master product
                keyList.push(ccLineItem.product.ID + getSortedAttributes(ccLineItem));
            } else {
                // eslint-disable-next-line no-throw-literal
                throw 'Error identifying Vlocity product ID for: [0]' + ccLineItem;
            }
        }

        keyList.sort();

        for (var y = 0; y < keyList.length; y++) {
            sortedLineItems += keyList[y];
        }
    }
    return sortedLineItems;
}

/**
 *
 * @param {*} catalogCode
 * @param {*} queryString
 * @return {JSON.object} getOfferDetailsResult
 */
function getOffers(catalogCode, customerContext) {
    var cacheContent;
    var cacheKey;

    if (RESOURCE.useCustomCache === true) {
        var offersEndpoint = StringUtils.format(ENDPOINTS.DCAPI_GET_OFFERS, DCAPI_NAMESPACE, catalogCode) +
                                customerContext;

        cacheKey = keyGen(offersEndpoint);
        cacheContent = fetchFromCache(cacheKey);
    }
    return {
        cacheContent: cacheContent,
        cacheKey: cacheKey
    };
}

/**
 *
 * @param {*} offerCode
 * @param {*} catalogCode
 * @param {*} customerContext
 * @return {JSON.object} getOfferDetailsResult
 */
function getOfferDetails(offerCode, catalogCode, customerContext) {
    var cacheContent;
    var cacheKey;

    if (RESOURCE.useCustomCache === true) {
        var offerDetailEndpoint = StringUtils.format(ENDPOINTS.DCAPI_GET_OFFER_DETAILS, DCAPI_NAMESPACE, catalogCode, offerCode) +
                                    customerContext;

        cacheKey = keyGen(offerDetailEndpoint);
        cacheContent = fetchFromCache(cacheKey);
    }
    return {
        cacheContent: cacheContent,
        cacheKey: cacheKey
    };
}

/**
 *
 * @param {*} offerCode
 * @param {*} catalogCode
 * @param {*} offerConfiguration
 * @param {*} customerContext
 * @return {JSON.object} getConfiguredOfferDetailsResult
 */
function getConfiguredOfferDetails(offerCode, catalogCode, offerConfiguration, customerContext) {
    var cacheContent;
    var cacheKey;

    if (RESOURCE.useCustomCache === true) {
        var configuredOfferDetailEndpoint = StringUtils.format(ENDPOINTS.DCAPI_GET_OFFER_DETAILS, DCAPI_NAMESPACE, catalogCode, offerCode) +
                                            getSortedOfferConfiguration(offerConfiguration) +
                                            customerContext;

        cacheKey = keyGen(configuredOfferDetailEndpoint);
        cacheContent = fetchFromCache(cacheKey);
    }
    return {
        cacheContent: cacheContent,
        cacheKey: cacheKey
    };
}

/**
 *
 * @param {*} offerCode
 * @param {*} catalogCode
 * @param {*} customerContext
 * @return {JSON.object} createBasketResult
 */
function createBasket(createBasketPayload, catalogCode, customerContext) {
    var cacheContent;
    var cacheKey;

    if (RESOURCE.useCustomCache === true) {
        var createBasketEndpoint = StringUtils.format(ENDPOINTS.DCAPI_CREATE_BASKET, DCAPI_NAMESPACE, catalogCode, '') +
                                    getSortedLineItems(BasketMgr.getCurrentBasket().productLineItems) +
                                    customerContext;

        cacheKey = keyGen(createBasketEndpoint);
        cacheContent = fetchFromCache(cacheKey);
    }
    return {
        cacheContent: cacheContent,
        cacheKey: cacheKey
    };
}

/**
 *
 * @param {*} basketKey
 * @param {*} catalogCode
 * @param {*} customerContext
 * @return {JSON.object} modifyBasketResult
 */
function getBasketDetails(basketKey, catalogCode, customerContext) {
    var cacheContent;
    var cacheKey;

    if (RESOURCE.useCustomCache === true) {
        var getBasketDetailEndpoint = StringUtils.format(ENDPOINTS.DCAPI_GET_BASKET_DETAILS, DCAPI_NAMESPACE, catalogCode, basketKey) +
                                        customerContext;

        cacheKey = keyGen(getBasketDetailEndpoint);
        cacheContent = fetchFromCache(cacheKey);
    }

    return {
        cacheContent: cacheContent,
        cacheKey: cacheKey
    };
}

/**
 *
 * @param {*} offerCode
 * @param {*} catalogCode
 * @param {*} customerContext
 * @return {JSON.object} modifyBasketResult
 */
function modifyBasket(cartContextKey, modifyBasketPayload, catalogCode, customerContext) {
    var cacheContent;
    var cacheKey;

    if (RESOURCE.useCustomCache === true) {
        var modifyBasketEndpoint = StringUtils.format(ENDPOINTS.DCAPI_MODIFY_BASKET, DCAPI_NAMESPACE, catalogCode, '') +
                                    getSortedLineItems(BasketMgr.getCurrentBasket().productLineItems) +
                                    customerContext;

        cacheKey = keyGen(modifyBasketEndpoint);
        cacheContent = fetchFromCache(cacheKey);
    }
    return {
        cacheContent: cacheContent,
        cacheKey: cacheKey
    };
}

/**
 *
 * @param {*} offerCode
 * @param {*} catalogCode
 * @param {*} customerContext
 * @return {JSON.object} cacheContent, cacheKey
 */
function updateBasketItems(cartContextKey, updateBasketPayload, catalogCode, customerContext) {
    var cacheContent;
    var cacheKey;

    if (RESOURCE.useCustomCache === true) {
        var updateBasketEndpoint = StringUtils.format(ENDPOINTS.DCAPI_MODIFY_BASKET, DCAPI_NAMESPACE, catalogCode, '') +
                                getSortedLineItems(BasketMgr.getCurrentBasket().productLineItems) +
                                customerContext;

        cacheKey = keyGen(updateBasketEndpoint);
        cacheContent = fetchFromCache(cacheKey);
    }
    return {
        cacheContent: cacheContent,
        cacheKey: cacheKey
    };
}

// TODO: remove if not used
// function expiredBasketPricing() {

//     var currentBasket = BasketMgr.getCurrentBasket();

//     if( currentBasket
//         && currentBasket.custom.vlocity_cmt_catalogPublishDate
//         && currentBasket.custom.vlocity_cmt_catalogPublishDate < getCatalogPublishDate() ) {
//         return true;
//     }
//     return false;
// }

// TODO: remove is not used
/**
 * updateBasketPricing()
 * Check the Basket vlocity_cmt_catalogPublishDate against the latest catalog publish date
 * return true if the basket required repricing.
 * @returns {Boolean} basketRepriced
 */
function updateBasketPricing() {
    var basketRepriced = false;
    var currentBasket = BasketMgr.getCurrentBasket();

    if (RESOURCE.useCustomCache === true) {
        if (currentBasket &&
            (!currentBasket.custom.vlocity_cmt_catalogPublishDate ||
                currentBasket.custom.vlocity_cmt_catalogPublishDate < getCatalogPublishDate())) {
            // priceCurrentBasket();
            basketRepriced = true;
        }
    }

    return basketRepriced;
}

module.exports = {
    getCatalogPublishDate: getCatalogPublishDate,
    keyGen: keyGen,
    addToCache: addToCache,
    getOffers: getOffers,
    getOfferDetails: getOfferDetails,
    getConfiguredOfferDetails: getConfiguredOfferDetails,
    createBasket: createBasket,
    getBasketDetails: getBasketDetails,
    modifyBasket: modifyBasket,
    updateBasketItems: updateBasketItems,
    updateBasketPricing: updateBasketPricing
};
