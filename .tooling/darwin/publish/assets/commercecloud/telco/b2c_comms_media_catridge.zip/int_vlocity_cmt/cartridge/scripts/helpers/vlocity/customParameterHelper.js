/* eslint-disable guard-for-in */
/* eslint-disable no-restricted-syntax */
/* eslint-disable valid-jsdoc */
/* eslint-disable require-jsdoc */
/* eslint-disable no-throw-literal */
'use strict';

var HashMap = require('dw/util/HashMap');
var URLEncode = require('dw/crypto/Encoding');
var Logger = require('dw/system/Logger');
var LOGGER = Logger.getLogger('int_vlocity_cmt', 'helpers.calculateVlocityPricingHelper');
var Transaction = require('dw/system/Transaction');
var BasketMgr = require('dw/order/BasketMgr');

/**
 * This method is for converting JSON Obj as String to HashMap
 * @param {string} jsonObjStr - JSON String of parameters
 * @returns {dw.util.HashMap} Returns HashMap of context parameters
 */
function convertToHashMap(jsonObjStr) {
    var resultMap = new HashMap();

    if (jsonObjStr && jsonObjStr.length !== 0 && jsonObjStr !== '""') {
        var jsonObj = JSON.parse(jsonObjStr);
        if (typeof jsonObj === 'string') {
            jsonObj = JSON.parse(jsonObj);
        }

        if (jsonObj) {
            for (var x in jsonObj) {
                resultMap.put(x, jsonObj[x]);
            }
        }
    }

    return resultMap;
}

/**
 * This method is for converting HashMap to JSON Obj as string
 * @param {dw.util.HashMap} _hashMap - HashMap of parameters
 * @returns {string} jsonStr - Returns HashMap of context parameters as JSON String
 */
function convertToJSON(_hashMap) {
    var contextKeys = _hashMap.keySet();
    var jsonStr = '';
    if (contextKeys.size() > 0) {
        jsonStr += '{';
        for (var i = 0; i < contextKeys.size(); i++) {
            jsonStr += i > 0 ? ',' : '';
            jsonStr += '"' + contextKeys[i] + '":"' + _hashMap.get(contextKeys[i]) + '"';
        }
        jsonStr += '}';
    }
    return jsonStr;
}

/**
 * Return a HashMap of URL Parameters
 * @returns {string} Returns HashMap of context parameters as JSON String
 */
function retrieveURLParameters() {
    var parameterStr = session.custom.contextParameters;

    if (parameterStr && parameterStr.length !== 0) {
        return convertToHashMap(session.custom.urlParameters);
    }

    return new HashMap();
}

/**
 *
 * @param {string} urlParameters - JSON object as a string
 */
function storeURLParameters(urlParameters) {
    try {
        Transaction.wrap(function () {
            session.custom.urlParameters = JSON.stringify(convertToJSON(urlParameters));
        });
    } catch (e) {
        LOGGER.error(' ERROR in storeURLParameters() - Error occurred persisting URL parameters in session.custom.urlParameters: {0}', e.message);
    }
}

/**
 * @returns {dw.util.HashMap} _hashMap - HashMap of parameters
 */
function retrieveContextParameters() {
    var parameterStr = session.custom.contextParameters;

    if (parameterStr && parameterStr.length !== 0) {
        return convertToHashMap(session.custom.contextParameters);
    }

    return new HashMap();
}

/**
 * stores the context parameters as a session attribute
 * @param {string} contextParameters - JSON object as string
 */
function storeContextParameters(contextParameters) {
    try {
        Transaction.wrap(function () {
            session.custom.contextParameters = JSON.stringify(convertToJSON(contextParameters));
        });
    } catch (e) {
        LOGGER.error(' ERROR in storeURLParameters() - Error occurred persisting URL parameters in session.custom.urlParameters: {0}', e.message);
    }
}

/**
 * This method is use to set the
 * URL parameter: key and value
 *
 * return the key value or null
 * @param {string} key - string to use for key generation
 * @param {string} value - string value to use for key generation - default 0
 * */
function setContextParameter(key, value) {
    var contextParameters = retrieveContextParameters();
    contextParameters.put(key, value);
    storeContextParameters(contextParameters);
}

/**
 * This method is use to bulk load
 * context parameter: key and value pairs
 *
 * adds parameters to contextParameters hashmap
 * @param {dw.util.HashMap} _hashMap - HashMap of context parameters
 * */
function setContextParameters(_hashMap) {
    var contextParameters = new HashMap();

    contextParameters = retrieveContextParameters();
    contextParameters.putAll(_hashMap);
    storeContextParameters(contextParameters);
}

/**
 * This method is use to retrieve the
 * URL parameter by key
 *
 * return the key value or null
 * @param {string} key - string to use for key generation
 * @return {string} returns param value
 * */
function getContextParameter(key) {
    var contextParameters = new HashMap();

    contextParameters = retrieveContextParameters();
    return contextParameters.get(key);
}

/**
 * This method is use to devare the
 * URL parameter by key
 *
 * return the key value or null
 * @param {string} key - string to use for key generation
 * @return {string} result - returns parameters as string
 * */
function deleteContextParameter(key) {
    var contextParameters = new HashMap();

    contextParameters = retrieveContextParameters();
    if (contextParameters.containsKey(key)) {
        var result = contextParameters.remove(key);
        storeContextParameters(contextParameters);
        return result;
    }
    return null;
}

/**
 * This method returns a HashMap of Context Parameters.
 * @return {HashMap} returns values[]
 * */
function getContextParameters() {
    return retrieveContextParameters();
//    return contextParameters;
}

/**
 * This method is use to set the
 *  URL parameter: key and value
 *
 *
 * @type {dw.util.HashMap}
 *
 * return the key value or null
 * @param {string} _hashMap - string to use for key generation
 */
function setURLParameters(_hashMap) {
    var urlParameters = new HashMap();

    urlParameters = retrieveURLParameters();
    urlParameters.putAll(_hashMap);
    storeURLParameters(urlParameters);
}

/**
 * This method is use to set the
 * URL parameter: key and value
 *
 * return the key value or null
 * @param {string} key - string to use for key generation
 * @param {string} value - string value to use for key generation - default 0
 */
function setURLParameter(key, value) {
    var urlParameters = new HashMap();

    urlParameters = retrieveURLParameters();
    urlParameters.put(key, value);
    storeURLParameters(urlParameters);
}

/**
 * This method is use to retrieve the
 * URL parameter by key
 *
 * return the key value or null
 * @param {string} key - string to use for key generation
 * @return {string} returns param value
 * */
function getURLParameter(key) {
    var urlParameters = new HashMap();

    urlParameters = retrieveURLParameters();

    return urlParameters.get(key);
}

/**
 * This method is use to delete the
 *  URL parameter by key
 *
 * return the key value or null
 * @param {string} key - string to use for key generation
 * @return {string} returns param value
 * */
function deleteURLParameter(key) {
    var urlParameters = new HashMap();

    urlParameters = retrieveURLParameters();
    if (urlParameters.containsKey(key)) {
        var result = urlParameters.remove(key);
        storeURLParameters(urlParameters);
        return result;
    }

    return null;
}

/**
 * This method is use to set the
 *  custom context url from Product.js
 * Create a cacheKey from input String
 * Takes in a reliable string to base a cacke key
 * return a cache key with minimal chance of key collision.
 * @return {dw.util.HashMap} returns HashMap
 * */
function getURLParameters() {
    return retrieveURLParameters();
}

/**
 * Updates the logged in status parameters
 */
function updateLoginStatusParameters() {
    var customer = BasketMgr.getCurrentOrNewBasket().customer;
    var custAccID = '';

    if (customer.registered && customer.profile) {
        custAccID = customer.getProfile().custom.vlocity_cmt_accountId;
    }

    if (customer.isAuthenticated()) {
        setContextParameter('accountId', custAccID);
        setURLParameter('isloggedin', 'true');
    } else {
        deleteContextParameter('accountId');
        deleteURLParameter('isloggedin');
    }
}

/**
 * This method is for creating custom context values in the request URL
 * Example :/services/apexrest/vlocity_cmt/v3/catalogs/topupBundle/offers?
 *     context={"accountId":"0010Q00000xL2goQAC","subscriptionId":"a5t1x000000CmI9AAK"}
 *
 * This now returns only the context value:  '{"accountId":"0010Q00000xL2goQAC","subscriptionId":"a5t1x000000CmI9AAK"}
 * @param {dw.util.HashMap} _hashMap - generates the url encoded context parameter
 * @returns {string} contextString
 */
function createContext(_hashMap) {
    var contextKeys = _hashMap.keySet();
    var strToRet = '';
    if (contextKeys.size() > 0) {
        strToRet += '{';
        for (var i = 0; i < contextKeys.size(); i++) {
            strToRet += i > 0 ? ',' : '';
            strToRet += '"' + contextKeys[i] + '":"' + _hashMap.get(contextKeys[i]) + '"';
        }
        strToRet += '}';
    }
    return URLEncode.toURI(strToRet);
}

/**
 * This method is use to set the
 * custom context url from Product.js
 * Create a cacheKey from input String
 * Takes in a reliable string to base a cacke key
 * return a cache key with minimal chance of key collision.
 * @returns {string} returns values[]
 * */
function getURLParametersAsString() {
    var result = '';
    var allParameters = new HashMap();

    updateLoginStatusParameters();

    var urlParameters = getURLParameters();
    var contextParameters = getContextParameters();

    var contextValue = createContext(contextParameters);

    if (contextValue && contextValue.length !== 0 && contextParameters !== '""') {
        allParameters.put('context', contextValue);
    }
    allParameters.putAll(urlParameters);

    var allParametersKeys = allParameters.keySet();
    for (var i = 0; i < allParametersKeys.size(); i++) {
        result += i > 0 ? '&' : '?';
        result += allParametersKeys[i] + '=' + allParameters.get(allParametersKeys[i]);
    }

    return result;
}

/**
 *
 * @param {dw.util.HashMap} _contextParams - HashMap of context parameters
 */
function setContextParams(_contextParams) {
    setContextParameters(_contextParams);
}

module.exports = {
    setContextParameter: setContextParameter,
    setContextParameters: setContextParameters,
    deleteContextParameter: deleteContextParameter,
    getContextParameter: getContextParameter,
    getContextParameters: getContextParameters,
    setURLParameter: setURLParameter,
    setURLParameters: setURLParameters,
    deleteURLParameter: deleteURLParameter,
    getURLParameter: getURLParameter,
    getURLParameters: getURLParameters,
    getURLParametersAsString: getURLParametersAsString,
    setContextParams: setContextParams,
    createContext: createContext
};

