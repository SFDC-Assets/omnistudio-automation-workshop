/* eslint-disable valid-jsdoc */
'use strict';

/**
 * @module models/vlocity/contact
 */

/**
 * @type {dw.system.Transaction}
 */
var Transaction = require('dw/system/Transaction');
var Profile = require('dw/customer/Profile');

/**
 * Contact class
 * @param {dw.customer.Customer|dw.customer.Profile} [customer] Customer or profile object
 * @constructor
 * @alias module:models/vlocity/contact~Contact
 */
function Contact(customerOrProfile) {
    if (!customerOrProfile) {
        throw new Error('Invalid argument - customerOrProfile cannot be empty');
    }

    this.profile = customerOrProfile instanceof Profile
        ? customerOrProfile
        : customerOrProfile.profile;

    if (!this.profile) {
        throw new Error('Contact requires a registered customer profile to continue.');
    }

    this.type = 'Contact';
}

/**
 * @alias module:models/contact~Contact#prototype
 */
Contact.prototype = {
    /**
     * Builds up a formatted object for JSON.stringify()
     *
     * @returns {Object}
     */
    toJSON: function () {
        var addressbookObj = this.profile.getAddressBook();
        var prefAddress = addressbookObj.getPreferredAddress();
        var address1;
        var address2;
        var city;
        var stateCode;
        var postalCode;
        var street;

        if (prefAddress !== null) {
            address1 = prefAddress.address1;
            address2 = prefAddress.address2;
            city = prefAddress.city;
            stateCode = prefAddress.stateCode;
            postalCode = prefAddress.postalCode;
            street = address1;
            if (address2 !== null) {
                street += ', ' + address2;
            }
        }

        return {
            first_name: this.profile.getFirstName(),
            last_name: this.profile.getLastName(),
            email: this.profile.getEmail(),
            phone: this.profile.getPhoneHome(),
            customer_id: this.profile.getCustomer().getID(),
            customer_no: this.profile.getCustomerNo(),
            prefAddress: prefAddress,
            address1: address1,
            address2: address2,
            city: city,
            stateCode: stateCode,
            postalCode: postalCode,
            street: street
        };
    },

    /**
     * Get the {custom.vlocity_cmt_syncStatus} attribute
     *
     * @returns {vlocity_cmt_syncStatus}
     *
     */
    getStatus: function () {
        // returns null for Empty SyncStatus
        return this.profile.custom.vlocity_cmt_syncStatus.value;
    },

    /**
     * Update the {custom.vlocity_cmt_syncStatus} attribute with the given {status}
     *
     * @param {String} status
     */
    updateStatus: function (status) {
        var profile = this.profile;

        Transaction.wrap(function () {
            profile.custom.vlocity_cmt_syncStatus = status;
        });
    },

    /**
     * Update the {custom.sscid} attribute with the given {accountID}
     * Update the {custom.ssccid} attribute with the given {contactID}
     */
    updateExternalId: function (accountID) {
        var profile = this.profile;

        Transaction.wrap(function () {
            profile.custom.vlocity_cmt_accountId = accountID;
        });
    },

    /**
     * Update the {custom.sscSyncResponseText} attribute with the given {text}
     *
     * @param {String} text
     */
    updateSyncResponseText: function (text) {
        var profile = this.profile;

        Transaction.wrap(function () {
            profile.custom.vlocity_cmt_syncResponseText = text;
        });
    }
};

Contact.STATUS_EXPORTED = 'exported';
Contact.STATUS_CREATED = 'created';
Contact.STATUS_UPDATED = 'updated';

module.exports = Contact;
