/* eslint-disable no-underscore-dangle */
/* eslint-disable require-jsdoc */
'use strict';

var Transaction = require('dw/system/Transaction');
var Site = require('dw/system/Site');

var DCAPI_NAMESPACE = Site.current.getCustomPreferenceValue('vlocity_cmt_NamespaceForDCAPI');

function LineItem(apiLineItem) {
    Object.defineProperties(this, {
        _apiLineItem: {
            writable: false,
            value: apiLineItem
        },
        lineNumber: {
            enumerable: true,
            get: this.getLineNumber,
            set: this.setLineNumber
        },
        productCode: {
            enumerable: true,
            get: this.getProductCode,
            set: this.setProductCode
        },
        quantity: {
            enumerable: true,
            get: this.getQuantity,
            set: this.setQuantity
        },
        oneTimePrice: {
            enumerable: true,
            get: this.getOneTimePrice,
            set: this.setOneTimePrice

        },
        recurringPrice: {
            enumerable: true,
            get: this.getRecurringPrice,
            set: this.setRecurringPrice
        },
        lineItemKey: {
            enumerable: true,
            get: this.getLineItemKey,
            set: this.setLineItemKey
        },
        bundleContextKey: {
            enumerable: true,
            get: this.getBundleContextKey,
            set: this.setBundleContextKey
        },
        lineItemStatus: {
            enumerable: true,
            get: this.getLineItemStatus,
            set: this.setLineItemStatus
        },
        customerAuthenticated: {
            enumerable: true,
            get: this.isCustomerAuthenticated,
            set: this.setCustomerAuthenticated
        },
        attributes: {
            enumerable: true,
            get: this.getAttributes,
            set: this.setAttributes
        },
        unconfiguredProductDetails: {
            enumerable: true,
            get: this.getUnconfiguredProductDetails,
            set: this.setUnconfiguredProductDetails
        },
        productDetailResult: {
            enumerable: true,
            get: this.getProductDetailResult,
            set: this.setProductDetailResult
        },
        UUID: {
            enumerable: true,
            writable: false,
            value: apiLineItem.UUID
        }
    });
}

LineItem.prototype.getLineNumber = function () {
    return this._apiLineItem.custom.vlocity_cmt_lineNumber;
};

LineItem.prototype.setLineNumber = function (lineNumber) {
    var apiLineItem = this._apiLineItem;

    Transaction.wrap(function () {
        apiLineItem.custom.vlocity_cmt_lineNumber = lineNumber;
    });

    return this;
};

LineItem.prototype.getItemType = function () {
    return this._apiLineItem.custom.vlocity_cmt_itemType;
};

LineItem.prototype.setItemType = function (itemType) {
    var apiLineItem = this._apiLineItem;

    Transaction.wrap(function () {
        apiLineItem.custom.vlocity_cmt_itemType = itemType;
    });

    return this;
};

LineItem.prototype.getProductCode = function () {
    return this._apiLineItem.custom.vlocity_cmt_productCode;
};

LineItem.prototype.setProductCode = function (productCode) {
    var apiLineItem = this._apiLineItem;

    Transaction.wrap(function () {
        apiLineItem.custom.vlocity_cmt_productCode = productCode;
    });

    return this;
};

LineItem.prototype.getQuantity = function () {
    return this._apiLineItem.custom.vlocity_cmt_quantity;
};

LineItem.prototype.setQuantity = function (quantity) {
    var apiLineItem = this._apiLineItem;

    Transaction.wrap(function () {
        apiLineItem.custom.vlocity_cmt_quantity = quantity;
    });

    return this;
};

LineItem.prototype.getOneTimePrice = function () {
    return this._apiLineItem.custom.vlocity_cmt_oneTimePrice;
};

LineItem.prototype.setOneTimePrice = function (oneTimePrice) {
    var apiLineItem = this._apiLineItem;

    Transaction.wrap(function () {
        apiLineItem.custom.vlocity_cmt_oneTimePrice = oneTimePrice;
    });

    return this;
};

LineItem.prototype.getRecurringPrice = function () {
    return this._apiLineItem.custom.vlocity_cmt_recurringPrice;
};

LineItem.prototype.setRecurringPrice = function (recurringPrice) {
    var apiLineItem = this._apiLineItem;

    Transaction.wrap(function () {
        apiLineItem.custom.vlocity_cmt_recurringPrice = recurringPrice;
    });

    return this;
};

LineItem.prototype.getLineItemKey = function () {
    return this._apiLineItem.custom.vlocity_cmt_lineItemKey;
};

LineItem.prototype.setLineItemKey = function (lineItemKey) {
    var apiLineItem = this._apiLineItem;

    Transaction.wrap(function () {
        apiLineItem.custom.vlocity_cmt_lineItemKey = lineItemKey;
    });

    return this;
};

LineItem.prototype.getBundleContextKey = function () {
    return this._apiLineItem.custom.vlocity_cmt_bundleContextKey;
};

LineItem.prototype.setBundleContextKey = function (bundleContextKey) {
    var apiLineItem = this._apiLineItem;

    Transaction.wrap(function () {
        apiLineItem.custom.vlocity_cmt_bundleContextKey = bundleContextKey;
    });

    return this;
};

LineItem.prototype.getLineItemStatus = function () {
    return this._apiLineItem.custom.vlocity_cmt_lineItemStatus;
};

LineItem.prototype.setLineItemStatus = function (lineItemStatus) {
    var apiLineItem = this._apiLineItem;

    Transaction.wrap(function () {
        apiLineItem.custom.vlocity_cmt_lineItemStatus = lineItemStatus;
    });

    return this;
};

LineItem.prototype.isCustomerAuthenticated = function () {
    return this._apiLineItem.custom.vlocity_cmt_custAuthenticated;
};

LineItem.prototype.setCustomerAuthenticated = function (customerAuthenticated) {
    var apiLineItem = this._apiLineItem;

    Transaction.wrap(function () {
        apiLineItem.custom.vlocity_cmt_custAuthenticated = customerAuthenticated;
    });

    return this;
};

LineItem.prototype.getAttributes = function () {
    return this._apiLineItem.custom.vlocity_cmt_attributes;
};

LineItem.prototype.setAttributes = function (attributes) {
    var apiLineItem = this._apiLineItem;

    Transaction.wrap(function () {
        apiLineItem.custom.vlocity_cmt_attributes = attributes;
    });
    return this;
};

LineItem.prototype.getUnconfiguredProductDetails = function () {
    var value = this._apiLineItem.custom.vlocity_cmt_unconfiguredProductDetails;

    return value && JSON.parse(value);
};

LineItem.prototype.setUnconfiguredProductDetails = function (unconfiguredProductDetails) {
    var apiLineItem = this._apiLineItem;

    var value = unconfiguredProductDetails;
    if (value && typeof value === 'object') {
        value = JSON.stringify(value, null, 4);
    }

    Transaction.wrap(function () {
        apiLineItem.custom.vlocity_cmt_unconfiguredProductDetails = value;
    });

    return this;
};

LineItem.prototype.getProductDetailResult = function () {
    var value = this._apiLineItem.custom.vlocity_cmt_prodDetailResult;

    return value && JSON.parse(value);
};

LineItem.prototype.setProductDetailResult = function (productDetailResult) {
    var apiLineItem = this._apiLineItem;

    var value = productDetailResult;
    if (value && typeof value === 'object') {
        value = JSON.stringify(value, null, 4);
    }

    Transaction.wrap(function () {
        apiLineItem.custom.vlocity_cmt_prodDetailResult = value;
    });

    return this;
};

LineItem.prototype.getProductHierarchyPath = function () {
    return this._apiLineItem.custom.vlocity_cmt_productHierarchyPath;
};

function findRecordByLineNumber(records, lineNumber) {
    if (lineNumber) {
        var matchingRecords = records.filter(function (record) {
            return record.lineNumber === lineNumber;
        });

        if (matchingRecords.length) {
            return matchingRecords[0];
        }
    }

    return null;
}

function getChildRecordByPath(records, childPath) {
    if (!Array.isArray(records)) {
        return null;
    }

    for (var i = 0; i < records.length; i++) {
        var childProduct = records[i];

        if (childProduct.productHierarchyPath === childPath) {
            return childProduct;
        }

        var childProductFound = null;
        if (childProduct.lineItems && Array.isArray(childProduct.lineItems.records)) {
            childProductFound = getChildRecordByPath(childProduct.lineItems.records, childPath);
            if (childProductFound) {
                return childProductFound;
            }
        }
    }

    return null;
}

function getProductAttributes(productRecord) {
    var productAttributes = [];

    if (!productRecord.attributeCategories || !Array.isArray(productRecord.attributeCategories.records)) {
        return productAttributes;
    }

    for (var i = 0; i < productRecord.attributeCategories.records.length; i++) {
        var attributeCategory = productRecord.attributeCategories.records[i];

        if (attributeCategory.productAttributes && Array.isArray(attributeCategory.productAttributes.records)) {
            for (var j = 0; j < attributeCategory.productAttributes.records.length; j++) {
                var productAttribute = attributeCategory.productAttributes.records[j];

                if (productAttribute.userValues) {
                    var attributeData = {
                        attributeId: productAttribute.code,
                        inputType: productAttribute.inputType,
                        label: productAttribute.label,
                        value: productAttribute.userValues
                    };
                    productAttributes.push(attributeData);
                }
            }
        }
    }

    return productAttributes;
}

LineItem.prototype.createChildLineItem = function (product, quantity, childPath) {
    var lineItemCtnr = this._apiLineItem.lineItemCtnr;

    var apiProductLineItem = lineItemCtnr.createProductLineItem(
        product,
        null,
        lineItemCtnr.defaultShipment
    );

    apiProductLineItem.setQuantityValue(quantity * this._apiLineItem.quantityValue);
    apiProductLineItem.custom.vlocity_cmt_userQuantity = quantity;
    apiProductLineItem.custom.vlocity_cmt_parentItemUUID = this._apiLineItem.UUID;
    apiProductLineItem.custom.vlocity_cmt_productHierarchyPath = childPath;

    return new LineItem(apiProductLineItem);
};

LineItem.prototype.getChildLineItems = function () {
    if (this._children) {
        return this._children;
    }

    var children = [];

    var lineItemCtnr = this._apiLineItem.lineItemCtnr;
    var productLineItems = lineItemCtnr.productLineItems;

    for (var i = 0; i < productLineItems.length; i++) {
        var lineItem = productLineItems[i];

        if (lineItem.custom.vlocity_cmt_parentItemUUID === this._apiLineItem.UUID) {
            var childLineItem = new LineItem(lineItem);
            children.push(childLineItem);
        }
    }

    this._children = children;

    return children;
};

LineItem.prototype.getChildLineItem = function (productHierarchyPath) {
    var children = this.getChildLineItems();

    for (var i = 0; i < children.length; i++) {
        var childLineItem = children[i];

        if (childLineItem._apiLineItem.custom.vlocity_cmt_productHierarchyPath === productHierarchyPath) {
            return childLineItem;
        }
    }

    return null;
};

LineItem.prototype.updateFromBasketResponseRecord = function (basketResponseRecord) {
    var apiLineItem = this._apiLineItem;
    var attributes = getProductAttributes(basketResponseRecord);

    Transaction.wrap(function () {
        apiLineItem.custom.vlocity_cmt_custAuthenticated = customer.authenticated;
        apiLineItem.custom.vlocity_cmt_productCode = basketResponseRecord.ProductCode;
        apiLineItem.custom.vlocity_cmt_quantity = basketResponseRecord.Quantity.value;
        apiLineItem.custom.vlocity_cmt_lineItemKey = basketResponseRecord.lineItemKey;
        apiLineItem.custom.vlocity_cmt_bundleContextKey = basketResponseRecord.bundleContextKey;
        apiLineItem.custom.vlocity_cmt_oneTimePrice = basketResponseRecord[DCAPI_NAMESPACE + '__OneTimeCalculatedPrice__c'].value || 0;
        apiLineItem.custom.vlocity_cmt_recurringPrice = basketResponseRecord[DCAPI_NAMESPACE + '__RecurringCalculatedPrice__c'].value || 0;
        apiLineItem.custom.vlocity_cmt_lineNumber = basketResponseRecord.lineNumber;
        apiLineItem.custom.vlocity_cmt_productHierarchyPath = basketResponseRecord.productHierarchyPath;
        apiLineItem.custom.vlocity_cmt_attributes = (attributes && JSON.stringify(attributes)) || null;
    });
};

LineItem.prototype.updateFromBasketResponse = function (basketResponse) {
    var record = findRecordByLineNumber(basketResponse.result.records, this.lineNumber);

    if (!record) {
        // Assumed newly added records will always appear first
        record = basketResponse.result.records[0];
    }

    this.updateFromBasketResponseRecord(record);

    var children = this.getChildLineItems();
    for (var i = 0; i < children.length; i++) {
        var childLineItem = children[i];
        var childHierarchyPath = childLineItem.getProductHierarchyPath();
        var childRecord = getChildRecordByPath(record.lineItems.records, childHierarchyPath);

        if (childRecord) {
            childLineItem.updateFromBasketResponseRecord(childRecord);
        }
    }
};

LineItem.prototype.updateChildProductQuantities = function (qunatity) {
    var children = this.getChildLineItems();

    if (children && children.length) {
        Transaction.begin();
        for (var i = 0; i < children.length; i++) {
            var childLineItem = children[i];
            var userSelectedQuantity = childLineItem._apiLineItem.custom.vlocity_cmt_userQuantity;
            var updatedQuantity = userSelectedQuantity * qunatity;
            childLineItem._apiLineItem.setQuantityValue(updatedQuantity);
        }
        Transaction.commit();
    }
};

module.exports = LineItem;
