'use strict';

module.exports.getAccountId = function (profile) {
    return profile.custom.vlocity_cmt_accountId;
};

module.exports.getCustomerContext = function (currentCustomer) {
    if (currentCustomer.profile && !empty(currentCustomer.profile.custom.vlocity_cmt_accountId)) {
        return {
            context: {
                accountId: this.getAccountId(currentCustomer.profile)
            },
            isloggedin: true
        };
    }

    return null;
};

