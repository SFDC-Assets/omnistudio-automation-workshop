/* eslint-disable require-jsdoc */
'use strict';

var DCAPI = require('int_vlocity_cmt').VlocityService.DCAPI;

// -- Product Helper -----------------------------------------------------------

function getProduct(productOrId) {
    var Product = require('dw/catalog/Product');
    var ProductMgr = require('dw/catalog/ProductMgr');

    if (productOrId && typeof productOrId === 'string') {
        return ProductMgr.getProduct(productOrId);
    } else if (productOrId instanceof Product) {
        return productOrId;
    } else if (productOrId.productID) {
        return ProductMgr.getProduct(productOrId.productID);
    }

    return null;
}

module.exports.getProduct = getProduct;

function getCatalogCode(productOrId) {
    var product = getProduct(productOrId);

    if (!product) {
        throw new Error('Invalid argument - not a valid product or Id');
    }

    var catalogCodeStr = null;
    if ('vlocity_cmt_primaryCategory' in product.custom && !empty(product.custom.vlocity_cmt_primaryCategory)) {
        catalogCodeStr = product.custom.vlocity_cmt_primaryCategory;
    } else if (product.variant && product.masterProduct && 'vlocity_cmt_primaryCategory' in product.masterProduct.custom && !empty(product.masterProduct.custom.vlocity_cmt_primaryCategory)) {
        catalogCodeStr = product.masterProduct.custom.vlocity_cmt_primaryCategory;
    } else if (product.variant && product.masterProduct && product.masterProduct.primaryCategory.ID && !empty(product.masterProduct.primaryCategory.ID)) {
        return product.masterProduct.primaryCategory.ID;
    }

    if (catalogCodeStr) {
        try {
            var catalogCodeObject = JSON.parse(catalogCodeStr);
            // TODO: Need to revisit this logic, in general should not have multiple values;
            if (Array.isArray(catalogCodeObject)) {
                return catalogCodeObject.length
                    ? catalogCodeObject[0]
                    : null;
            }
        } catch (e) {
            return catalogCodeStr;
        }
    }

    return null;
}

module.exports.getCatalogCode = getCatalogCode;

function getVlocityAttribtueCategories(getOfferDetailsResponse) {
    if (getOfferDetailsResponse &&
        getOfferDetailsResponse.offerDetails &&
        getOfferDetailsResponse.offerDetails.offer &&
        getOfferDetailsResponse.offerDetails.offer.AttributeCategory &&
        getOfferDetailsResponse.offerDetails.offer.AttributeCategory.records) {
        return getOfferDetailsResponse.offerDetails.offer.AttributeCategory.records;
    }

    return null;
}

function getVlocityCategoryAttribtues(vlocityAttributeCategory) {
    if (vlocityAttributeCategory &&
        vlocityAttributeCategory.productAttributes &&
        vlocityAttributeCategory.productAttributes.records) {
        return vlocityAttributeCategory.productAttributes.records;
    }

    return null;
}

function appendProductConfiguration(product, getOfferDetailsResponse) {
    var vlocityAttributeCategories = getVlocityAttribtueCategories(getOfferDetailsResponse);

    if (Array.isArray(vlocityAttributeCategories)) {
        vlocityAttributeCategories.forEach(function (vlocityAttributeCategory) {
            var vlocityAttributes = getVlocityCategoryAttribtues(vlocityAttributeCategory);

            if (Array.isArray(vlocityAttributeCategories)) {
                vlocityAttributes.forEach(function (vlocityAttribute) {
                    var attributeId = vlocityAttribute.code;

                    if (attributeId in product.custom) {
                        vlocityAttribute.userValues = product.custom[attributeId];
                    }
                });
            }
        });
    }
}

module.exports.appendProductConfiguration = appendProductConfiguration;

module.exports.getOfferDetails = function (product, customerContext) {
    var offerCode = product.variant ? product.masterProduct.ID : product.ID;
    var catalogCode = getCatalogCode(product);

    var getOfferDetailsResponse = DCAPI.getOfferDetails(offerCode, catalogCode, customerContext);

    return getOfferDetailsResponse;
};

module.exports.getConfiguredOfferDetails = function (getOfferDetailsResponse, product, quantity, customerContext, productStructure) {
    var offerCode = product.variant ? product.masterProduct.ID : product.ID;
    var catalogCode = getCatalogCode(product);

    getOfferDetailsResponse.offerDetails.offer.Quantity = parseInt(quantity, 10);
    appendProductConfiguration(product, getOfferDetailsResponse);

    if (productStructure && productStructure.childProducts) {
        // TODO: Merge rather than replace?
        getOfferDetailsResponse.offerDetails.offer.childProducts = productStructure.childProducts;
    }

    var offerConfiguration = {
        result: getOfferDetailsResponse
    };

    var getConfiguredOfferResponse = DCAPI.getConfiguredOfferDetails(offerCode, catalogCode, offerConfiguration, customerContext);

    return getConfiguredOfferResponse;
};

module.exports.getCatalogOffers = function (catalogCode, customerContext) {
    var getOffersResponse = DCAPI.getOffers(catalogCode, customerContext);

    return getOffersResponse;
};

module.exports.getSelectedVariant = function (masterProduct, attribtuesMap) {
    if (!masterProduct.master) {
        return null;
    }

    var variationAttributeIDs = masterProduct.variationModel.attributeDefinitions.toArray().map(function (attrDefinition) {
        return attrDefinition.ID;
    });

    if (!variationAttributeIDs.length) {
        return null;
    }

    var variantsFound = masterProduct.variants.toArray().filter(function (variant) {
        return variationAttributeIDs.every(function (variationAttributeId) {
            return variant.custom[variationAttributeId] === attribtuesMap[variationAttributeId];
        });
    });

    if (variantsFound && variantsFound.length) {
        return variantsFound[0];
    }

    return null;
};
