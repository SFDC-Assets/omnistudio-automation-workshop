/* eslint-disable require-jsdoc */
/* eslint-disable no-underscore-dangle */
'use strict';

var HashMap = require('dw/util/HashMap');
var Site = require('dw/system/Site');
var DCAPI_NAMESPACE = Site.current.getCustomPreferenceValue('vlocity_cmt_NamespaceForDCAPI');
var vlocityProductHelper = require('int_vlocity_cmt').productHelper;
var Resource = require('dw/web/Resource');
var createAssetLine;
var createAssetContextTree;
var createAssetLinesFromAPI;
var createChildProductTree;
var Money = require('dw/value/Money');
var formatMoney = require('dw/util/StringUtils').formatMoney;

var findVariationProductInCC = function (productCode, prodAttrMap) {
    var currApiProduct = vlocityProductHelper.getProduct(productCode);
    var variationProducts = currApiProduct.variants;
    var matchingProduct;
    for (var x = 0; x < variationProducts.length; x++) {
        var currVarProd = variationProducts[x];
        var foundProduct = true;
        var attrVals = prodAttrMap.keySet();
        if (attrVals) {
            for (var y = 0; y < attrVals.length; y++) {
                var eachAttr = attrVals[y];
                if (currVarProd.custom[eachAttr] !== prodAttrMap.get(eachAttr)) {
                    foundProduct = false;
                }
            }
        }
        if (foundProduct === true) {
            matchingProduct = currVarProd;
            break;
        }
    }
    return matchingProduct;
};

var findVariationAttr = function (currApiProduct) {
    var variationAttrs = [];
    var collections = require('*/cartridge/scripts/util/collections');
    var variationModel = currApiProduct.variationModel;
    if (variationModel) {
        var allAttributes = variationModel.productVariationAttributes;
        collections.forEach(allAttributes, function (attr) {
            var prodAttrMap = {};
            var selectedVal = variationModel.getSelectedValue(attr).value;
            prodAttrMap.code = attr.displayName;// attr.attributeID;
            prodAttrMap.value = selectedVal;
            variationAttrs.push(prodAttrMap);
        });
    }
    return variationAttrs;
};

var findAttrCategories = function (attributeCategories) {
    var attrMap = new HashMap();

    if (attributeCategories && attributeCategories.records && attributeCategories.records.length) {
        for (var x = 0; x < attributeCategories.records.length; x++) {
            for (var y = 0; y < attributeCategories.records[x].productAttributes.records.length; y++) {
                if (attributeCategories.records[x].productAttributes.records[y].inputType === 'dropdown' ||
                    attributeCategories.records[x].productAttributes.records[y].inputType === 'radio') {
                    attrMap.put(attributeCategories.records[x].productAttributes.records[y].code,
                            attributeCategories.records[x].productAttributes.records[y].userValues);
                }
            }
        }
    }
    return attrMap;
};

var addAttrCategoriesToContext = function (newCurrentContext, orgCurrentContext) {
    var isVariationProduct = false;
    var attrMap;
    var ImageModel = require('*/cartridge/models/product/productImages');
    var vlocityAttributeCategories = orgCurrentContext.attributeCategories;
    if (vlocityAttributeCategories) {
        newCurrentContext.attributeCategories = vlocityAttributeCategories;
        newCurrentContext.vlocityAttributeCategories = vlocityAttributeCategories;
        attrMap = findAttrCategories(vlocityAttributeCategories);

        if (attrMap && attrMap.getLength()) {
            isVariationProduct = true;
        }
    }
    if (isVariationProduct) {
        newCurrentContext.currentProduct = findVariationProductInCC(newCurrentContext.ProductCode, attrMap);
        // --Found the matching product in CC
        if (newCurrentContext.currentProduct) {
            newCurrentContext.prodImages = new ImageModel(newCurrentContext.currentProduct, { types: ['large', 'small'], quantity: 'all' });
            newCurrentContext.variationAttributes = findVariationAttr(newCurrentContext.currentProduct);
        }
    } else {
        var currApiProduct = vlocityProductHelper.getProduct(newCurrentContext.ProductCode);
        if (currApiProduct) {
            newCurrentContext.currentProduct = currApiProduct;
            if (newCurrentContext.currentProduct) {
                newCurrentContext.prodImages = new ImageModel(currApiProduct, { types: ['large', 'small'], quantity: 'all' });
            }
            newCurrentContext.variationAttributes = null;
        }
    }
    return newCurrentContext;
};

createAssetLine = function (custAssetContext, basket) {
    var assetContext = custAssetContext;
    var eachAssetContext = {};
    var onetime = assetContext[DCAPI_NAMESPACE + '__OneTimeCharge__c'];
    var total = assetContext[DCAPI_NAMESPACE + '__OneTimeTotal__c'];
    var recurring = assetContext[DCAPI_NAMESPACE + '__RecurringCharge__c'];
    var currMasterProduct = vlocityProductHelper.getProduct(assetContext.ProductCode);
    if (assetContext) {
        // to track new product Vs Asset
        eachAssetContext.isProduct = false;
        eachAssetContext.currMasterProduct = currMasterProduct;
        eachAssetContext.DCAPI_NAMESPACE = DCAPI_NAMESPACE;
        if (assetContext[DCAPI_NAMESPACE + '__AssetReferenceId__c']) {
            eachAssetContext.Id = assetContext[DCAPI_NAMESPACE + '__AssetReferenceId__c'].value;
        }
        eachAssetContext.Name = assetContext.Name;
        eachAssetContext.quantity = (assetContext.Quantity && assetContext.Quantity.value) !== null ? assetContext.Quantity.value : '';
        eachAssetContext.sequenceNumber = assetContext.sequenceNumber;
        eachAssetContext.productId = assetContext.productId;
        eachAssetContext.ProductCode = assetContext.ProductCode;
        eachAssetContext.primaryCatalogCode = vlocityProductHelper.getCatalogCode(assetContext.ProductCode);
        if (recurring) {
            eachAssetContext.RecurringPrice = formatMoney(new Money(recurring.value, basket.currencyCode));
        }
        if (onetime) {
            eachAssetContext.OneTimePrice = formatMoney(new Money(onetime.value, basket.currencyCode));
        }
        if (total) {
            eachAssetContext.OneTimeTotal = formatMoney(new Money(total.value, basket.currencyCode));
        }
        eachAssetContext.action = assetContext.action;
        eachAssetContext.actions = assetContext.actions;
        eachAssetContext.lineItemKey = assetContext.lineItemKey;
        if (assetContext.actions && assetContext.actions.updateBasketAction) {
            eachAssetContext.bundleContextKey = assetContext.actions.updateBasketAction.rest.params.bundleContextKey;
        } else {
            eachAssetContext.bundleContextKey = assetContext.bundleContextKey;
        }
        eachAssetContext = addAttrCategoriesToContext(eachAssetContext, custAssetContext);
        eachAssetContext.currencyCode = basket.currencyCode;
        eachAssetContext.hasChildren = assetContext.hasChildren;
        if (assetContext.lineItems) {
            eachAssetContext.lineItems = [];
            createAssetContextTree(assetContext, basket, eachAssetContext);
        }
        if (assetContext.childProducts) {
            eachAssetContext.childProducts = createChildProductTree(basket, assetContext.childProducts);
        }
    } else {
        throw Resource.msg('asset.context.missing', 'asset', null);
    }
    return eachAssetContext;
};
createAssetContextTree = function (astContext, basket, currAssetContext) {
    var records = astContext.lineItems.records;
    if (records) {
        for (var i = 0; i < records.length; i++) {
            currAssetContext.lineItems.push(createAssetLine(records[i], basket));
        }
    }
};

function createChildProduct(basket, childProduct) {
    var assetChildProduct = {};
    assetChildProduct.isProduct = true;
    assetChildProduct.Id = childProduct.Id.value;
    assetChildProduct.Name = (childProduct.Name &&
                                childProduct.Name.value) !== null ? childProduct.Name.value : '';
    assetChildProduct.ProductCode = (childProduct.ProductCode &&
                                    childProduct.ProductCode.value) !== null ? childProduct.ProductCode.value : '';

    if (childProduct.UnitPrice && childProduct.UnitPrice.value && typeof childProduct.UnitPrice.value === 'number') {
        assetChildProduct.UnitPrice = formatMoney(new Money(childProduct.UnitPrice.value, basket.currencyCode));
    }
    if (childProduct[DCAPI_NAMESPACE + '__RecurringPrice__c'] &&
            childProduct[DCAPI_NAMESPACE + '__RecurringPrice__c'].value &&
            typeof childProduct[DCAPI_NAMESPACE + '__RecurringPrice__c'].value === 'number') {
        assetChildProduct.RecurringPrice = formatMoney(new Money(childProduct[DCAPI_NAMESPACE + '__RecurringPrice__c'].value, basket.currencyCode));
    }
    assetChildProduct.CurrencyCode = childProduct.CurrencyCode;
    assetChildProduct.quantity = childProduct.quantity.value;
    assetChildProduct.attributeCategories = childProduct.attributeCategories;
    assetChildProduct.primaryCatalogCode = vlocityProductHelper.getCatalogCode(assetChildProduct.ProductCode);
    assetChildProduct.actions = childProduct.actions;
    assetChildProduct.method = childProduct.actions.addChildBasketAction.rest.method;
    assetChildProduct.link = childProduct.actions.addChildBasketAction.rest.link;
    assetChildProduct.bundleContextKey = childProduct.actions.addChildBasketAction.rest.params.bundleContextKey;
    assetChildProduct.basketAction = childProduct.actions.addChildBasketAction.rest.params.basketAction;
    assetChildProduct.offer = childProduct.actions.addChildBasketAction.rest.params.offer;
    assetChildProduct.parentHierarchyPath = childProduct.actions.addChildBasketAction.rest.params.parentHierarchyPath;
    assetChildProduct.parentLineItemKey = childProduct.actions.addChildBasketAction.rest.params.parentLineItemKey;
    var currMasterProduct = vlocityProductHelper.getProduct(assetChildProduct.ProductCode);
    assetChildProduct.currMasterProduct = currMasterProduct;
    assetChildProduct = addAttrCategoriesToContext(assetChildProduct, childProduct);
    return assetChildProduct;
}

createChildProductTree = function (basket, childProducts) {
    var childProductTree = [];
    var currChildProducts = childProducts.records;
    if (currChildProducts) {
        for (var i = 0; i < currChildProducts.length; i++) {
            childProductTree.push(createChildProduct(basket, currChildProducts[i]));
        }
    }
    return childProductTree;
};

function createAssetLines(basket) {
    var assetLines = [];

    var assetContext = null;

    if (basket != null &&
        'vlocity_cmt_assetContext' in basket.custom &&
        !empty(basket.custom.vlocity_cmt_assetContext)) {
        assetContext = JSON.parse(basket.custom.vlocity_cmt_assetContext);
        if (assetContext.length > 0) {
            for (var i = 0; i < assetContext.length; i++) {
                var eachAssetContext = assetContext[i];
                var eachAsset = createAssetLine(eachAssetContext, basket);
                assetLines.push(eachAsset);
            }
        } else {
            assetLines.push(createAssetLine(assetContext, basket));
        }
    }

    return assetLines;
}
function updateAssetContext(updateBasketItemsResponse, basket) {
    var Transaction = require('dw/system/Transaction');
    Transaction.wrap(function () {
        basket.custom.vlocity_cmt_custAuthenticated = basket.customer.authenticated;
        basket.custom.vlocity_cmt_cartContextKey = updateBasketItemsResponse.cartContextKey;
        basket.custom.vlocity_cmt_BasketResponse = JSON.stringify(updateBasketItemsResponse, null, 4);
        var responseArr = [];
        if (updateBasketItemsResponse.result &&
            updateBasketItemsResponse.result.records) {
            for (var i = 0; i < updateBasketItemsResponse.result.records.length; i++) {
                if (updateBasketItemsResponse.result.records[i].action !== 'Add') {
                    responseArr.push(updateBasketItemsResponse.result.records[i]);
                }
            }
            basket.custom.vlocity_cmt_assetContext = JSON.stringify(createAssetLinesFromAPI(responseArr, basket));
        }
    });
}

function populateAttributeCategories(attCategories, userInput) {
    var vlocityAttributeCategories = attCategories;

    if (Array.isArray(vlocityAttributeCategories.records)) {
        vlocityAttributeCategories.records.forEach(function (vlocityAttributeCategory) {
            var vlocityAttributes = vlocityAttributeCategory.productAttributes.records;

            if (Array.isArray(vlocityAttributes)) {
                vlocityAttributes.forEach(function (eachVlocityAttribute) {
                    var attributeId = eachVlocityAttribute.code;

                    if (attributeId in userInput.product.custom) {
                        eachVlocityAttribute.userValues = userInput.product.custom[attributeId];
                    }
                });
            }
        });
    }

    return vlocityAttributeCategories;
}

function getAssetLineItemByAssetID(currentBasket, assetIDToRemove) {
    if (currentBasket.custom.vlocity_cmt_assetContext != null) {
        var currentAssets = JSON.parse(currentBasket.custom.vlocity_cmt_assetContext);
        for (var i = 0; i < currentAssets.length; i++) {
            var assetLI = currentAssets[i];

            if (assetLI.Id === assetIDToRemove) {
                return assetLI;
            }
        }
    }

    return null;
}

createAssetLinesFromAPI = function (asstLines, basket) {
    var assetLines = [];
    var assetRespLines = asstLines;// JSON.parse(asstLines);
    if (assetRespLines.length > 0) {
        for (var i = 0; i < assetRespLines.length; i++) {
            var eachAssetContext = assetRespLines[i];
            var eachAsset = createAssetLine(eachAssetContext, basket);
            assetLines.push(eachAsset);
        }
    }

    return assetLines;
};

module.exports = {
    createAssetLine: createAssetLine,
    getAssetLineItemByAssetID: getAssetLineItemByAssetID,
    populateAttributeCategories: populateAttributeCategories,
    updateAssetContext: updateAssetContext,
    createAssetLines: createAssetLines,
    createAssetLinesFromAPI: createAssetLinesFromAPI
};

