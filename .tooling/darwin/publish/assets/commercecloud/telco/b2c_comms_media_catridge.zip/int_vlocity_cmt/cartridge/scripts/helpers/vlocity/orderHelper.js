/* eslint-disable require-jsdoc */
/* eslint-disable no-underscore-dangle */
'use strict';

var VlocityService = require('int_vlocity_cmt').VlocityService;

function getShippingAddress(currentBasket) {
    var apiShippingAddress = currentBasket.defaultShipment && currentBasket.defaultShipment.shippingAddress;
    var shippingAddress = {};

    shippingAddress.ShippingCity = apiShippingAddress.city;
    shippingAddress.ShippingPostalCode = apiShippingAddress.postalCode;
    shippingAddress.ShippingCountry = apiShippingAddress.countryCode && apiShippingAddress.countryCode.displayValue;
    shippingAddress.ShippingState = apiShippingAddress.stateCode;
    shippingAddress.ShippingStreet = apiShippingAddress.address1;
    if (apiShippingAddress.address2) {
        shippingAddress.ShippingStreet += '\n' + apiShippingAddress.address2;
    }
    shippingAddress.Phone = apiShippingAddress.phone;

    return shippingAddress;
}

module.exports.submitOrder = function (currentBasket) {
    var BasketModel = require('~/cartridge/models/vlocity/basket');
    var vlocityCustomerHelper = require('./customerHelper');

    var vlocityBasket = new BasketModel(currentBasket);

    if (!vlocityBasket._customer.profile) {
        throw new Error('Cannot create cart in Vlocity for anonymous customer');
    }

    var catalogCode = vlocityBasket.getCatalogCode();

    if (!catalogCode) {
        throw new Error('Cannot create cart in Vlocity');
    }

    var accountId = vlocityCustomerHelper.getAccountId(vlocityBasket._customer.profile);

    var vlocityParameterHelper = require('./customParameterHelper');

    var context = {};
    context.accountId = accountId;

    var submitOrderPayload = {
        accountId: accountId,
        catalogCode: catalogCode,
        cartContextKey: vlocityBasket.cartContextKey,
        context: JSON.stringify(context),
        isloggedin: true
    };

    var shippingAddress = getShippingAddress(currentBasket);
    if (shippingAddress) {
        submitOrderPayload.shippingAddress = shippingAddress;
    }

    vlocityParameterHelper.setURLParameter('chainable', 'false');
    var customerContext = vlocityParameterHelper.getURLParametersAsString();

    var Site = require('dw/system/Site');
    var suppressCreateOrderValidation = Site.current.getCustomPreferenceValue('vlocity_cmt_suppressCreateOrderValidation');
    if (suppressCreateOrderValidation) {
        customerContext += (customerContext.length ? '&' : '?') + 'validate=false';
    }

    var submitOrderResponse = VlocityService.submitOrder(submitOrderPayload, customerContext);

    return submitOrderResponse;
};

module.exports.updateOrderWithSubmitOrderResponse = function (order, createCartResponse) {
    order.custom.vlocity_cmt_orderId = createCartResponse.orderId;
};
