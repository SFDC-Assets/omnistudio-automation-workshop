/* eslint-disable valid-jsdoc */
/* eslint-disable require-jsdoc */
'use strict';

var LocalServiceRegistry = require('dw/svc/LocalServiceRegistry');
var Site = require('dw/system/Site');
var StringUtils = require('dw/util/StringUtils');
var DCAPI_NAMESPACE = Site.current.getCustomPreferenceValue('vlocity_cmt_NamespaceForDCAPI');
var ENDPOINTS = require('~/cartridge/config/vlocityServiceEndpoints.json');
var CustomCache = require('~/cartridge/scripts/helpers/vlocity/customCacheHelper');

function resultIsOK(result) {
    return result.ok &&
        result.status === 'OK' &&
        result.object &&
        !result.object.isError &&
        result.object.responseObj;
}

function VlocityServiceException(errorMessage, errorContext, requestObject) {
    var reqObject = requestObject || {};

    this.message = errorMessage;
    this.errorMessage = errorMessage;
    this.errorContext = errorContext;
    this.endpoint = reqObject.endpoint;
    this.httpMethod = reqObject.httpMethod;

    this.toString = function () {
        return StringUtils.format('Vlocity Service exception: {0}; context: {1}; endpoint: {2}; method: {3}', this.message, this.errorContext, this.endpoint, this.httpMethod);
    };
}

function throwVlocityServiceException(requestObject, result) {
    if (!result.ok) {
        throw new VlocityServiceException(result.errorMessage, 'result', requestObject);
    } else if (result.object && result.object.isError) {
        throw new VlocityServiceException(result.object.errorText, 'result.object', requestObject);
    } else if (result.object && result.object.responseObj && result.object.responseObj.error && (result.object.responseObj.error !== 'OK')) {
        throw new VlocityServiceException(result.object.responseObj.error, 'result.object.responseObj', requestObject);
    } else {
        throw new VlocityServiceException('Unknown error', 'unknown', requestObject);
    }
}

function callService(requestObject, skipResultValidation) {
    if (!requestObject) {
        throw new Error('Required requestObject parameter missing or incorrect.');
    }

    var service = LocalServiceRegistry.createService('vlocity.rest', require('./services/vlocity'));
    var callResult = service.call(requestObject);

    if (!skipResultValidation && !resultIsOK(callResult)) {
        throwVlocityServiceException(requestObject, callResult);
    }
    return callResult;
}

function getMultiTransactionKey(result) {
    var nextTransactionDetails = 'nexttransaction' in result.object.responseObj && result.object.responseObj.nexttransaction;

    if (nextTransactionDetails &&
            nextTransactionDetails.rest &&
            nextTransactionDetails.rest.params &&
            nextTransactionDetails.rest.params.multiTransactionKey) {
        return nextTransactionDetails.rest.params.multiTransactionKey;
    }
    return null;
}

function multiTransactionCall(requestObject) {
    var result = callService(requestObject);

    var multiTransactionKey = getMultiTransactionKey(result);
    while (multiTransactionKey) {
        requestObject.payload.multiTransactionKey = multiTransactionKey;
        result = callService(requestObject);
        multiTransactionKey = getMultiTransactionKey(result);
    }
    return result;
}

module.exports.DCAPI = {
    getAssets: function (accountId, queryString) {
        var requestObject = {
            httpMethod: 'GET',
            endpoint: StringUtils.format(ENDPOINTS.GET_ASSETS, DCAPI_NAMESPACE, accountId)
        };
        if (queryString) {
            requestObject.queryString = queryString;
        }
        var result = callService(requestObject);
        return {
            result: result
        };
    },

    getOffers: function (catalogCode, queryString) {
        var cacheOutput = CustomCache.getOffers(catalogCode, queryString);
        var result;

        if (cacheOutput && cacheOutput.cacheContent) {
            return {
                offers: cacheOutput.cacheContent.offers,
                nextOffersAction: cacheOutput.cacheContent.nextOffersAction,
                hasMore: 'nextOffersAction' in cacheOutput.cacheContent
            };
        }
        var requestObject = {
            httpMethod: 'GET',
            endpoint: StringUtils.format(ENDPOINTS.DCAPI_GET_OFFERS, DCAPI_NAMESPACE, catalogCode)
        };

        if (queryString) {
            requestObject.queryString = queryString;
        }

        result = multiTransactionCall(requestObject);

        if (resultIsOK(result)) {
            CustomCache.addToCache(cacheOutput.cacheKey, result.object.responseObj);
        }

        return {
            offers: result.object.responseObj.offers,
            nextOffersAction: result.object.responseObj.nextOffersAction,
            hasMore: 'nextOffersAction' in result.object.responseObj
        };
    },

    getOfferDetails: function (offerCode, catalogCode, queryString) {
        var cacheOutput = CustomCache.getOfferDetails(offerCode, catalogCode, queryString);
        var result;

        if (cacheOutput && cacheOutput.cacheContent) {
            return cacheOutput.cacheContent;
        }
        var requestObject = {
            httpMethod: 'GET',
            endpoint: StringUtils.format(ENDPOINTS.DCAPI_GET_OFFER_DETAILS, DCAPI_NAMESPACE, catalogCode, offerCode)
        };

        if (queryString) {
            requestObject.queryString = queryString;
        }

        result = multiTransactionCall(requestObject);

        if (!result.object.responseObj.result || (result.object.responseObj.success === false)) {
            throw new VlocityServiceException(result.object.responseObj.error, 'DCAPI.getOfferDetails', requestObject);
        }

        CustomCache.addToCache(cacheOutput.cacheKey, result.object.responseObj.result);

        return result.object.responseObj.result;
    },

    /**
     *
     * @param {string} offerCode
     * @param {string} catalogCode
     * @param {object} offerConfiguratgion
     * @returns {object}
     */
    getConfiguredOfferDetails: function (offerCode, catalogCode, offerConfiguration, queryString) {
        var cacheOutput = CustomCache.getConfiguredOfferDetails(offerCode, catalogCode, offerConfiguration, queryString);
        var result;

        if (cacheOutput && cacheOutput.cacheContent) {
            return cacheOutput.cacheContent;
        }
        var requestObject = {
            httpMethod: 'POST',
            endpoint: StringUtils.format(ENDPOINTS.DCAPI_GET_OFFER_DETAILS, DCAPI_NAMESPACE, catalogCode, offerCode),
            payload: offerConfiguration
        };

        if (queryString) {
            requestObject.queryString = queryString;
        }

        result = multiTransactionCall(requestObject);

        if (!result.object.responseObj.result || (result.object.responseObj.success === false)) {
            throw new VlocityServiceException(result.object.responseObj.error, 'DCAPI.getConfiguredOfferDetails', requestObject);
        }

        CustomCache.addToCache(cacheOutput.cacheKey, result.object.responseObj.result);

        return result.object.responseObj.result;
    },

    createAssetBasket: function (newBasketPayload, catalogCode, queryString) {
        var result;
        var requestObject = {
            httpMethod: 'POST',
            endpoint: StringUtils.format(ENDPOINTS.DCAPI_CREATE_BASKET, DCAPI_NAMESPACE, catalogCode),
            payload: newBasketPayload
        };

        if (queryString) {
            requestObject.queryString = queryString;
        }

        result = multiTransactionCall(requestObject);

        if (resultIsOK(result)) {
            return result.object.responseObj;
        }

        return null;
    },

    addProductToAsset: function (basketKey, existingBasketPayload, catalogCode, queryString) {
        var result;
        var Resource = require('dw/web/Resource');

        var requestObject = {
            httpMethod: 'POST',
            endpoint: StringUtils.format(ENDPOINTS.DCAPI_MODIFY_BASKET, DCAPI_NAMESPACE, catalogCode, basketKey),
            payload: existingBasketPayload
        };

        if (queryString) {
            requestObject.queryString = queryString;
        }

        result = multiTransactionCall(requestObject);

        if (!resultIsOK(result)) {
            throw Resource.msg('add.product.to.asset.failed', 'asset', null);
        }

        return result.object.responseObj;
    },

    modifyAssetBasket: function (basketKey, existingBasketPayload, catalogCode, queryString) {
        var result;
        var Resource = require('dw/web/Resource');

        var requestObject = {
            httpMethod: 'POST',
            endpoint: StringUtils.format(ENDPOINTS.DCAPI_MODIFY_BASKET, DCAPI_NAMESPACE, catalogCode, basketKey),
            payload: existingBasketPayload
        };

        if (queryString) {
            requestObject.queryString = queryString;
        }

        result = multiTransactionCall(requestObject);

        if (!resultIsOK(result)) {
            throw Resource.msg('modifyAssetBasket.failed', 'asset', null);
        }

        return result.object.responseObj;
    },

    updateAssetBasketItems: function (basketKey, updateBasketInput, catalogCode, queryString) {
        var result;
        var Resource = require('dw/web/Resource');

        var requestObject = {
            httpMethod: 'PUT',
            endpoint: StringUtils.format(ENDPOINTS.DCAPI_MODIFY_BASKET, DCAPI_NAMESPACE, catalogCode, basketKey),
            payload: updateBasketInput
        };

        if (queryString) {
            requestObject.queryString = queryString;
        }

        result = multiTransactionCall(requestObject);

        if (!resultIsOK(result)) {
            throw Resource.msg('update.asset.failed', 'asset', null);
        }

        return result.object.responseObj;
    },

    createBasket: function (newBasketPayload, catalogCode, queryString) {
        var cacheOutput = CustomCache.createBasket(newBasketPayload, catalogCode, queryString);
        var result;

        if (cacheOutput && cacheOutput.cacheContent) {
            return cacheOutput.cacheContent;
        }
        var requestObject = {
            httpMethod: 'POST',
            endpoint: StringUtils.format(ENDPOINTS.DCAPI_CREATE_BASKET, DCAPI_NAMESPACE, catalogCode),
            payload: newBasketPayload
        };

        if (queryString) {
            requestObject.queryString = queryString;
        }

        result = multiTransactionCall(requestObject);

        if (!result.object.responseObj.result || (result.object.responseObj.success === false)) {
            throw new VlocityServiceException(result.object.responseObj.error, 'DCAPI.createBasket', requestObject);
        }

        CustomCache.addToCache(cacheOutput.cacheKey, result.object.responseObj);

        return result.object.responseObj;
    },

    getBasketDetails: function (basketKey, catalogCode, queryString) {
        var cacheOutput = CustomCache.getBasketDetails(basketKey, catalogCode, queryString);
        var result;

        if (cacheOutput && cacheOutput.cacheContent) {
            return cacheOutput.cacheContent;
        }
        var requestObject = {
            httpMethod: 'GET',
            endpoint: StringUtils.format(ENDPOINTS.DCAPI_GET_BASKET_DETAILS, DCAPI_NAMESPACE, catalogCode, basketKey)
        };

        if (queryString) {
            requestObject.queryString = queryString;
        }

        result = multiTransactionCall(requestObject);

        if (result.object.responseObj.result) {
            CustomCache.addToCache(cacheOutput.cacheKey, result.object.responseObj);
        } else {
            throw new VlocityServiceException('Get basket details failed, Reason: ' + result.object.responseObj.error, ' getBasketDetails ', requestObject);
        }

        if (!result.object.responseObj.result) {
            throw new VlocityServiceException(result.object.responseObj.error, 'DCAPI.getBasketDetails', requestObject);
        }

        return result.object.responseObj;
    },

    modifyBasket: function (basketKey, existingBasketPayload, catalogCode, queryString) {
        var cacheOutput = CustomCache.modifyBasket(basketKey, existingBasketPayload, catalogCode, queryString);
        var result;

        if (cacheOutput && cacheOutput.cacheContent) {
            return cacheOutput.cacheContent;
        }
        var requestObject = {
            httpMethod: 'POST',
            endpoint: StringUtils.format(ENDPOINTS.DCAPI_MODIFY_BASKET, DCAPI_NAMESPACE, catalogCode, basketKey),
            payload: existingBasketPayload
        };

        if (queryString) {
            requestObject.queryString = queryString;
        }

        result = multiTransactionCall(requestObject);

        if (!result.object.responseObj.result) {
            throw new VlocityServiceException(result.object.responseObj.error, 'DCAPI.modifyBasket', requestObject);
        }

        CustomCache.addToCache(cacheOutput.cacheKey, result.object.responseObj);

        return result.object.responseObj;
    },

    updateBasketItems: function (basketKey, updateBasketInput, catalogCode, queryString) {
        var cacheOutput = CustomCache.updateBasketItems(basketKey, updateBasketInput, catalogCode, queryString);
        var result;

        if (cacheOutput && cacheOutput.cacheContent) {
            return cacheOutput.cacheContent;
        }
        var requestObject = {
            httpMethod: 'PUT',
            endpoint: StringUtils.format(ENDPOINTS.DCAPI_MODIFY_BASKET, DCAPI_NAMESPACE, catalogCode, basketKey),
            payload: updateBasketInput
        };

        if (queryString) {
            requestObject.queryString = queryString;
        }

        result = multiTransactionCall(requestObject);

        if (!result.object.responseObj.result) {
            throw new VlocityServiceException(result.object.responseObj.error, 'DCAPI.updateBasketItems', requestObject);
        }

        CustomCache.addToCache(cacheOutput.cacheKey, result.object.responseObj);

        return result.object.responseObj;
    },

    createOrderFromBasket: function (requestBody, queryString) {
        var requestObject = {
            httpMethod: 'POST',
            endpoint: StringUtils.format(ENDPOINTS.DCAPI_CREATE_CART, DCAPI_NAMESPACE),
            payload: requestBody
        };

        if (queryString) {
            requestObject.queryString = queryString;
        }

        var result = multiTransactionCall(requestObject);

        return result.object.responseObj;
    },

    getAccountHierarchy: function (graphId, requestBody) {
        var requestObject = {
            httpMethod: 'POST',
            endpoint: StringUtils.format(ENDPOINTS.FETCH_GRAPH, DCAPI_NAMESPACE, graphId),
            payload: requestBody
        };

        var result = multiTransactionCall(requestObject);

        return result.object.responseObj;
    }

};

module.exports.createAccount = function (accountPayload) {
    var requestObject = {
        httpMethod: 'POST',
        endpoint: StringUtils.format(ENDPOINTS.VPL_CREATE_ACCOUNT, DCAPI_NAMESPACE),
        payload: accountPayload
    };

    var result = callService(requestObject);

    return result;
};

module.exports.updateAccount = function (accountPayload) {
    return this.createAccount(accountPayload);
};

/* eslint-disable consistent-return */
/* eslint-disable indent*/
/* eslint-disable no-trailing-spaces*/
/* eslint-disable no-multiple-empty-lines*/
/* eslint-disable no-multi-spaces*/

module.exports.submitOrder = function (submitOrderPayload, queryString) {
    var firstRequestObject = {
        httpMethod: 'POST',
        endpoint: StringUtils.format(ENDPOINTS.VPL_SUBMIT_ORDER, DCAPI_NAMESPACE),
        payload: submitOrderPayload
    };

    if (queryString) {
        firstRequestObject.queryString = queryString;
    }

    var firstCallResult = callService(firstRequestObject, true /* skip validation */);

    if (firstCallResult.ok &&
        firstCallResult.object &&
        !firstCallResult.object.isError &&
        firstCallResult.object.responseObj) {
        var firstCallResponse = JSON.parse(firstCallResult.object.responseObj);

        if (firstCallResponse && firstCallResponse.orderId && firstCallResponse.orderNumber) {
            return firstCallResponse;
        }

        if (firstCallResponse && firstCallResponse.vlcIPData && firstCallResponse.vlcStatus === 'InProgress') {
            var secondRequestObject = {
                httpMethod: 'POST',
                endpoint: StringUtils.format(ENDPOINTS.VPL_SUBMIT_ORDER, DCAPI_NAMESPACE),
                headers: {
                    vlcIPData: firstCallResponse.vlcIPData
                },
                queryString: {
                    vlcIPData: firstCallResponse.vlcIPData
                },
                payload: {}
            };

            var secondCallResult = callService(secondRequestObject, true /* skip validation */);

            if (secondCallResult.ok &&
                secondCallResult.object &&
                !secondCallResult.object.isError &&
                secondCallResult.object.responseObj) {
                var secondCallResponse = JSON.parse(secondCallResult.object.responseObj);

                if (secondCallResponse && secondCallResponse.orderId) {
                    return secondCallResponse;
                }
            } else {
                throw new VlocityServiceException('Creating Order in Vlocity Failed, Reason: ' + secondCallResult.errorMessage, 'submitOrder', secondRequestObject);
            }
        }
    }
    if (firstCallResult.errorMessage) {
        throw new VlocityServiceException('Creating Order in Vlocity Failed, Reason: ' + firstCallResult.errorMessage, 'submitOrder', firstRequestObject);
    }
};

module.exports.Exception = VlocityServiceException;
