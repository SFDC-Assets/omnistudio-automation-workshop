function printRecipe(){
    window.print();
}