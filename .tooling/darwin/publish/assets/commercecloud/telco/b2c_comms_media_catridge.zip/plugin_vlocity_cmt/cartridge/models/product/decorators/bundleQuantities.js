/* eslint-disable wrap-iife */
'use strict';

module.exports = function (object, apiProduct, params) {
    Object.defineProperty(object, 'bundleMinQuantity', {
        enumerable: true,
        value: (function () {
            var bundleMinQuantity = params.minQuantity;
            return bundleMinQuantity;
        })()
    });

    Object.defineProperty(object, 'bundleMaxQuantity', {
        enumerable: true,
        value: (function () {
            var bundleMaxQuantity = params.maxQuantity;
            return bundleMaxQuantity;
        })()
    });

    Object.defineProperty(object, 'bundleDefaultQuantity', {
        enumerable: true,
        value: (function () {
            var bundleDefaultQuantity = params.defaultQuantity;
            return bundleDefaultQuantity;
        })()
    });
};
