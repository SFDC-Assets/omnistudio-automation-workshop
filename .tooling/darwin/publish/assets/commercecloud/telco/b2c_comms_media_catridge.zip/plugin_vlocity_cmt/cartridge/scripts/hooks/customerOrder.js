/* eslint-disable valid-jsdoc */
'use strict';

/**
 * @module hooks/customerOrder
 */

/**
 * @type {dw.system.Logger}
 */
var Logger = require('dw/system/Logger');

/**
 * This method will export the given {order} details to Service Cloud through REST API
 * If the async mode is disabled
 *
 * @param {dw.order.Order} order
 */
function handleExport() {
    var vlocityService = require('int_vlocity_cmt').VlocityService;

    // TODO: get basket details via the cart context key, from the response of the call pass that through to create cart

    // mock addToBasketRequest
    var addToBasketRequest = {
        offer: 'VLO-MOB-0161', basketAction: 'AddWithNoConfig'
    };

    var payloadCartRequest = {
        accountId: '0013k00002inUCgAAM',
        catalogCode: 'MOBCATPHO'
        // JSONResult: the result I get back from calling the basket api

    };
    // by this stage the a basket with cartContextKey must have been created : dependent on getting the GET basket API to work
    try {
        var vlocityBasket = vlocityService.createBasket(addToBasketRequest);
        payloadCartRequest.JSONResult = vlocityBasket.object.responseObj.result;
        Logger.info('Add to basket request response {0}', JSON.stringify(vlocityBasket, null, 4));
    } catch (e) {
        Logger.error('Error when sending order: {0}', e.message);
    }
}

/**
 * @type {module:ServiceMgr}
 */
/**
 * @type {dw.system.Logger}
 */

/**
 * Customer order created
 * @param {dw.order.Order} order
 */
function orderCreated(order) {
    handleExport(order, 'created');
}

/**
 * Customer order updated
 * @param {dw.order.Order} order
 */
function orderUpdated(order) {
    handleExport(order, 'updated');
}

exports.created = orderCreated;
exports.updated = orderUpdated;
