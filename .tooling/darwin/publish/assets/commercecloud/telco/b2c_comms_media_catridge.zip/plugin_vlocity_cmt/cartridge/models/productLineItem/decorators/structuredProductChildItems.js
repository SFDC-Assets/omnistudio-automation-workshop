/* eslint-disable require-jsdoc */
'use strict';

function getProductStructure(apiProduct) {
    var ProductStructure = require('~/cartridge/scripts/models/productStructure');
    var productStructure = new ProductStructure(apiProduct.custom.vlocity_cmt_productHierarchy);
    return productStructure;
}

function getChildLineItemsMap(parentItem) {
    var lineItemCtnr = parentItem.lineItemCtnr;
    var map = {};
    var parentUUID = parentItem.UUID;

    lineItemCtnr.productLineItems.toArray().forEach(function (lineItem) {
        if (lineItem.custom.vlocity_cmt_parentItemUUID === parentUUID) {
            var childPath = lineItem.custom.vlocity_cmt_productHierarchyPath;
            map[childPath] = lineItem;
        }
    });

    return map;
}

function getChildProductDetails(childNode, matchingLineItem) {
    var attributes;
    if (matchingLineItem) {
        var attributesStr = matchingLineItem.custom.vlocity_cmt_attributes;
        if (attributesStr) {
            attributes = JSON.parse(attributesStr);
        }
    }

    return {
        productCode: childNode.ProductCode,
        displayName: childNode.Name,
        lineItem: matchingLineItem,
        isLeaf: true,
        product: childNode.getProduct({
            pview: 'productLineItem',
            pid: matchingLineItem.productID,
            lineItem: matchingLineItem,
            quantity: matchingLineItem.quantityValue
        }),
        attributes: attributes
    };
}

function appendChildItems(productStructureNode, lineItemsStructure, childLineItemsMap) {
    if (productStructureNode && Array.isArray(productStructureNode.childProducts)) {
        productStructureNode.childProducts.forEach(function (directChild) {
            if (directChild.productHierarchyPath in childLineItemsMap) {
                var matchingLineItem = childLineItemsMap[directChild.productHierarchyPath];
                var childProductDetails = getChildProductDetails(directChild, matchingLineItem);

                lineItemsStructure.children.push(childProductDetails);

                appendChildItems(directChild, lineItemsStructure, childLineItemsMap);
            }
        });
    }

    if (productStructureNode && Array.isArray(productStructureNode.productGroups)) {
        productStructureNode.productGroups.forEach(function (group) {
            if (Array.isArray(group.childProducts)) {
                var groupDetails = null;
                group.childProducts.forEach(function (groupChild) {
                    if (groupChild.productHierarchyPath in childLineItemsMap) {
                        groupDetails = groupDetails || {
                            productCode: group.ProductCode,
                            displayName: group.Name,
                            isGroup: true,
                            children: []
                        };

                        var matchingLineItem = childLineItemsMap[groupChild.productHierarchyPath];
                        var childProductDetails = getChildProductDetails(groupChild, matchingLineItem);

                        groupDetails.children.push(childProductDetails);

                        appendChildItems(groupChild, lineItemsStructure, childLineItemsMap);
                    }
                });

                if (groupDetails) {
                    lineItemsStructure.children.push(groupDetails);
                }
            }
        });
    }
}

function getChildProductLineItems(lineItem) {
    var apiProduct = lineItem.product;
    var childLineItemsMap = getChildLineItemsMap(lineItem);

    var productStructure = getProductStructure(apiProduct);
    var lineItemsStructure = {
        children: []
    };

    appendChildItems(productStructure, lineItemsStructure, childLineItemsMap);

    return lineItemsStructure;
}

module.exports = function (object, lineItem) {
    Object.defineProperty(object, 'hasChildren', {
        enumerable: true,
        writable: false,
        value: true
    });

    Object.defineProperty(object, 'childProductLineItems', {
        enumerable: true,
        value: getChildProductLineItems(lineItem)
    });
};
