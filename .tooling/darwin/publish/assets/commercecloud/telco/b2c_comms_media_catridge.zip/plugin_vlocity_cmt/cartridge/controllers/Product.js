'use strict';

var server = require('server');
server.extend(module.superModule);

server.replace('Variation', function (req, res, next) {
    var productHelper = require('*/cartridge/scripts/helpers/productHelpers');
    var priceHelper = require('*/cartridge/scripts/helpers/pricing');
    var ProductFactory = require('*/cartridge/scripts/factories/product');
    var renderTemplateHelper = require('*/cartridge/scripts/renderTemplateHelper');

    var params = req.querystring;
    var product = ProductFactory.get(params);

    var context = {
        price: product.price
    };

    product.price.html = priceHelper.renderHtml(priceHelper.getHtmlContext(context));

    var attributeContext = { product: { attributes: product.attributes } };
    var attributeTemplate = 'product/components/attributesPre';
    product.attributesHtml = renderTemplateHelper.getRenderedHtml(
        attributeContext,
        attributeTemplate
    );

    var promotionsContext = { product: { promotions: product.promotions } };
    var promotionsTemplate = 'product/components/promotions';

    product.promotionsHtml = renderTemplateHelper.getRenderedHtml(
        promotionsContext,
        promotionsTemplate
    );

    var optionsContext = { product: { options: product.options } };
    var optionsTemplate = 'product/components/options';

    product.optionsHtml = renderTemplateHelper.getRenderedHtml(
        optionsContext,
        optionsTemplate
    );

    res.json({
        product: product,
        resources: productHelper.getResources()
    });

    next();
});

server.post('FetchPrices', function (req, res, next) {
    var productHelper = require('*/cartridge/scripts/helpers/productHelpers');
    var priceHelper = require('*/cartridge/scripts/helpers/pricing');
    var ProductFactory = require('*/cartridge/scripts/factories/product');
    var renderTemplateHelper = require('*/cartridge/scripts/renderTemplateHelper');
    var vlocityProductHelper = require('int_vlocity_cmt').productHelper;
    var vlocityParameterHelper = require('*/cartridge/scripts/helpers/vlocity/customParameterHelper');
    var productStructure;

    var productId = req.form.pid;
    if (req.form.currentProductStructure) {
        productStructure = JSON.parse(req.form.currentProductStructure);
    }

    var params = {
        pid: productId,
        quantity: req.form.quantity
    };

    var product = ProductFactory.get(params);

    var fetchedPrices;

    // two different stream for price updates depending on whether its a standard product or a product bundle
    if (product.productType) {
        var vlocityProduct = vlocityProductHelper.getProduct(product.id);
        var customerContext = vlocityParameterHelper.getURLParametersAsString();

        var quantity = product.selectedQuantity;
        var getOfferDetailsResponse = vlocityProductHelper.getOfferDetails(vlocityProduct, customerContext);

        var getConfiguredOfferResponse = vlocityProductHelper.getConfiguredOfferDetails(getOfferDetailsResponse, vlocityProduct, quantity, customerContext, productStructure);
        fetchedPrices = getConfiguredOfferResponse.offerDetails.offer.priceResult;

        for (var i = 0; i < fetchedPrices.length; i++) {
            if (fetchedPrices[i].ChargeType__c === 'Recurring' && product.price.recurringPrice) {
                // reset prices
                product.price.recurringPrice.value = 0;
                product.price.recurringPrice.decimalPrice = 0;
                product.price.recurringPrice.formatted = 0;

                product.price.recurringPrice.value = fetchedPrices[i].RecurringTotal__c;
                product.price.recurringPrice.decimalPrice = fetchedPrices[i].RecurringTotal__c;
                product.price.recurringPrice.formatted = fetchedPrices[i].RecurringTotal__c;
            } else if (fetchedPrices[i].ChargeType__c === 'One-time' && product.price.initialPrice) {
                // reset prices
                product.price.initialPrice.value = 0;
                product.price.initialPrice.decimalPrice = 0;
                product.price.initialPrice.formatted = 0;

                product.price.initialPrice.value = fetchedPrices[i].OneTimeTotal__c;
                product.price.initialPrice.decimalPrice = fetchedPrices[i].OneTimeTotal__c;
                product.price.initialPrice.formatted = fetchedPrices[i].OneTimeTotal__c;
            } else {
                // if the product doesnt have price info populated
                product.price.sales.value = fetchedPrices[i].chargeamount;
                product.price.sales.decimalPrice = fetchedPrices[i].chargeamount;
                product.price.sales.formatted = fetchedPrices[i].chargeamount;
            }
        }
    }

    var context = {
        price: product.price
    };

    product.price.html = priceHelper.renderHtml(priceHelper.getHtmlContext(context));

    var attributeContext = { product: { attributes: product.attributes } };
    var attributeTemplate = 'product/components/attributesPre';
    product.attributesHtml = renderTemplateHelper.getRenderedHtml(
        attributeContext,
        attributeTemplate
    );

    res.json({
        product: product,
        resources: productHelper.getResources()
    });

    next();
});

module.exports = server.exports();

