/* eslint-disable require-jsdoc */
'use strict';
var base = module.superModule;

/**
 * @constructor
 * @classdesc CartModel class that represents the current basket
 *
 * @param {dw.order.Basket} basket - Current users's basket
 */
function CartModel(basket) {
    base.call(this, basket);
    var allAssetLines;
    if (basket && 'vlocity_cmt_assetContext' in basket.custom && !empty(basket.custom.vlocity_cmt_assetContext)) {
        allAssetLines = JSON.parse(basket.custom.vlocity_cmt_assetContext);
    }
    this.assetLines = allAssetLines;
    if (this.assetLines && !this.numItems) {
        this.numItems = this.assetLines.length;
    } else if (this.assetLines && this.numItems) {
        this.numItems = this.numItems + this.assetLines.length;
    }
}
module.exports = CartModel;
