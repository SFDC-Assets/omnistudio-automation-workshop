'use strict';

var base = module.superModule;

base.productStructure = require('*/cartridge/models/product/decorators/productStructure');
base.bundleQuantities = require('*/cartridge/models/product/decorators/bundleQuantities');
base.price = require('*/cartridge/models/product/decorators/price');

module.exports = base;
