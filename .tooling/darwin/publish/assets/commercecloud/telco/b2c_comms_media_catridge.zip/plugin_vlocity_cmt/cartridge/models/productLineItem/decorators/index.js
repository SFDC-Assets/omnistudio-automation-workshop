'use strict';

var base = module.superModule;

base.structuredProductChildItems = require('*/cartridge/models/productLineItem/decorators/structuredProductChildItems');

module.exports = base;
