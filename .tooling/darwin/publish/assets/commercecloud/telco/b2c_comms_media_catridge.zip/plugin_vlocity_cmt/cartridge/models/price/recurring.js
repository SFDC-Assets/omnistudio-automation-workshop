/* eslint-disable valid-jsdoc */
/* eslint-disable require-jsdoc */
'use strict';

var Money = require('dw/value/Money');
var formatMoney = require('dw/util/StringUtils').formatMoney;

/**
 * Convert API price to an object
 * @param {dw.value.Money} price - Price object returned from the API
 * @returns {Object} price formatted as a simple object
 */
function toPriceModel(price, frequency) {
    var value = price.available ? price.getDecimalValue().get() : null;
    var currency = price.available ? price.getCurrencyCode() : null;
    var formattedPrice = price.available ? formatMoney(price) : null;
    var decimalPrice;

    if (formattedPrice) { decimalPrice = price.getDecimalValue().toString(); }

    return {
        value: value,
        currency: currency,
        formatted: formattedPrice,
        decimalPrice: decimalPrice,
        frequency: frequency
    };
}

function RecurringPrice(priceModel) {
    var priceInfo = priceModel && priceModel.priceInfo && priceModel.priceInfo.priceInfo;

    if (priceInfo) {
        priceInfo = JSON.parse(priceInfo);
        this.recurringFrequency = priceInfo.recurring;
        var recurringPrice;

        if (priceInfo.price) {
            recurringPrice = new Money(priceInfo.price, priceModel.price.currencyCode);
        } else {
            recurringPrice = new Money(0, priceModel.price.currencyCode);
        }

        this.recurringPrice = toPriceModel(recurringPrice, priceInfo.frequency);
    }

    this.type = 'recurring';
    this.initialPrice = toPriceModel(priceModel.price);
}

RecurringPrice.isPriceRecurring = function (priceModel) {
    return priceModel && priceModel.priceInfo && priceModel.priceInfo.priceInfo;
};

module.exports = RecurringPrice;
