/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./cartridges/plugin_vlocity_cmt/cartridge/client/default/js/product/productStructure.js");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./cartridges/plugin_vlocity_cmt/cartridge/client/default/js/product/productStructure.js":
/*!***********************************************************************************************!*\
  !*** ./cartridges/plugin_vlocity_cmt/cartridge/client/default/js/product/productStructure.js ***!
  \***********************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

/* eslint-disable require-jsdoc */
/* global structuredProductData */

/**
 * Makes a call to the server to report the event of adding an item to the cart
 *
 * @param {string | boolean} url - a string representing the end point to hit so that the event can be recorded, or false
 */
function miniCartReportingUrl(url) {
    if (url) {
        $.ajax({
            url,
            method: 'GET',
            success() {
                // reporting urls hit on the server
            },
            error() {
                // no reporting urls hit on the server
            },
        });
    }
}

/**
 * Updates the Mini-Cart quantity value after the customer has pressed the "Add to Cart" button
 * @param {string} response - ajax response from clicking the add to cart button
 */
function handlePostCartAdd(response) {
    $('.minicart').trigger('count:update', response);
    const messageType = response.error ? 'alert-danger' : 'alert-success';

    if ($('.add-to-cart-messages').length === 0) {
        $('body').append(
            '<div class="add-to-cart-messages"></div>'
        );
    }

    $('.add-to-cart-messages').append(
        `<div class="alert ${messageType} add-to-basket-alert text-center" role="alert">${
         response.message
         }</div>`
    );

    setTimeout(() => {
        $('.add-to-basket-alert').remove();
    }, 5000);
}

function updateItemPrices(input, selectedQuantity) {
    const $input = $(input);
    let calculatedInitialPrice = 0;
    let calculatedRecurringPrice = 0;
    let selectedQty = selectedQuantity;

    if (typeof selectedQty === 'undefined') {
        selectedQty = input.checked ? 1 : 0;
    }

    if (selectedQty > 0) {
        const initialPrice = parseFloat($input.data('initialPrice'));
        const recurringPrice = parseFloat($input.data('recurringPrice'));
        calculatedInitialPrice = initialPrice * selectedQty;
        calculatedRecurringPrice = recurringPrice * selectedQty;
    }

    $input.data('calculatedInitialPrice', calculatedInitialPrice);
    $input.data('calculatedRecurringPrice', calculatedRecurringPrice);
}

// function to handle the variant response
function handleVariantBundleConfig(response, $productContainer) {
    // need a function to update the attribute and subsequently processNonSwatchValues
    const variationAttributes = response.product.variationAttributes;
    if (variationAttributes) {
        variationAttributes.forEach(attribute => {
            attribute.values.forEach(attributeValue => {
                const $test = `[data-attr-value="${attributeValue.value}"]`;
                const $attributeValue = $productContainer.find($test);
                $attributeValue.attr('value', attributeValue.url).removeAttr('disabled');

                if (!attributeValue.selectable) {
                    $attributeValue.attr('disabled', true);
                }
            });
        });
        $productContainer.find('.product-sku').text(response.product.id);
    }

    // retrieve the first product-availability element
    const $bundleProductAvailability = $('.product-availability:first');

    $('button.js-add-structured-product-to-cart').trigger('product:updateStructuredAddToCart', {
        product: response.product,
        childProducts: structuredProductData.productStructure.childProducts,
        $bundleProductAvailability,
    });
}

// function to make the ajax call
function ajaxBundleCall(selectedValueUrl, $productContainer) {
    $('body').trigger('product:beforeAttributeSelect', {
        url: selectedValueUrl,
        container: $productContainer,
    });

    // finding the min max and default cardinality for child product
    const minQuantity = $productContainer.data('minquantity');
    const maxQuantity = $productContainer.data('maxquantity');
    const defaultQuantity = $productContainer.data('defaultquantity');

    // adding new param to the url inBundle to identify the product, if the param is true we leverage the new quantities decorator
    if (selectedValueUrl !== 'null') {
        const myUrl = new URL(selectedValueUrl);
        const searchParams = myUrl.searchParams;
        searchParams.set('inBundle', true);
        searchParams.set('minQuantity', minQuantity);
        searchParams.set('maxQuantity', maxQuantity);
        searchParams.set('defaultQuantity', defaultQuantity);

        $.ajax({
            url: myUrl,
            method: 'GET',
            success(data) {
            // handle variant response method
                handleVariantBundleConfig(data, $productContainer);
            // updateQuantityTest(data.product.quantities, $productContainer);
                $.spinner().stop();
            },
            error() {
                $.spinner().stop();
            },
        });
    } else {
        $.spinner().stop();
    }
}

// function to retrieve the child record via productHierarchy path
function getChildRecordByPath(productStructure, childPath, attrId, attrValue, quantity) {
    if (!Array.isArray(productStructure.childProducts)) {
        return null;
    }

    for (let i = 0; i < productStructure.childProducts.length; i++) {
        let childProduct = productStructure.childProducts[i];
        if (childProduct.productHierarchyPath === childPath) {
            // loop through the attibute categories
            if (childProduct.AttributeCategory) {
                for (let j = 0; j < childProduct.AttributeCategory.records.length; j++) {
                    const attrCategoryRecord = childProduct.AttributeCategory.records[j];

                    if (attrCategoryRecord.productAttributes.records) {
                        // loop through product attributes
                        for (let w = 0; w < attrCategoryRecord.productAttributes.records.length; w++) {
                            const productAttrRecord = attrCategoryRecord.productAttributes.records[w];
                            if (productAttrRecord.code === attrId) {
                                // overriding the user value to whats been passed in
                                productAttrRecord.userValues = attrValue;
                            }
                        }
                    }
                }
            }

            childProduct.Quantity = quantity;
            return productStructure;
        }

        childProduct = getChildRecordByPath(childProduct, childPath, attrId, attrValue, quantity);
        if (childProduct) {
            return childProduct;
        }
    }

    return null;
}

// function to update the structuredProduct --> productStructure
function updateProductStructure(value) {
    const productPath = value.parents('div[class^="product-path"]').data('path');
    const attrId = value[0].id;
    let attrValue = value.find('option:selected').data('attr-value');
    let quantity = value.find(':selected').val();

    // if the attrValue is coming from an input field
    if (attrValue == null) {
        attrValue = value.val();
    } else if (!attrValue) {
        attrValue = 'default';
    }


    // if the attribute has been reverted back to the select state
    if (attrValue === 'default') {
        attrValue = null;
    }

    // check to see if quantity is a number or not
    if (isNaN(quantity)) {
        // if it standard i.e check box .. default is 1
        const checkbox = value.closest('.product-path').find('.js-leaf-checkbox');
        quantity = value.closest('.product-path').find('.bundle-quantity-select :selected').val();

        const currentClass = value.attr('class');
        const booleanCheck = currentClass.includes('js-leaf-checkbox');


        if (booleanCheck && !quantity && checkbox.prop('checked')) {
            value.closest('.product-path').find('.input-bundle-field').prop('disabled', false);
            quantity = 1;
        } else if (booleanCheck && !quantity && !checkbox.prop('checked')) {
            // if unchecked disable all the input fields
            value.closest('.product-path').find('.input-bundle-field').prop('disabled', true);

            quantity = 0;
        } else if ((booleanCheck || currentClass.includes('input-bundle-field')) && checkbox.prop('checked')) {
            quantity = 1;
        } else if ((booleanCheck || currentClass.includes('input-bundle-field')) && !checkbox.prop('checked')) {
            if (!quantity) {
                quantity = 0;
            }
        }
    }

    const productStructure = structuredProductData.productStructure;

    getChildRecordByPath(productStructure, productPath, attrId, attrValue, parseInt(quantity, 10));
}

// function to find the products in the bundle that have been configured
function findAddToCartProducts(allProducts) {
    for (let i = 0; i < allProducts.length; i++) {
        const quantity = $(allProducts[i]).find('.bundle-quantity-select :selected').val();
        const standardSelect = $(allProducts[i]).find('.js-leaf-checkbox:checked').length;

        const chosenProduct = {
            productId: '',
            quantity: '',
            childProductPath: '',
        };

        if (quantity > 0 || standardSelect > 0) {
            // this product has been chosen, append to array
            chosenProduct.productId = $(allProducts[i]).find('.product-sku').first().text();
            chosenProduct.quantity = parseInt(quantity || standardSelect, 10);
            chosenProduct.childProductPath = $(allProducts[i]).data('path');

            structuredProductData.addToCart.push(chosenProduct);
        }
    }
}

function enableStructuredAddToCartCheck(childProducts) {
    for (let i = 0; i < childProducts.length; i++) {
        const childProduct = childProducts[i];

        if (childProduct.Quantity < childProduct.minQuantity || childProduct.Quantity > childProduct.maxQuantity) {
            return false;
        }

        // check if its a master variant product that has required
        if (childProduct.Quantity > 0 && childProduct.AttributeCategory) {
            // find the AttributeCategoryRecords (loop through them)
            for (let x = 0; x < childProduct.AttributeCategory.records.length; x++) {
                const attrCategoryRecord = childProduct.AttributeCategory.records[x];

                if (attrCategoryRecord.productAttributes) {
                    // find the productAttributes (loop through them)
                    for (let z = 0; z < attrCategoryRecord.productAttributes.records.length; z++) {
                        const productAttrRecord = attrCategoryRecord.productAttributes.records[z];
                        if ((productAttrRecord.required) && (productAttrRecord.userValues === null || productAttrRecord.userValues === '')) {
                            return false;
                        }
                    }
                }
            }
        }

        if (childProduct.childProducts && !enableStructuredAddToCartCheck(childProduct.childProducts)) {
            return false;
        }
    }

    return true;
}

module.exports.init = function () {
    // check to see if a variant configuration has been done i.e select attribute
    $(document).on('change', 'select[class*="selectBundle-"]', e => {
        e.preventDefault();
        const $jqObject = $(e.target);
        const $productContainer = $jqObject.closest('.leaf');
        // make the ajax call to sfcc
        ajaxBundleCall(e.currentTarget.value, $productContainer);

        // make the updates to the structuredProduct --> productStructure
        updateProductStructure($(e.target));
    });

    // check to see if input field has changed to update the product structure
    $(document).on('change', 'input[class*="input-bundle-field"]', e => {
        // make the updates to the structuredProduct --> productStructure
        updateProductStructure($(e.target));
        const enable = enableStructuredAddToCartCheck(structuredProductData.productStructure.childProducts);
        $('button.js-add-structured-product-to-cart').prop('disabled', !enable);
    });

    // check to see if quantity has been changed
    $(document).on('change', '.bundle-quantity-select', e => {
        updateProductStructure($(e.target));
        const enable = enableStructuredAddToCartCheck(structuredProductData.productStructure.childProducts);
        $('button.js-add-structured-product-to-cart').prop('disabled', !enable);
    });

    $(document).on('change', '.js-leaf-quantity-select', e => {
        const $this = $(e.target);
        $this.data('selectedQuantity', $this.val() === '0' ? 1 : $this.val());

        const closestInput = $this.parent('.leaf').find('input')[0];

        if (closestInput && closestInput.type === 'checkbox') {
            const selectedQuantity = parseInt(this.value, 10);

            if (selectedQuantity > 0) {
                if (!closestInput.checked) {
                    closestInput.checked = true;
                }
                updateItemPrices(closestInput, selectedQuantity);
            } else if (selectedQuantity === 0 && closestInput.checked) {
                closestInput.checked = false;
                updateItemPrices(closestInput, selectedQuantity);
            }
        }

        const enable = enableStructuredAddToCartCheck(structuredProductData.productStructure.childProducts);
        $('button.js-add-structured-product-to-cart').prop('disabled', !enable);
    });

    $(document).on('change', '.js-leaf-checkbox', e => {
        const $quantitySelect = $(this).parent().find('.js-leaf-quantity-select');

        if ($quantitySelect.length) {
            const selectedQuantity = parseInt($quantitySelect.val(), 10);

            if (this.checked && selectedQuantity === 0) {
                const savedValue = $quantitySelect.data('selectedQuantity');
                $quantitySelect.val(savedValue || 1);
            } else if (!this.checked && selectedQuantity > 0) {
                $quantitySelect.val(0);
            }

            updateItemPrices(this, parseInt($quantitySelect.val(), 10));
        } else {
            updateItemPrices(this);
        }

        updateProductStructure($(e.target));
        const enable = enableStructuredAddToCartCheck(structuredProductData.productStructure.childProducts);
        $('button.js-add-structured-product-to-cart').prop('disabled', !enable);
    });

    $(document).on('click', '.js-add-structured-product-to-cart', function () {
        structuredProductData.addToCart = [];
        // finding all products within the bundle
        const bundleProducts = $(document.getElementsByClassName('product-path'));

        // method that finds all the selected products and appends them to the addToCart array
        findAddToCartProducts(bundleProducts);

        const $this = $(this);
        const productId = $('.product-detail:not(".bundle-item")').data('pid');
        // const quantity = 1;
        let quantity = $('.product-detail').find('.quantity-select').val();
        if (!quantity) {
            // for bundle products that dont have quantity selector, default to 1
            quantity = 1;
        }

        const addToCartUrl = $this.data('addToCartUrl');

        $('body').trigger('product:beforeAddToCart', this);

        const form = {
            pid: productId,
            quantity,
            structuredProductData: JSON.stringify(structuredProductData),
        };

        if (addToCartUrl) {
            $.ajax({
                url: addToCartUrl,
                method: 'POST',
                data: form,
                success(data) {
                    handlePostCartAdd(data);
                    $('body').trigger('product:afterAddToCart', data);
                    $.spinner().stop();
                    miniCartReportingUrl(data.reportingURL);
                },
                error() {
                    $.spinner().stop();
                },
            });
        }
    });

    $(document).on('click', '.js-update-structured-product', function () {
        structuredProductData.addToCart = [];
        // finding all products within the bundle
        const bundleProducts = $(document.getElementsByClassName('product-path'));

        // method that finds all the selected products and appends them to the addToCart array
        findAddToCartProducts(bundleProducts);

        const $this = $(this);
        const productId = $('.product-detail:not(".bundle-item")').data('pid');
        const uuid = $this.data('lineUuid');

        let quantity = $('.product-detail').find('.quantity-select').val();
        if (!quantity) {
            // for bundle products that dont have quantity selector, default to 1
            quantity = 1;
        }

        const updateStructuredProductUrl = $this.data('updateStructuredProductUrl');

        const form = {
            pid: productId,
            quantity,
            structuredProductData: JSON.stringify(structuredProductData),
            uuid,
        };

        $('body').trigger('product:beforeAddToCart', this);

        $.ajax({
            url: updateStructuredProductUrl,
            method: 'POST',
            data: form,
            success(data) {
                if (data.redirectURL) {
                    window.location.href = data.redirectURL;
                } else {
                    handlePostCartAdd(data);
                    $('body').trigger('product:afterAddToCart', data);
                    $.spinner().stop();
                }
            },
            error() {
                $.spinner().stop();
            },
        });
    });

    $('body').on('product:updateStructuredAddToCart', (e, response) => {
        const bundleProductAvailable = response.$bundleProductAvailability.data('readyToOrder') && response.$bundleProductAvailability.data('available');

        const enable = bundleProductAvailable && enableStructuredAddToCartCheck(response.childProducts);

        $('button.js-add-structured-product-to-cart').prop('disabled', !enable);
    });

    $('body').on('product:updateAddToCart', () => {
        let enable = $('.product-availability').toArray().every(item =>
            $(item).data('available') && $(item).data('ready-to-order')
        );

        enable = enable && enableStructuredAddToCartCheck(structuredProductData.productStructure.childProducts);

        $('button.js-add-structured-product-to-cart').prop('disabled', !enable);
    });
};


/***/ })

/******/ });
//# sourceMappingURL=productStructure.js.map