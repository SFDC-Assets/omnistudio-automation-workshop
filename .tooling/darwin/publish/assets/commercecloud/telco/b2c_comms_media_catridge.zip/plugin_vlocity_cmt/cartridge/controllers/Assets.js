'use strict';

var server = require('server');
var Resource = require('dw/web/Resource');
var URLUtils = require('dw/web/URLUtils');
var userLoggedIn = require('*/cartridge/scripts/middleware/userLoggedIn');
var consentTracking = require('*/cartridge/scripts/middleware/consentTracking');
var vlocityParameterHelper = require('int_vlocity_cmt').customParameterHelper;
// var vlocityCustomerHelper = require('int_vlocity_cmt').customerHelper;
var Site = require('dw/system/Site');
var DCAPI_NAMESPACE = Site.current.getCustomPreferenceValue('vlocity_cmt_NamespaceForDCAPI');
var DCAPI = require('int_vlocity_cmt').VlocityService.DCAPI;
var Logger = require('dw/system/Logger');

server.get(
    'History',
    consentTracking.consent,
    server.middleware.https,
    userLoggedIn.validateLoggedIn,
    function (req, res, next) {
        try {
            var assetFilter = req.querystring.assetFilter;
            var currentCustomer = req.currentCustomer;
            var currencyCode = req.session.currency.symbol;
            var filterDate = '';
            if (assetFilter === '6') {
                filterDate = new Date(Date.now() - 15778476000);// SIX_MONTHS_AGO
            } else if (assetFilter === '12') {
                filterDate = new Date(Date.now() - 31556952000);// YEAR_AGO
            } else if (assetFilter === '1') {
                filterDate = new Date(Date.now() - 2638461600);// past month
            }
            var pageSize = Site.current.getCustomPreferenceValue('vlocity_cmt_AssetListSize');
            var includes = 'noContractAssets';
            var effectiveAssetsDateFilter = !empty(filterDate) ? filterDate.toISOString() : '';
            var currentCustomerId = currentCustomer.raw.profile.custom.vlocity_cmt_accountId;
            if (!currentCustomerId) {
                throw Resource.msg('cannot.find.customer', 'asset', null);
            }

            var queryString = {};

            if (pageSize || includes || effectiveAssetsDateFilter) {
            // endpoint+='?';
                if (!empty(pageSize)) {
                    queryString.pagesize = pageSize;
                } else {
                    queryString.pageSize = 10;
                }
                if (!empty(includes)) {
                    queryString.includes = includes;
                }
                if (!empty(effectiveAssetsDateFilter)) {
                    queryString.effectiveAssetsDateFilter = effectiveAssetsDateFilter;
                }
                // --By Default assets created in  last 30 days
                if (empty(effectiveAssetsDateFilter)) {
                    queryString.effectiveAssetsDateFilter = new Date(Date.now() - 2638461600).toISOString();
                }
            }
            var apiResponse = DCAPI.getAssets(currentCustomerId, queryString);

            var filterValues = [
                {
                    displayValue: Resource.msg('text.last.thirty.days', 'asset', null),
                    optionValue: URLUtils.url('Assets-History', 'assetFilter', '1').abs().toString()
                },
                {
                    displayValue: Resource.msg('text.last.six.months', 'asset', null),
                    optionValue: URLUtils.url('Assets-History', 'assetFilter', '6').abs().toString()
                },
                {
                    displayValue: Resource.msg('text.last.twelve.months', 'asset', null),
                    optionValue: URLUtils.url('Assets-History', 'assetFilter', '12').abs().toString()
                }
            ];
            var breadcrumbs = [
                {
                    htmlValue: Resource.msg('global.home', 'common', null),
                    url: URLUtils.home().toString()
                },
                {
                    htmlValue: Resource.msg('page.title.myaccount', 'account', null),
                    url: URLUtils.url('Account-Show').toString()
                }
            ];
            var assets = apiResponse.result.object.responseObj.records;

            if (effectiveAssetsDateFilter) {
                res.render('account/asset/assetList', {
                    assets: assets,
                    orgNameSpace: DCAPI_NAMESPACE,
                    currencyCode: currencyCode,
                    filterValues: filterValues,
                    assetFilter: req.querystring.assetFilter,
                    accountlanding: false
                });
            } else {
                res.render('account/asset/history', {
                    assets: assets,
                    orgNameSpace: DCAPI_NAMESPACE,
                    filterValues: filterValues,
                    currencyCode: currencyCode,
                    assetFilter: req.querystring.assetFilter,
                    accountlanding: false,
                    breadcrumbs: breadcrumbs
                });
            }
        } catch (e) {
            Logger.error(e);
            res.setStatusCode(500);
            res.json({
                error: true,
                errorMessage: Resource.msg('error.technical ' + e, 'modifyOrder', null),
                redirectUrl: URLUtils.url('Account-History').toString() });
        }
        next();
    }
);

server.get(
    'AssetToOrder',
    consentTracking.consent,
    server.middleware.https,
    userLoggedIn.validateLoggedIn,
    function (req, res, next) {
        try {
            var vlocityProductHelper = require('int_vlocity_cmt').productHelper;
            var vlocityAssetHelper = require('int_vlocity_cmt').assetHelper;
            var BasketMgr = require('dw/order/BasketMgr');
            var assetId = req.querystring.assetID;
            var productId = req.querystring.productId;
            var catalogCode = vlocityProductHelper.getCatalogCode(productId);
            if (!catalogCode) {
                Logger.getLogger('vlocity.asset').debug('Catalog code missing for asset with ID ' +
                assetId);
                throw Resource.msg('cannot.modify.asset' + productId, 'asset', null);
            }
            var currentDate = new Date(Date.now());
            var customerContext = vlocityParameterHelper.getURLParametersAsString();
           // var customerContext = vlocityCustomerHelper.getCustomerContext(req.currentCustomer.raw);
            var currentOrNewBasket = BasketMgr.getCurrentOrNewBasket();
            var currentValidBasket = BasketMgr.getCurrentBasket();

            if (currentValidBasket.allProductLineItems.length) {
                throw Resource.msg('basket.exists', 'asset', null);
            }
            if (!customerContext) {
                throw Resource.msg('cannot.find.customer', 'asset', null);
            }
            var reqBody = {};
            reqBody.basketAction = 'AssetToBasket';
            reqBody.rootAssetIds = '' + assetId + '';
            reqBody.requestDateTime = currentDate.toISOString();

            Logger.getLogger('vlocity.asset').debug('****** Endpoint from Asset to basket requestBody ' + JSON.stringify(reqBody));
            var apiResponse = DCAPI.createAssetBasket(reqBody, catalogCode, customerContext);

            if (!apiResponse) {
                throw Resource.msg('assetToBasket.request.failed', 'asset', null);
            }
            if (apiResponse.errorCode && apiResponse.errorCode === 'INVOKE-500') {
                throw Resource.msg('assetToBasket.request.failed' + apiResponse.error, 'asset', null);
            }
            if (apiResponse) {
                if (!apiResponse.result || !apiResponse.result.records) {
                    throw apiResponse;
                }
                Logger.getLogger('vlocity.asset').debug('*****CartContextKey for Asset to Basket*****' + apiResponse.cartContextKey);
                var allAssetLinesItems = apiResponse.result.records;

                if (!allAssetLinesItems.length) {
                    throw Resource.msg('no.records.returned ', 'asset', null);
                }

                if (currentOrNewBasket && apiResponse) {
                    vlocityAssetHelper.updateAssetContext(apiResponse, currentOrNewBasket);
                }

                res.json({
                    error: false,
                    redirectUrl: URLUtils.url('Cart-Show').toString()
                });
            }
        } catch (e) {
            res.json({
                error: true,
                errorMessage: Resource.msg(e, 'asset', null),
                redirectUrl: URLUtils.url('Account-History').toString()

            });
        }
        next();
    }
);

module.exports = server.exports();

