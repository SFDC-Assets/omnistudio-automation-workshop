

const processInclude = require('base/util');

$(document).ready(() => {
    processInclude(require('./product/detail'));
    processInclude(require('./product/productStructure'));
});
