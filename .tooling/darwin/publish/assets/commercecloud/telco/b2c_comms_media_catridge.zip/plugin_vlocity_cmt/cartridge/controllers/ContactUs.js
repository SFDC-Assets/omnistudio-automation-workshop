'use strict';

var server = require('server');
var Site = require('dw/system/Site');
var OMNISCRIPT_NAME = Site.current.getCustomPreferenceValue('vlocity_cmt_ContactUsOmniScript');
server.extend(module.superModule);

server.replace('Landing', function (req, res, next) {
    var omnioutHelper = require('*/cartridge/scripts/omniout/omnioutHelper');

    if (omnioutHelper.isOmniOutPage(OMNISCRIPT_NAME)) {
        res.render('vlocity/omniout/page', { sid: OMNISCRIPT_NAME });
        this.done(req, res);
        return;
    }

    next();
});

module.exports = server.exports();
