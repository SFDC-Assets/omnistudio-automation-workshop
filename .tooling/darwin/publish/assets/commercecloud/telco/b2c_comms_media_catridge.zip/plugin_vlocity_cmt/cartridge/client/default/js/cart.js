

const processInclude = require('base/util');

$(document).ready(() => {
    processInclude(require('./cart/cart'));
});
