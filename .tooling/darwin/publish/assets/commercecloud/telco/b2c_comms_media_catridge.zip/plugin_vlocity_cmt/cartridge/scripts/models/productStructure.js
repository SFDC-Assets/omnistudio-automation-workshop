/* eslint-disable no-underscore-dangle */
/* eslint-disable require-jsdoc */
'use strict';

function ProductStructure(source) {
    var src = source;

    if (typeof source === 'string') {
        src = JSON.parse(src);
    } else if (!src || typeof src !== 'object') {
        return;
    }

    this._type = 'productStructure';

    var self = this;
    Object.keys(src).forEach(function (key) {
        self[key] = src[key];
    });

    if (Array.isArray(src.childProducts)) {
        for (var i = 0; i < src.childProducts.length; i++) {
            var child = src.childProducts[i];
            this.childProducts[i] = new ProductStructure(child);
        }
    }

    if (Array.isArray(src.productGroups)) {
        for (var k = 0; k < src.productGroups.length; k++) {
            var productGroup = src.productGroups[k];

            if (Array.isArray(productGroup.childProducts)) {
                for (var j = 0; j < productGroup.childProducts.length; j++) {
                    var productGroupChild = productGroup.childProducts[j];
                    productGroup.childProducts[j] = new ProductStructure(productGroupChild);
                }
            }
        }
    }

    Object.defineProperty(this, 'isLeaf', {
        enumerable: true,
        get: function () {
            return !this.childProducts || !this.childProducts.length;
        }
    });
}

ProductStructure.prototype.getAllAttributes = function () {
    var attributes = {};

    if (this.AttributeCategory && Array.isArray(this.AttributeCategory.records)) {
        this.AttributeCategory.records.forEach(function (attrCategory) {
            if (attrCategory.productAttributes && Array.isArray(attrCategory.productAttributes.records)) {
                attrCategory.productAttributes.records.forEach(function (attribute) {
                    attributes[attribute.code] = attribute.userValues;
                });
            }
        });
    }

    return attributes;
};

ProductStructure.prototype.getProduct = function (params) {
    var productFactoryParams = params;

    if (!productFactoryParams) {
        var ProductMgr = require('dw/catalog/ProductMgr');
        var apiProduct = ProductMgr.getProduct(this.ProductCode);

        if (apiProduct) {
            productFactoryParams = { pid: this.ProductCode };

            if (apiProduct.master) {
                var attributesMap = this.getAllAttributes();

                if (Object.keys(attributesMap).length) {
                    var productHelper = require('int_vlocity_cmt').productHelper;
                    var variant = productHelper.getSelectedVariant(apiProduct, attributesMap);

                    if (variant) {
                        productFactoryParams = { pid: variant.ID };
                    }
                }
            }
        }
    }

    if (productFactoryParams) {
        var ProductFactory = require('*/cartridge/scripts/factories/product');
        var product = ProductFactory.get(productFactoryParams);
        return product;
    }

    return null;
};

module.exports = ProductStructure;
