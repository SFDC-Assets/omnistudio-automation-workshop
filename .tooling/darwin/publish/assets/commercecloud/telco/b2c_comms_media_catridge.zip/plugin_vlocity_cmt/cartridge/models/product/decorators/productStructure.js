'use strict';

module.exports = function (object, apiProduct) {
    Object.defineProperty(object, 'isStructuredProduct', {
        enumerable: true,
        get: function () {
            return 'vlocity_cmt_productHierarchy' in apiProduct.custom && !empty(apiProduct.custom);
        }
    });

    Object.defineProperty(object, 'productStructure', {
        enumerable: true,
        value: (function () {
            if ('vlocity_cmt_productHierarchy' in apiProduct.custom) {
                var ProductStructure = require('~/cartridge/scripts/models/productStructure');
                var productStructure = new ProductStructure(apiProduct.custom.vlocity_cmt_productHierarchy);
                return productStructure;
            }
            return null;
        }())
    });
};
