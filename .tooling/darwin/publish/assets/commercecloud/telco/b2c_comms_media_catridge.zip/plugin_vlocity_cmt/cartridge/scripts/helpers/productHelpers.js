/* eslint-disable require-jsdoc */
'use strict';

var base = module.superModule;

var showProductPageBase = base.showProductPage;

function getDefaultStructuredProductRenderingTemplate() {
    var Site = require('dw/system/Site');

    return Site.current.getCustomPreferenceValue('vlocity_cmt_defaultStructuredProductRenderingTemplate');
}

function showProductPage(querystring, reqPageMetaData) {
    var result = showProductPageBase(querystring, reqPageMetaData);
    var product = result.product;

    if (product && !product.template && product.isStructuredProduct) {
        var defaultTemplate = getDefaultStructuredProductRenderingTemplate();
        if (defaultTemplate) {
            result.template = defaultTemplate;
        }
    }

    return result;
}

base.showProductPage = showProductPage;

module.exports = base;
