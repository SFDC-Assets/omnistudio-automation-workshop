/* eslint-disable require-jsdoc */


const scrollAnimate = function (element) {
    const position = element && element.length ? element.offset().top : 0;
    $('html, body').animate({
        scrollTop: position,
    }, 500);
    if (!element) {
        $('.logo-home').focus();
    }
};

function printMessage(errorMsg) {
    const errorHtml = `${'<div class="alert alert-danger alert-dismissible ' +
                    'fade show" role="alert">' +
                    '<button type="button" class="close" data-dismiss="alert" aria-label="Close">' +
                    '<span aria-hidden="true">&times;</span>' +
                    '</button>'}${errorMsg}</div>`;
    $('.error-message-text').append(errorHtml);
}

$('body').on('change', '.asset-history-select', (e) => {
    $('.error-message-text').text('');
    const $assetsContainer = $('.asset-list-container');
    $.spinner().start();
    $.ajax({
        url: e.currentTarget.value,
        method: 'GET',
        success(data) {
            $assetsContainer.html(data);
            $.spinner().stop();
        },
        error(err) {
            if (err.responseJSON.redirectUrl) {
                window.location.href = err.responseJSON.redirectUrl;
            }
            $.spinner().stop();
        },
    });
});

$('.modifyAsset').on('click', function (e) {
    $.spinner().start();
    $('.modifyAsset').prop('disabled', true);
    const url = this.href;
    $('.error-message-text').text('');
    $.ajax({
        url,
        method: 'GET',
        success(data) {
            if (!data.error) {
                $.spinner().stop();
                $('.modifyAsset').prop('disabled', false);
                location.href = data.redirectUrl;
            } else {
                $.spinner().stop();
                e.preventDefault();
                const errorMsg = data.errorMessage;
                printMessage(errorMsg);
                scrollAnimate($('.error-message-text'));
            }
        },
        error(data) {
            $.spinner().stop();
            e.preventDefault();
            const errorMsg = data.errorMessage;
            printMessage(errorMsg);
            scrollAnimate($('.error-message-text'));
        },
    });
    return false;
});


$(document).ready(() => {
    $('.error-message-text').text('');
});

