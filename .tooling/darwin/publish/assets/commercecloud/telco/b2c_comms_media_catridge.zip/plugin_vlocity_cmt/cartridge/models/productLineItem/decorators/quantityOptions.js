/* eslint-disable require-jsdoc */
'use strict';

function getMinMaxQuantityOptions() {
    return {
        minOrderQuantity: 1,
        maxOrderQuantity: 99
    };
}

module.exports = function (object, productLineItem, quantity) {
    Object.defineProperty(object, 'quantityOptions', {
        enumerable: true,
        value: getMinMaxQuantityOptions(productLineItem, quantity)
    });
};
