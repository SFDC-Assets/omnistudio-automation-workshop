/* eslint-disable require-jsdoc */
'use strict';
var base = module.superModule;

function OrderModel(lineItemContainer, options) {
    base.call(this, lineItemContainer, options);
    var allAssetLines;
    if (lineItemContainer && 'vlocity_cmt_assetContext' in lineItemContainer.custom && !empty(lineItemContainer.custom.vlocity_cmt_assetContext)) {
        allAssetLines = JSON.parse(lineItemContainer.custom.vlocity_cmt_assetContext);
    }
    this.assetLines = allAssetLines;
    // use this only if there is vlocity assets
    if (this.assetLines && this.assetLines.length) {
        if (this.items) {
            if (this.items.totalQuantity) {
                this.items.totalQuantity = this.items.totalQuantity + this.assetLines.length;
            } else {
                this.items.totalQuantity = this.assetLines.length;
            }
        } else {
            this.items = {};
            this.items.totalQuantity = this.assetLines.length;
        }
    }
}
module.exports = OrderModel;
