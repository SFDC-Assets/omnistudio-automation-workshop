/* eslint-disable require-jsdoc */
'use strict';

var server = require('server');
var LOGGER = require('dw/system/Logger');
var csrfProtection = require('*/cartridge/scripts/middleware/csrf');
var consentTracking = require('*/cartridge/scripts/middleware/consentTracking');

server.extend(module.superModule);

server.prepend('AddProduct', function (req, res, next) {
    var vlocityBasketHelper = require('int_vlocity_cmt').basketHelper;
    var productId = req.form.pid;
    var quantity = req.form.quantity;
    var addProductResult;
    quantity = parseInt(quantity, 10);
    quantity = isNaN(quantity) ? 1 : quantity;

    try {
        addProductResult = vlocityBasketHelper.addProduct(productId, quantity);
    } catch (e) {
        LOGGER.error('Add to Vlocity Basket failed: ' + e);
        res.setStatusCode(500);
        res.json({
            error: true,
            message: 'Failed to add product to Vlocity Basket',
            errorMessage: '' + e
        });
        this.done(req, res);
        return;
    }

    this.on('route:BeforeComplete', function (req, res) { // eslint-disable-line no-shadow
        var viewData = res.getViewData();
        vlocityBasketHelper.saveLineItemDetails(viewData.pliUUID, addProductResult);
    });

    next();
});

server.replace(
    'Show',
    server.middleware.https,
    consentTracking.consent,
    csrfProtection.generateToken,
    function (req, res, next) {
        var BasketMgr = require('dw/order/BasketMgr');
        var Transaction = require('dw/system/Transaction');
        var CartModel = require('*/cartridge/models/cart');
        var cartHelper = require('*/cartridge/scripts/cart/cartHelpers');
        var reportingUrlsHelper = require('*/cartridge/scripts/reportingUrls');
        var basketCalculationHelpers = require('*/cartridge/scripts/helpers/basketCalculationHelpers');
        var vlocityBasketHelper = require('int_vlocity_cmt').basketHelper;

        var currentBasket = BasketMgr.getCurrentBasket();
        var reportingURLs;

        if (currentBasket) {
            vlocityBasketHelper.checkBasketDetails(currentBasket);

            Transaction.wrap(function () {
                if (currentBasket.currencyCode !== req.session.currency.currencyCode) {
                    currentBasket.updateCurrency();
                }
                cartHelper.ensureAllShipmentsHaveMethods(currentBasket);

                basketCalculationHelpers.calculateTotals(currentBasket);
            });
        }

        if (currentBasket && currentBasket.allLineItems.length) {
            reportingURLs = reportingUrlsHelper.getBasketOpenReportingURLs(currentBasket);
        }

        res.setViewData({ reportingURLs: reportingURLs });

        var basketModel = new CartModel(currentBasket);
        res.render('cart/cart', basketModel);
        next();
    }
);

server.prepend('UpdateQuantity', function (req, res, next) {
    var vlocityBasketHelper = require('int_vlocity_cmt').basketHelper;

    var updateQuantity = parseInt(req.querystring.quantity, 10);
    var updatedLineItemUUID = req.querystring.uuid;

    try {
        vlocityBasketHelper.updateLineQuantity(updatedLineItemUUID, updateQuantity);
    } catch (e) {
        LOGGER.error('Update product in Vlocity Basket failed: ' + e);
        res.setStatusCode(500);
        res.json({
            error: true,
            message: 'Failed to update product in Vlocity Basket',
            errorMessage: '' + e
        });
        this.done(req, res);
        return;
    }

    next();
});

server.replace('MiniCartShow', function (req, res, next) {
    var BasketMgr = require('dw/order/BasketMgr');
    var Transaction = require('dw/system/Transaction');
    var CartModel = require('*/cartridge/models/cart');
    var cartHelper = require('*/cartridge/scripts/cart/cartHelpers');
    var reportingUrlsHelper = require('*/cartridge/scripts/reportingUrls');
    var basketCalculationHelpers = require('*/cartridge/scripts/helpers/basketCalculationHelpers');
    var vlocityBasketHelper = require('int_vlocity_cmt').basketHelper;

    var currentBasket = BasketMgr.getCurrentBasket();
    var reportingURLs;

    if (currentBasket) {
        vlocityBasketHelper.checkBasketDetails(currentBasket);

        Transaction.wrap(function () {
            if (currentBasket.currencyCode !== req.session.currency.currencyCode) {
                currentBasket.updateCurrency();
            }
            cartHelper.ensureAllShipmentsHaveMethods(currentBasket);
            basketCalculationHelpers.calculateTotals(currentBasket);
        });
    }

    if (currentBasket && currentBasket.allLineItems.length) {
        reportingURLs = reportingUrlsHelper.getBasketOpenReportingURLs(currentBasket);
    }

    res.setViewData({ reportingURLs: reportingURLs });

    var basketModel = new CartModel(currentBasket);

    res.render('checkout/cart/miniCart', basketModel);
    next();
});

server.replace('MiniCart', server.middleware.include, function (req, res, next) {
    var BasketMgr = require('dw/order/BasketMgr');
    var ProductLineItemsModel = require('*/cartridge/models/productLineItems');

    var currentBasket = BasketMgr.getCurrentBasket();
    var quantityTotal;

    if (currentBasket) {
        quantityTotal = ProductLineItemsModel.getTotalQuantity(currentBasket.productLineItems);
        if (currentBasket.custom.vlocity_cmt_assetContext) {
            quantityTotal += 1;// We have only one asset in cart at a time in basket
        }
    } else {
        quantityTotal = 0;
    }

    res.render('/components/header/miniCart', { quantityTotal: quantityTotal });
    next();
});

server.replace('RemoveProductLineItem', function (req, res, next) {
    var BasketMgr = require('dw/order/BasketMgr');
    var Resource = require('dw/web/Resource');
    var Transaction = require('dw/system/Transaction');
    var URLUtils = require('dw/web/URLUtils');
    var CartModel = require('*/cartridge/models/cart');
    var basketCalculationHelpers = require('*/cartridge/scripts/helpers/basketCalculationHelpers');

    var currentBasket = BasketMgr.getCurrentBasket();

    if (!currentBasket) {
        res.setStatusCode(500);
        res.json({
            error: true,
            redirectUrl: URLUtils.url('Cart-Show').toString()
        });

        return next();
    }

    var vlocityBasketHelper = require('int_vlocity_cmt').basketHelper;
    try {
        vlocityBasketHelper.removeLine(req.querystring.uuid);
    } catch (e) {
        LOGGER.error('Delete from Vlocity Basket failed: ' + e);
        res.setStatusCode(500);
        res.json({
            error: true,
            message: 'Failed to delete product in Vlocity Basket',
            errorMessage: '' + e
        });
        this.done(req, res);
        return null;
    }

    var isProductLineItemFound = false;
    var bonusProductsUUIDs = [];

    Transaction.wrap(function () {
        if (req.querystring.pid && req.querystring.uuid) {
            var productLineItems = currentBasket.getAllProductLineItems(req.querystring.pid);
            var bonusProductLineItems = currentBasket.bonusLineItems;
            var mainProdItem;
            for (var i = 0; i < productLineItems.length; i++) {
                var item = productLineItems[i];
                if ((item.UUID === req.querystring.uuid)) {
                    if (bonusProductLineItems && bonusProductLineItems.length > 0) {
                        for (var j = 0; j < bonusProductLineItems.length; j++) {
                            var bonusItem = bonusProductLineItems[j];
                            mainProdItem = bonusItem.getQualifyingProductLineItemForBonusProduct();
                            if (mainProdItem !== null &&
                                (mainProdItem.productID === item.productID)) {
                                bonusProductsUUIDs.push(bonusItem.UUID);
                            }
                        }
                    }

                    vlocityBasketHelper.removeChildLineItems(currentBasket, req.querystring.uuid);

                    var shipmentToRemove = item.shipment;
                    currentBasket.removeProductLineItem(item);
                    if (shipmentToRemove.productLineItems.empty && !shipmentToRemove.default) {
                        currentBasket.removeShipment(shipmentToRemove);
                    }
                    isProductLineItemFound = true;
                    break;
                }
            }
        }
        basketCalculationHelpers.calculateTotals(currentBasket);
    });

    if (isProductLineItemFound) {
        var basketModel = new CartModel(currentBasket);
        var basketModelPlus = {
            basket: basketModel,
            toBeDeletedUUIDs: bonusProductsUUIDs
        };
        res.json(basketModelPlus);
    } else {
        res.setStatusCode(500);
        res.json({ errorMessage: Resource.msg('error.cannot.remove.product', 'cart', null) });
    }

    if (currentBasket.productQuantityTotal === 0) {
        vlocityBasketHelper.disconnectBasket();
    }

    return next();
});

server.post('AddStructuredProduct', function (req, res, next) {
    var Transaction = require('dw/system/Transaction');
    var BasketMgr = require('dw/order/BasketMgr');
    var Resource = require('dw/web/Resource');
    var CartModel = require('*/cartridge/models/cart');
    var ProductLineItemsModel = require('*/cartridge/models/productLineItems');
    var cartHelper = require('*/cartridge/scripts/cart/cartHelpers');
    var basketCalculationHelpers = require('*/cartridge/scripts/helpers/basketCalculationHelpers');

    var currentBasket = BasketMgr.getCurrentOrNewBasket();

    var productId = req.form.pid;
    var quantity = req.form.quantity;
    var structuredProductDataStr = req.form.structuredProductData;

    var structuredProductData;
    try {
        structuredProductData = JSON.parse(structuredProductDataStr);
    } catch (e) {
        res.json({
            error: true,
            message: e
        });
        return next();
    }

    var productStructure = structuredProductData.productStructure;
    var childProducts = structuredProductData.addToCart;

    var vlocityBasketHelper = require('int_vlocity_cmt').basketHelper;

    var result = {
        error: false,
        message: Resource.msg('text.alert.addedtobasket', 'product', null)
    };
    try {
        Transaction.begin();

        var newLineItemUUID = vlocityBasketHelper.addStructuredProduct(productId, quantity, productStructure, childProducts);

        cartHelper.ensureAllShipmentsHaveMethods(currentBasket);
        basketCalculationHelpers.calculateTotals(currentBasket);

        result.uuid = newLineItemUUID;

        Transaction.commit();
    } catch (e) {
        Transaction.rollback();
        res.json({
            error: true,
            message: '' + e
        });
        return next();
    }

    var quantityTotal = ProductLineItemsModel.getTotalQuantity(currentBasket.productLineItems);
    var cartModel = new CartModel(currentBasket);

    var reportingURL = cartHelper.getReportingUrlAddToCart(currentBasket, result.error);

    res.json({
        reportingURL: reportingURL,
        quantityTotal: quantityTotal,
        message: result.message,
        cart: cartModel,
        newBonusDiscountLineItem: {},
        error: result.error,
        pliUUID: result.uuid,
        minicartCountOfItems: Resource.msgf('minicart.count', 'common', null, quantityTotal)
    });

    return next();
});

server.post('UpdateStructuredProduct', function (req, res, next) {
    var URLUtils = require('dw/web/URLUtils');
    var Transaction = require('dw/system/Transaction');

    var productId = req.form.pid;
    var quantity = req.form.quantity;
    var lineItemUUID = req.form.uuid;
    var structuredProductDataStr = req.form.structuredProductData;

    var structuredProductData;
    try {
        structuredProductData = JSON.parse(structuredProductDataStr);
    } catch (e) {
        res.json({
            error: true,
            message: e
        });
        return next();
    }

    var productStructure = structuredProductData.productStructure;
    var childProducts = structuredProductData.addToCart;

    var vlocityBasketHelper = require('int_vlocity_cmt').basketHelper;

    try {
        Transaction.begin();

        vlocityBasketHelper.updateStructuredProduct(lineItemUUID, productId, quantity, productStructure, childProducts);

        Transaction.commit();
    } catch (e) {
        Transaction.rollback();
        res.json({
            error: true,
            message: '' + e
        });
        return next();
    }

    res.json({
        error: false,
        redirectURL: URLUtils.url('Cart-Show').toString()
    });

    return next();
});

server.replace('EditProductLineItem', function (req, res, next) {
    var BasketMgr = require('dw/order/BasketMgr');
    var ProductMgr = require('dw/catalog/ProductMgr');
    var Resource = require('dw/web/Resource');
    var URLUtils = require('dw/web/URLUtils');
    var Transaction = require('dw/system/Transaction');
    var CartModel = require('*/cartridge/models/cart');
    var collections = require('*/cartridge/scripts/util/collections');
    var cartHelper = require('*/cartridge/scripts/cart/cartHelpers');
    var basketCalculationHelpers = require('*/cartridge/scripts/helpers/basketCalculationHelpers');

    var currentBasket = BasketMgr.getCurrentBasket();

    if (!currentBasket) {
        res.setStatusCode(500);
        res.json({
            error: true,
            redirectUrl: URLUtils.url('Cart-Show').toString()
        });
        return next();
    }

    var uuid = req.form.uuid;
    var productId = req.form.pid;
    var selectedOptionValueId = req.form.selectedOptionValueId;
    var updateQuantity = parseInt(req.form.quantity, 10);

    var productLineItems = currentBasket.allProductLineItems;
    var requestLineItem = collections.find(productLineItems, function (item) {
        return item.UUID === uuid;
    });

    var uuidToBeDeleted = null;
    var pliToBeDeleted;
    var newPidAlreadyExist = collections.find(productLineItems, function (item) {
        if (item.productID === productId && item.UUID !== uuid) {
            uuidToBeDeleted = item.UUID;
            pliToBeDeleted = item;
            updateQuantity += parseInt(item.quantity, 10);
            return true;
        }
        return false;
    });

    var availableToSell = 0;
    var totalQtyRequested = 0;
    var qtyAlreadyInCart = 0;
    var minOrderQuantity = 0;
    var canBeUpdated = false;
    var perpetual = false;
    var bundleItems;

    if (requestLineItem) {
        if (requestLineItem.product.bundle) {
            bundleItems = requestLineItem.bundledProductLineItems;
            canBeUpdated = collections.every(bundleItems, function (item) {
                var quantityToUpdate = updateQuantity *
                    requestLineItem.product.getBundledProductQuantity(item.product).value;
                qtyAlreadyInCart = cartHelper.getQtyAlreadyInCart(
                    item.productID,
                    productLineItems,
                    item.UUID
                );
                totalQtyRequested = quantityToUpdate + qtyAlreadyInCart;
                availableToSell = item.product.availabilityModel.inventoryRecord.ATS.value;
                perpetual = item.product.availabilityModel.inventoryRecord.perpetual;
                minOrderQuantity = item.product.minOrderQuantity.value;
                return (totalQtyRequested <= availableToSell || perpetual) &&
                    (quantityToUpdate >= minOrderQuantity);
            });
        } else {
            availableToSell = requestLineItem.product.availabilityModel.inventoryRecord.ATS.value;
            perpetual = requestLineItem.product.availabilityModel.inventoryRecord.perpetual;
            qtyAlreadyInCart = cartHelper.getQtyAlreadyInCart(
                productId,
                productLineItems,
                requestLineItem.UUID
            );
            totalQtyRequested = updateQuantity + qtyAlreadyInCart;
            minOrderQuantity = requestLineItem.product.minOrderQuantity.value;
            canBeUpdated = (totalQtyRequested <= availableToSell || perpetual) &&
                (updateQuantity >= minOrderQuantity);
        }
    }

    var error = false;
    if (canBeUpdated) {
        var product = ProductMgr.getProduct(productId);

        var vlocityBasketHelper = require('int_vlocity_cmt').basketHelper;
        vlocityBasketHelper.updateLineProduct(requestLineItem, product, updateQuantity);

        try {
            Transaction.wrap(function () {
                if (newPidAlreadyExist) {
                    var shipmentToRemove = pliToBeDeleted.shipment;
                    currentBasket.removeProductLineItem(pliToBeDeleted);
                    if (shipmentToRemove.productLineItems.empty && !shipmentToRemove.default) {
                        currentBasket.removeShipment(shipmentToRemove);
                    }
                }

                if (!requestLineItem.product.bundle) {
                    requestLineItem.replaceProduct(product);
                }

                // If the product has options
                var optionModel = product.getOptionModel();
                if (optionModel && optionModel.options && optionModel.options.length) {
                    var productOption = optionModel.options.iterator().next();
                    var productOptionValue = optionModel.getOptionValue(productOption, selectedOptionValueId);
                    var optionProductLineItems = requestLineItem.getOptionProductLineItems();
                    var optionProductLineItem = optionProductLineItems.iterator().next();
                    optionProductLineItem.updateOptionValue(productOptionValue);
                }

                requestLineItem.setQuantityValue(updateQuantity);
                basketCalculationHelpers.calculateTotals(currentBasket);
            });
        } catch (e) {
            error = true;
        }
    }

    if (!error && requestLineItem && canBeUpdated) {
        var cartModel = new CartModel(currentBasket);

        var responseObject = {
            cartModel: cartModel,
            newProductId: productId
        };

        if (uuidToBeDeleted) {
            responseObject.uuidToBeDeleted = uuidToBeDeleted;
        }

        res.json(responseObject);
    } else {
        res.setStatusCode(500);
        res.json({
            errorMessage: Resource.msg('error.cannot.update.product', 'cart', null)
        });
    }

    return next();
});

server.post('AddProductToAsset', function (req, res, next) {
    var URLUtils = require('dw/web/URLUtils');
    var BasketMgr = require('dw/order/BasketMgr');
    var currentBasket = BasketMgr.getCurrentBasket();
    var vlocityBasketHelper = require('int_vlocity_cmt').basketHelper;
    var basketCalculationHelpers = require('*/cartridge/scripts/helpers/basketCalculationHelpers');

    // var bundleContextKey = req.querystring.bundleContextKey;
    // var parentLineItemKey = req.querystring.parentLineItemKey;
    // var parentHierarchyPath = req.querystring.parentHierarchyPath;
    // var primaryCatalogCode = req.querystring.primaryCatalogCode;
    // var offer = req.querystring.offer;

    var bundleContextKey = req.form.addBundleContextKey;
    var parentLineItemKey = req.form.parentLineItemKey;
    var parentHierarchyPath = req.form.parentHierarchyPath;
    var primaryCatalogCode = req.form.primaryCatalogCode;
    var offer = req.form.offer;

    if (!currentBasket) {
        res.setStatusCode(500);
        res.json({
            error: true,
            redirectUrl: URLUtils.url('Cart-Show').toString()
        });

        return next();
    }

    var userInput = {
        bundleContextKey: bundleContextKey,
        parentLineItemKey: parentLineItemKey,
        parentHierarchyPath: parentHierarchyPath,
        primaryCatalogCode: primaryCatalogCode,
        offer: offer
    };
    try {
        vlocityBasketHelper.addProductToAsset(userInput);
        basketCalculationHelpers.calculateTotals(currentBasket);
        var CartModel = require('*/cartridge/models/cart');
        var basketModel = new CartModel(currentBasket);
        res.json({
            basketModel: basketModel,
            redirectUrl: URLUtils.url('Cart-Show').toString() }
            );
    } catch (e) {
        LOGGER.error('Add priduct to  asset failed: ' + e);
        res.setStatusCode(500);
        res.json({
            error: true,
            message: 'Cannot Add product',
            errorMessage: '' + e,
            redirectUrl: URLUtils.url('Cart-Show').toString()
        });
    }
    return next();
});

server.post('GetAsset', function (req, res, next) {
    var Resource = require('dw/web/Resource');
    var URLUtils = require('dw/web/URLUtils');
    var ProductFactory = require('*/cartridge/scripts/factories/product');
    var renderTemplateHelper = require('*/cartridge/scripts/renderTemplateHelper');
    var reqProdCode = req.querystring.ProductCode;
    var reqAssetCode = req.querystring.assetID;
    var bundleContextKey = req.form.bundleContextKey;
    var lineItemKey = req.form.lineItemKey;
    var primaryCatalogCode = req.form.primaryCatalogCode;
    var vlocityAttributeCategories = JSON.parse(req.form.attrCategories);

    var requestQuantity = null;

    var pliProduct = {
        pid: reqProdCode,
        quantity: requestQuantity,
        options: null
    };

    var context = {
        product: ProductFactory.get(pliProduct),
        selectedQuantity: requestQuantity,
        selectedOptionValueId: null,
        assetID: reqAssetCode,
        bundleContextKey: bundleContextKey,
        lineItemKey: lineItemKey,
        vlocityAttributeCategories: vlocityAttributeCategories,
        primaryCatalogCode: primaryCatalogCode,
        updateCartUrl: URLUtils.url('Cart-EditAssetLineItem'),
        closeButtonText: Resource.msg('link.editProduct.close', 'cart', null),
        enterDialogMessage: Resource.msg('msg.enter.edit.product', 'cart', null),
        template: 'asset/quickView.isml'
    };

    res.setViewData(context);

    this.on('route:BeforeComplete', function (req, res) { // eslint-disable-line no-shadow
        var viewData = res.getViewData();

        res.json({
            renderedTemplate: renderTemplateHelper.getRenderedHtml(viewData, viewData.template)
        });
    });

    next();
});
server.post('EditAssetLineItem', function (req, res, next) {
    var BasketMgr = require('dw/order/BasketMgr');
    var Resource = require('dw/web/Resource');
    var URLUtils = require('dw/web/URLUtils');
    var CartModel = require('*/cartridge/models/cart');
    var basketCalculationHelpers = require('*/cartridge/scripts/helpers/basketCalculationHelpers');
    var currentBasket = BasketMgr.getCurrentBasket();
    var vlocityBasketHelper = require('int_vlocity_cmt').basketHelper;
    try {
        if (!currentBasket) {
            res.setStatusCode(500);
            res.json({
                error: true,
                redirectUrl: URLUtils.url('Cart-Show').toString()
            });
            return next();
        }
        var productId = req.form.pid;
        var bundleContextKey = req.form.bundleContextKey;
        var lineItemKey = req.form.lineItemKey;
        var primaryCatalogCode = req.form.primaryCatalogCode;
        var vlocityAttributeCategories = JSON.parse(req.form.vlocityAttributeCategories);

        var vlocityProductHelper = require('int_vlocity_cmt').productHelper;
        var currentSelectedProduct = vlocityProductHelper.getProduct(productId);
        if (!currentSelectedProduct.variant) {
            throw Resource.msg('nothing.to.change', 'asset', null);
        }
        var userInput = {};
        userInput.product = currentSelectedProduct;// User Selected product
        userInput.bundleContextKey = bundleContextKey;
        userInput.lineItemKey = lineItemKey;
        userInput.vlocityAttributeCategories = vlocityAttributeCategories;// Vlocity Attributes
        userInput.primaryCatalogCode = primaryCatalogCode;

        vlocityBasketHelper.updateAssetLine(userInput);
        basketCalculationHelpers.calculateTotals(currentBasket);
        var basketModel = new CartModel(currentBasket);
        res.json({
            basketModel: basketModel,
            redirectUrl: URLUtils.url('Cart-Show').toString() }
            );
    } catch (e) {
        res.setStatusCode(500);
        res.json({
            errorMessage: Resource.msg('error.cannot.update.asset ' + e, 'asset', null)
        });
    }

    return next();
});

server.post('RemoveAssetLineItem', function (req, res, next) {
    var BasketMgr = require('dw/order/BasketMgr');
    var currentBasket = BasketMgr.getCurrentBasket();
    var CartModel = require('*/cartridge/models/cart');
    var URLUtils = require('dw/web/URLUtils');
    var Resource = require('dw/web/Resource');
    var vlocityBasketHelper = require('int_vlocity_cmt').basketHelper;
    var bundleContextKey = req.form.bundleContextKey;
    var lineItemKey = req.form.lineItemKey;
    var primaryCatalogCode = req.form.primaryCatalogCode;

    if (!currentBasket) {
        res.setStatusCode(500);
        res.json({
            error: true,
            redirectUrl: URLUtils.url('Cart-Show').toString()
        });

        return next();
    }
    var userInput = {
        lineItemKey: lineItemKey,
        bundleContextKey: bundleContextKey,
        primaryCatalogCode: primaryCatalogCode
    };
    try {
        vlocityBasketHelper.removeAssetLine(userInput);
    } catch (e) {
        LOGGER.error('Delete asset from Vlocity Basket failed: ' + e);
        res.setStatusCode(500);
        res.json({
            error: true,
            message: Resource.msg('error.cannot.remove.asset', 'cart', null),
            errorMessage: '' + e
        });
        this.done(req, res);
        return null;
    }
    currentBasket = BasketMgr.getCurrentBasket();

    var basketModel = new CartModel(currentBasket);
    var basketModelAfter = {
        basket: basketModel,
        redirectUrl: URLUtils.url('Cart-Show').toString(),
        assetsTobeDeleted: []
    };

    res.json(basketModelAfter);

    return next();
});

function getProductLineItemByUUID(basket, lineItemUUID) {
    for (var i = 0; i < basket.productLineItems.length; i++) {
        var pli = basket.productLineItems[i];

        if (pli.UUID === lineItemUUID) {
            return pli;
        }
    }

    return null;
}

function getRawProductStructure(productLineItem) {
    var savedProductDetails = productLineItem.custom.vlocity_cmt_prodDetailResult;

    if (savedProductDetails) {
        var parsed = JSON.parse(savedProductDetails);

        return {
            childProducts: parsed.offerDetails.offer.childProducts,
            productGroups: parsed.offerDetails.offer.productGroups
        };
    }

    return null;
}

server.get('EditStructuredProduct', function (req, res, next) {
    var lineItemUUID = req.querystring.uuid;

    var BasketMgr = require('dw/order/BasketMgr');
    var currentBasket = BasketMgr.getCurrentBasket();

    if (!currentBasket) {
        var URLUtils = require('dw/web/URLUtils');
        res.redirect(URLUtils.url('Cart-Show'));
        return next();
    }

    var editedLineItem = getProductLineItemByUUID(currentBasket, lineItemUUID);
    var productID = editedLineItem.productID;

    req.querystring.pid = productID;

    var productHelper = require('*/cartridge/scripts/helpers/productHelpers');
    var showProductPageHelperResult = productHelper.showProductPage({ pid: productID, quantity: editedLineItem.quantityValue }, req.pageMetaData);

    var productType = showProductPageHelperResult.product.productType;
    if (!showProductPageHelperResult.product.online && productType !== 'set' && productType !== 'bundle') {
        res.setStatusCode(404);
        res.render('error/notFound');
    } else {
        var rawProductStructure = getRawProductStructure(editedLineItem);
        var productStructure = null;

        if (rawProductStructure) {
            var ProductStructure = require('~/cartridge/scripts/models/productStructure');
            productStructure = new ProductStructure(rawProductStructure);
        }

        res.render(showProductPageHelperResult.template, {
            product: showProductPageHelperResult.product,
            rawProductStructure: JSON.stringify(rawProductStructure),
            productStructure: productStructure,
            isUpdatePage: true,
            lineItemUUID: lineItemUUID,
            resources: showProductPageHelperResult.resources,
            breadcrumbs: showProductPageHelperResult.breadcrumbs,
            canonicalUrl: showProductPageHelperResult.canonicalUrl,
            schemaData: showProductPageHelperResult.schemaData
        });
    }

    return next();
});

module.exports = server.exports();
