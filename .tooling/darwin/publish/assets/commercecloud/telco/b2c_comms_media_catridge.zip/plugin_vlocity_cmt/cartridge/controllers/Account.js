'use strict';

var server = require('server');
var Logger = require('dw/system/Logger');

server.extend(module.superModule);

server.append('SubmitRegistration', function (req, res, next) {
    this.on('route:Complete', function (requ, resp) {
        if (resp.getViewData().authenticatedCustomer) {
            require('dw/system/HookMgr').callHook('app.account.created', 'created', resp.getViewData().authenticatedCustomer);
        }
    });
    next();
});

server.append('SaveProfile', function (req, res, next) {
    this.on('route:Complete', function (requ, resp) { // eslint-disable-line no-unused-vars
        if (requ.currentCustomer.profile) {
            require('dw/system/HookMgr').callHook('app.account.updated', 'updated', requ.currentCustomer.raw);
        }
    });
    next();
});

server.append('Login', function (req, res, next) {
    this.on('route:Complete', function (requ, resp) {
        if (resp.getViewData().authenticatedCustomer) {
            require('dw/system/HookMgr').callHook('app.account.created', 'login', resp.getViewData().authenticatedCustomer);
        }
    });
    next();
});

// append to show rout the account hierarchy data
server.append('Show', function (req, res, next) {
    var traversals;
    var apiNodes;

    var CustomerMgr = require('dw/customer/CustomerMgr');
    var DCAPI = require('int_vlocity_cmt').VlocityService.DCAPI;
    var Site = require('dw/system/Site');
    Site.current.getCustomPreferenceValue('vlocity_cmt_NamespaceForDCAPI');
    var graphId = Site.current.getCustomPreferenceValue('vlocity_cmt_GraphId');

    var finalAccount;

    // fetch vlocity_cmt_accountId of current user
    var currentUser = req.currentCustomer.profile;
    var currentProfile = CustomerMgr.getProfile(currentUser.customerNo);
    var accountId = currentProfile.custom.vlocity_cmt_accountId;

    var requestBody = {
        numberOfDegrees: 3,
        nodesToEval: {
        },
        numberOfNodes: 15
    };
    requestBody.nodesToEval[accountId] = [];

    // make the api call out to
    try {
        var apiResponse = DCAPI.getAccountHierarchy(graphId, requestBody);

        traversals = apiResponse.result.traversals;
        apiNodes = apiResponse.result.nodes;

        var traversalIds = Object.keys(traversals);

    // nodes
        var arrNodes = Object.keys(apiNodes).map(function (key) {
            return apiNodes[key];
        });

        var account = [];

        for (var i = 0; i < traversalIds.length; i++) {
        // loop through arrNodes
            for (var j = 0; j < arrNodes.length; j++) {
            // match between the traversal and node
                if (traversalIds[i] === arrNodes[j].Id) {
                    var accountTraversal = {};
                    accountTraversal.id = arrNodes[j].Id;
                    accountTraversal.name = arrNodes[j].Name;
                    accountTraversal.objType = arrNodes[j].SObjectType;
                    account.push(accountTraversal);
                } else {
                // no match
                }
            }

        // retrieve nodeIds of the oneToMany in Traversals
            var traversalId = traversalIds[i];
            var nodes = [];

            for (var z = 0; z < traversals[traversalId].oneToMany.length; z++) {
                var node = {};
                node.id = traversals[traversalId].oneToMany[z].targetNodeId;
            // loop through nodes array to fetch the name and type
                for (var c = 0; c < arrNodes.length; c++) {
                    if (node.id === arrNodes[c].Id) {
                        node.name = arrNodes[c].Name;
                        node.type = arrNodes[c].SObjectType;
                    }
                }
            // push these nodeId into the account object
                nodes.push(node);
            }
        // loop through account to find correct traversal
            for (var y = 0; y < account.length; y++) {
                if (account[y].id === traversalId) {
                    account[y].nodes = nodes;
                }
            }
        }

    // check if in the accountHierarchy if an account includes another account that has a hierarchy
        for (var g = 0; g < account.length; g++) {
            for (var h = 0; h < account.length; h++) {
            // loop through nodes of that account
                for (var d = 0; d < account[g].nodes.length; d++) {
                    if (account[g].nodes[d].id === account[h].id) {
                        account[g].childAccount = [];
                        account[g].childAccount.push(account[h]);
                    // delete the node
                        account[g].nodes.splice(d, 1);
                    // flag the account that is a child
                        account[h].isChild = true;
                    }
                }
            }
        }
    // delete the account on top level
        finalAccount = account.filter(function (val) { return !val.isChild; });
    } catch (e) {
        var errorMessage = 'Error fetching account hiearchy ' + e.message;
        Logger.error(errorMessage);
    }

    res.setViewData({ accountHierarchy: finalAccount });

    next();
});

module.exports = server.exports();
