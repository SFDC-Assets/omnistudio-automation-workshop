/* eslint-disable require-jsdoc */
/* eslint-disable brace-style */
'use strict';
var server = require('server');
server.extend(module.superModule);
var ArrayList = require('dw/util/ArrayList');
var cache = require('*/cartridge/scripts/middleware/cache');
var consentTracking = require('*/cartridge/scripts/middleware/consentTracking');
var pageMetaData = require('*/cartridge/scripts/middleware/pageMetaData');
var searchHelper = require('*/cartridge/scripts/helpers/searchHelpers');
var Logger = require('dw/system/Logger');

function createSearchReq(req, customerContext) {
    var vlocityProductHelper = require('int_vlocity_cmt').productHelper;

    var catergryId = req.querystring.cgid;

    var augReq = {};
    augReq.host = req.host;
    augReq.httpHeaders = req.httpHeaders;
    augReq.httpMethod = req.httpMethod;
    augReq.path = req.path;
    augReq.setLocale = req.setLocale;
    augReq.includeRequest = req.includeRequest;
    augReq.https = req.https;
    augReq.pageMetaData = req.pageMetaData;
    augReq.querystring = {};
    augReq.querystring.cgid = req.querystring.cgid;
    augReq.querystring.selectedUrl = req.querystring.selectedUrl;
    augReq.querystring.page = req.querystring.page;

    if (req.querystring.pmax) {
        augReq.querystring.pmax = req.querystring.pmax;
    }
    if (req.querystring.pmin) {
        augReq.querystring.pmin = req.querystring.pmin;
    }
    var isRegisteredCustomer = req.currentCustomer && req.currentCustomer.raw && req.currentCustomer.raw.registered;

    var apiResponse = vlocityProductHelper.getCatalogOffers(catergryId, customerContext);

    var eligiOffers = apiResponse.offers;
    var eligibleVlocOffers = [];

    // -------------Offers returned from Digital Commerce APIs----------
    if (eligiOffers && eligiOffers.length) {
        for (var i = 0; i < eligiOffers.length; i++) {
            // ----loggedin user----
            if (isRegisteredCustomer) { // Check with Anchal/Meghana
                if (eligiOffers[i].qualification && eligiOffers[i].qualification.qualificationType === 'Pass') {
                    eligibleVlocOffers.push(eligiOffers[i].ProductCode);
                }
            }
            // -----Guest User----
            else {
                eligibleVlocOffers.push(eligiOffers[i].ProductCode);
            }
        }
        augReq.querystring.pid = new ArrayList(eligibleVlocOffers);
    }
    // --------Vlocity DC API has no offers returned, so we will mask the CC offers---//
    else {
        augReq.querystring.pid = new ArrayList('');
    }

    return augReq;
}

// ----------Controller Code for the Ajax Calls--------------------//
server.replace('ShowAjax', cache.applyShortPromotionSensitiveCache, consentTracking.consent, function (req, res, next) {
    var vlocityParameterHelper = require('int_vlocity_cmt').customParameterHelper;

    var categoryId = req.querystring.cgid;

    try {
        var result;

        var customerContext = vlocityParameterHelper.getURLParametersAsString();

        if (categoryId && customerContext) {
            var augReq = createSearchReq(req, customerContext);
            result = searchHelper.search(augReq, res);
        } else {
            result = searchHelper.search(req, res);
        }
        res.render('search/searchResultsNoDecorator', {
            productSearch: result.productSearch,
            maxSlots: result.maxSlots,
            reportingURLs: result.reportingURLs,
            refineurl: result.refineurl
        });
    } catch (e) {
        var errorMessage = 'Error happened while fetching Vlocity Offers for Category: ' +
                categoryId + '.Reason: ' + e.message;
        Logger.error(errorMessage);
        res.render('error/errorTemplate', { errorMessage: errorMessage, categoryName: categoryId });
    }

    next();
});

server.replace('Show', cache.applyShortPromotionSensitiveCache, consentTracking.consent, function (req, res, next) {
    var vlocityParameterHelper = require('int_vlocity_cmt').customParameterHelper;
    var template = 'search/searchResults';

    var categoryId = req.querystring.cgid;
    try {
        var result;
        var customerContext = vlocityParameterHelper.getURLParametersAsString();

        if (categoryId && customerContext) {
            var augReq = createSearchReq(req, customerContext);
            result = searchHelper.search(augReq, res);
        } else {
            result = searchHelper.search(req, res);
        }

        if (result.searchRedirect) {
            res.redirect(result.searchRedirect);
            return next();
        }
        if (result.category && result.categoryTemplate) {
            template = result.categoryTemplate;
        }
        res.render(template, {
            productSearch: result.productSearch,
            maxSlots: result.maxSlots,
            reportingURLs: result.reportingURLs,
            refineurl: result.refineurl,
            category: result.category ? result.category : null,
            canonicalUrl: result.canonicalUrl,
            schemaData: result.schemaData
        });
    } catch (e) {
        var errorMessage = 'Error fetching Vlocity Offers for Category: ' +
                categoryId + '.Reason: ' + e;
        Logger.error(errorMessage);
        res.render('error/errorTemplate', { errorMessage: errorMessage, categoryName: categoryId });
    }

    return next();
}, pageMetaData.computedPageMetaData);

module.exports = server.exports();
