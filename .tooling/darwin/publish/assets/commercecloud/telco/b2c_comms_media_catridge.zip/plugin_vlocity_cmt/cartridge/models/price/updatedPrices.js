/* eslint-disable valid-jsdoc */
/* eslint-disable require-jsdoc */
'use strict';

var formatMoney = require('dw/util/StringUtils').formatMoney;

function toPriceModel(price, frequency) {
    var value = price;
    var currency = price.available ? price.getCurrencyCode() : null;
    var formattedPrice = price.available ? formatMoney(price) : null;
    var decimalPrice;

    if (formattedPrice) { decimalPrice = price.getDecimalValue().toString(); }

    return {
        value: value,
        currency: currency,
        formatted: formattedPrice,
        decimalPrice: decimalPrice,
        frequency: frequency
    };
}

function UpdatedPrice(lineItem) {
    this.recurringPrice = toPriceModel(lineItem.custom.vlocity_cmt_recurringPrice);
    this.initialPrice = toPriceModel(lineItem.custom.vlocity_cmt_oneTimePrice);
    if (this.recurringPrice) {
        this.type = 'recurring';
    }
}

module.exports = UpdatedPrice;
