'use strict';

var base = module.superModule;
var decorators = require('*/cartridge/models/product/decorators/index');

module.exports = function (product, apiProduct, options, params) {
    var baseProduct = base(product, apiProduct, options);
    decorators.productStructure(baseProduct, apiProduct);
    // check if inBundle param is true, if it is use the bundleQuantities decorator
    if (params.inBundle) {
        // call the bundle quantities decorator
        decorators.bundleQuantities(baseProduct, apiProduct, params);
    }

    return baseProduct;
};
