/* eslint-disable require-jsdoc */
/* global structuredProductData */

/**
 * JS for the update of pricing from vlocity (post config)
 * @param {string} data - the response data from the ajax call
 */
function updatePrice(data) {
    const $priceSelector = $('.prices .price');
    $priceSelector.replaceWith(data.product.price.html);
}

module.exports.init = function () {
    $(document).on('click', '.js-fetch-vlocity-price', () => {
        const fetchPriceUrl = $('.fetch-price-url').val();
        const pid = $('.product-detail').data('pid');
        const quantity = $('.product-detail').find('.quantity-select').val();

        let currentProductStructure;

        if (!(typeof structuredProductData === 'undefined')) {
            currentProductStructure = JSON.stringify(structuredProductData.productStructure);
        }

        const form = {
            pid,
            quantity,
            currentProductStructure,
        };

        if (fetchPriceUrl) {
            $.spinner().start();
            $.ajax({
                url: fetchPriceUrl,
                method: 'POST',
                data: form,
                success(data) {
                    updatePrice(data);
                    $.spinner().stop();
                },
                error() {
                    $.spinner().stop();
                },
            });
        }
    });
};
