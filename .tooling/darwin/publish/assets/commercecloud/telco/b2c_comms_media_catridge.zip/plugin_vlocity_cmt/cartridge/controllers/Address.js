'use strict';

var server = require('server');

server.extend(module.superModule);

server.append('SaveAddress', function (req, res, next) {
    this.on('route:Complete', function (requ, resp) { // eslint-disable-line no-unused-vars
        if (requ.currentCustomer.profile) {
            require('dw/system/HookMgr').callHook('app.account.updated', 'updated', requ.currentCustomer.raw);
        }
    });
    next();
});

server.append('DeleteAddress', function (req, res, next) {
    this.on('route:Complete', function (requ, resp) { // eslint-disable-line no-unused-vars
        if (requ.currentCustomer.profile) {
            require('dw/system/HookMgr').callHook('app.account.updated', 'updated', requ.currentCustomer.raw);
        }
    });
    next();
});

server.append('SetDefault', function (req, res, next) {
    this.on('route:Complete', function (requ, resp) { // eslint-disable-line no-unused-vars
        if (requ.currentCustomer.profile) {
            require('dw/system/HookMgr').callHook('app.account.updated', 'updated', requ.currentCustomer.raw);
        }
    });
    next();
});

module.exports = server.exports();
