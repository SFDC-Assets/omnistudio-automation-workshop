/* eslint-disable require-jsdoc */
'use strict';

var HookMgr = require('dw/system/HookMgr');
var PaymentMgr = require('dw/order/PaymentMgr');
var Transaction = require('dw/system/Transaction');
var OrderMgr = require('dw/order/OrderMgr');
var Order = require('dw/order/Order');
var Status = require('dw/system/Status');

var base = module.superModule;

var ASSET_UPDATE_PRODUCT_ID = 'ASSET_UPDATE';

function fixEmptyBasket(basket) {
    if (!basket.productLineItems.length) {
        Transaction.wrap(function () {
            var pli = basket.createProductLineItem(ASSET_UPDATE_PRODUCT_ID, basket.defaultShipment);
            pli.lineItemText = 'Asset Update';
            pli.productName = 'Asset Update';
            pli.priceValue = 0;
            pli.custom.vlocity_cmt_userQuantity = 1;
            pli.updateTax(0);
        });
    }
}

function removeAssetLineItemFromBasket() {
    var BasketMgr = require('dw/order/BasketMgr');

    var basket = BasketMgr.currentBasket;

    if (!basket) {
        return;
    }

    for (var i = 0; i < basket.productLineItems.length; i++) {
        var pli = basket.productLineItems[i];

        if (pli.productID === ASSET_UPDATE_PRODUCT_ID) {
            // eslint-disable-next-line no-loop-func
            Transaction.wrap(function () {
                basket.removeProductLineItem(pli);
            });
        }
    }
}

function failOrder(order) {
    Transaction.wrap(function () { OrderMgr.failOrder(order, true); });
    removeAssetLineItemFromBasket();
}

/**
 * Attempts to create an order from the current basket
 * @param {dw.order.Basket} currentBasket - The current basket
 * @returns {dw.order.Order} The order object created from the current basket
 */
function createOrder(currentBasket) {
    var vlocityOrderHelper = require('int_vlocity_cmt').orderHelper;

    var order;

    try {
        order = Transaction.wrap(function () {
            var submitOrderResponse = vlocityOrderHelper.submitOrder(currentBasket);
            if (submitOrderResponse.orderNumber) {
                fixEmptyBasket(currentBasket);
                var apiOrder = OrderMgr.createOrder(currentBasket, submitOrderResponse.orderNumber);
                vlocityOrderHelper.updateOrderWithSubmitOrderResponse(apiOrder, submitOrderResponse);
                return apiOrder;
            }
            throw new Error('Failed to create order');
        });
    } catch (error) {
        var Logger = require('dw/system/Logger');
        Logger.error('' + error);
        return null;
    }

    return order;
}

/**
 * handles the payment authorization for each payment instrument
 * @param {dw.order.Order} order - the order object
 * @param {string} orderNumber - The order number for the order
 * @returns {Object} an error object
 */
function handlePayments(order, orderNumber) {
    var result = {};

    if (order.totalNetPrice !== 0.00) {
        var paymentInstruments = order.paymentInstruments;

        if (paymentInstruments.length === 0) {
            failOrder(order);
            result.error = true;
        }

        if (!result.error) {
            for (var i = 0; i < paymentInstruments.length; i++) {
                var paymentInstrument = paymentInstruments[i];
                var paymentProcessor = PaymentMgr
                    .getPaymentMethod(paymentInstrument.paymentMethod)
                    .paymentProcessor;
                var authorizationResult;
                if (paymentProcessor === null) {
                    Transaction.begin();
                    paymentInstrument.paymentTransaction.setTransactionID(orderNumber);
                    Transaction.commit();
                } else {
                    if (HookMgr.hasHook('app.payment.processor.' +
                            paymentProcessor.ID.toLowerCase())) {
                        authorizationResult = HookMgr.callHook(
                            'app.payment.processor.' + paymentProcessor.ID.toLowerCase(),
                            'Authorize',
                            orderNumber,
                            paymentInstrument,
                            paymentProcessor
                        );
                    } else {
                        authorizationResult = HookMgr.callHook(
                            'app.payment.processor.default',
                            'Authorize'
                        );
                    }

                    if (authorizationResult.error) {
                        failOrder(order);
                        result.error = true;
                        break;
                    }
                }
            }
        }
    }

    return result;
}

/**
 * Attempts to place the order
 * @param {dw.order.Order} order - The order object to be placed
 * @param {Object} fraudDetectionStatus - an Object returned by the fraud detection hook
 * @returns {Object} an error object
 */
function placeOrder(order, fraudDetectionStatus) {
    var result = { error: false };

    try {
        Transaction.begin();
        var placeOrderStatus = OrderMgr.placeOrder(order);
        if (placeOrderStatus === Status.ERROR) {
            throw new Error();
        }

        if (fraudDetectionStatus.status === 'flag') {
            order.setConfirmationStatus(Order.CONFIRMATION_STATUS_NOTCONFIRMED);
        } else {
            order.setConfirmationStatus(Order.CONFIRMATION_STATUS_CONFIRMED);
        }

        order.setExportStatus(Order.EXPORT_STATUS_READY);
        Transaction.commit();
    } catch (e) {
        failOrder(order);
        result.error = true;
    }

    return result;
}

base.createOrder = createOrder;
base.handlePayments = handlePayments;
base.placeOrder = placeOrder;
base.removeAssetLineItemFromBasket = removeAssetLineItemFromBasket;

module.exports = base;
