/* eslint-disable valid-jsdoc */
'use strict';

/**
 * @module hooks/account
 */

var LOGGER = require('dw/system/Logger').getLogger('vlocity', 'hooks.account');

/**
 * This method will export the given {customer} details to Vlocity through REST API
 * If the async mode is disabled
 *
 * @param {dw.customer.Customer} customerToSync
 * @param {String} status
 */
function syncCustomerAccount(customerToSync, status) {
    var VlocityContactModel = require('int_vlocity_cmt').ContactModel;
    var vlocityContact = new VlocityContactModel(customerToSync);

    try {
        if (status === 'login' && vlocityContact.getStatus() === VlocityContactModel.STATUS_EXPORTED) {
            return;
        }

        vlocityContact.updateStatus(status);

        var VlocityService = require('int_vlocity_cmt').VlocityService;
        var result = VlocityService.createAccount(vlocityContact);

        if (result.status === 'OK') {
            if (result.object && result.object.responseObj && result.object.responseObj.error === 'OK' && !result.object.isError && !result.object.isAuthError) {
                vlocityContact.updateStatus(VlocityContactModel.STATUS_EXPORTED);
                vlocityContact.updateExternalId(result.object.responseObj.Account_1[0].Id);
                vlocityContact.updateSyncResponseText('Successfully Exported');
            } else {
                vlocityContact.updateSyncResponseText(result.object.responseObj.Account_1[0].UpsertError);
            }
        } else {
            LOGGER.error('Failed to update Vlocity Contact, orrignal error was {0}', result.msg);
            vlocityContact.updateSyncResponseText(result.msg);
        }
    } catch (e) {
        vlocityContact.updateSyncResponseText(e.message);
        LOGGER.error('Error occurred updating Vlocity Contact: {0}', e.message);
        throw e;
    }
}

/**
 * Customer account created
 * @param {dw.customer.Customer} customerToSync
 */
function accountCreated(customerToSync) {
    syncCustomerAccount(customerToSync, 'created');
}

/**
 * Customer account updated
 * @param {dw.customer.Customer} customerToSync
 */
function accountUpdated(customerToSync) {
    syncCustomerAccount(customerToSync, 'updated');
}

/**
 * Customer account login
 * @param {dw.customer.Customer} customerToSync
 */
function accountLoggedIn(customerToSync) {
    syncCustomerAccount(customerToSync, 'login');
}

exports.created = accountCreated;
exports.updated = accountUpdated;
exports.login = accountLoggedIn;
