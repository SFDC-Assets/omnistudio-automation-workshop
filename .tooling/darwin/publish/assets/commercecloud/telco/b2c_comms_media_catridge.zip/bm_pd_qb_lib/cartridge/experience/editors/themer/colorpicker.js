'use strict';
/**
 * Init for the color picker custom editor
 * Source: https://github.com/SalesforceCommerceCloud/plugin_themes/blob/master/cartridges/plugin_themes
 */
module.exports.init = function () {};
