'use strict';

/* global request, customer */

const ISML = require('dw/template/ISML');
const DCAPI = require('int_vlocity_cmt').VlocityService.DCAPI;

const Site = require('dw/system/Site');
const DCAPI_NAMESPACE = Site.current.getCustomPreferenceValue('vlocity_cmt_NamespaceForDCAPI');
const StringUtils = require('dw/util/StringUtils');

function appendVlocityLineItem(record, lineItems) {
    var details = [
        {
            label: 'Line Item key',
            value: record.lineItemKey
        },
        {
            label: 'Bundle Context key',
            value: record.bundleContextKey
        },
        {
            label: 'Hierarchy path',
            value: record.productHierarchyPath
        }
    ];

    var attributes = [];
    if (record.attributeCategories && Array.isArray(record.attributeCategories.records)) {
        record.attributeCategories.records.forEach(function(category) {
            if (category.productAttributes && Array.isArray(category.productAttributes.records)) {
                category.productAttributes.records.forEach(function(attribute) {
                    attributes.push({
                        label: attribute.label,
                        code: attribute.code,
                        value: attribute.userValues
                    });
                });
            }
        });
    }

    lineItems.push({
        productId: record.ProductCode,
        name: record.Name,
        action:record.action,
        quantity: record.Quantity.value,
        lineNumber: record[DCAPI_NAMESPACE + '__LineNumber__c'].value,
        oneTimePrice: record[DCAPI_NAMESPACE + '__OneTimeCalculatedPrice__c'].value,
        recurringPrice: record[DCAPI_NAMESPACE + '__RecurringCalculatedPrice__c'].value,
        details: details,
        attributes: attributes
    });

    if (record.lineItems && Array.isArray(record.lineItems.records)) {
        record.lineItems.records.forEach(function(childRecord) {
            appendVlocityLineItem(childRecord, lineItems);
        });
    }
}

function getLineItems(currentBasket) {
    var productLineItemsArray = currentBasket.productLineItems.toArray();
    var topLevelLineItems = productLineItemsArray.filter(function(pli) {
        return empty(pli.custom.vlocity_cmt_parentItemUUID);
    });

    topLevelLineItems.reverse();

    var lineItems = [];
    topLevelLineItems.forEach(function(topLevelPLI) {
        lineItems.push(topLevelPLI);

        lineItems = lineItems.concat(productLineItemsArray.filter(function(pli) {
            return pli.custom.vlocity_cmt_parentItemUUID === topLevelPLI.UUID;
        }));
    });

    

    return lineItems;
}

function getAssetLines(currentBasket){
    //Check for assets
    if(!empty(currentBasket.custom.vlocity_cmt_assetContext)){
        return JSON.parse(currentBasket.custom.vlocity_cmt_assetContext);
    }
   return null;
}

exports.ShowBasket = function() {
    const BasketMgr = require('dw/order/BasketMgr');

    const currentBasket = BasketMgr.currentBasket;

    var result = {
        sfccBasket: currentBasket
    };

    if (currentBasket) {
        var sfccLines = getLineItems(currentBasket);
        result.sfccLines = sfccLines;
       // result.assetLines = getAssetLines(currentBasket);
    }

    if (currentBasket) {
        var cartContextKey = currentBasket.custom.vlocity_cmt_cartContextKey;

        if (cartContextKey) {
            try {
                var firstProduct ; var catalogCode ;
                var vlocityParameterHelper = require('int_vlocity_cmt').customParameterHelper;
                var customerContext = vlocityParameterHelper.getURLParametersAsString();
                var vlocityProductHelper = require('int_vlocity_cmt').productHelper;
                var vlocityCustomerHelper = require('int_vlocity_cmt').customerHelper;
                // TODO: May need to rewrite this logic
                // Is catalog code really necessary?
                // if (!currentBasket.productLineItems.length  && !currentBasket.custom.vlocity_cmt_assetContext) {
                   
                //         throw 'No items found in SFCC basket';
                  
                   
                // }
                if(!empty(currentBasket.productLineItems)){
                     firstProduct = currentBasket.productLineItems[0].product;
                     catalogCode = firstProduct ? vlocityProductHelper.getCatalogCode(firstProduct) : 'default';
                }
                // There is only assets in basket
                else if(!empty(currentBasket.custom.vlocity_cmt_assetContext)){
                    var allAssetLines = JSON.parse(currentBasket.custom.vlocity_cmt_assetContext);
                    catalogCode = allAssetLines[0].primaryCatalogCode;
                }else{
                    throw 'No items found in SFCC basket';
                }
                
               
               

               // var customerContext = vlocityCustomerHelper.getCustomerContext(currentBasket.customer);
                var callResult = DCAPI.getBasketDetails(cartContextKey, catalogCode, customerContext);
 
                result.vlocityBasket = {
                    cartContextKey: cartContextKey,
                    numLines: callResult.result.totalSize,
                    oneTimeTotal: callResult.result.totals.EffectiveOneTimeTotal__c,
                    recurringTotal: callResult.result.totals.EffectiveRecurringTotal__c
                };

                if (result.vlocityBasket.numLines) {
                    result.vlocityBasket.lines = [];

                    callResult.result.records.forEach(function(record) {
                        appendVlocityLineItem(record, result.vlocityBasket.lines);
                    });
                }
            } catch (e) {
                result.message = ''+e;
            }
        } else {
            result.message = 'No Vlocity basket - no saved cartContextKey found in SFCC basket.';
        }
    } else {
        result.message = 'No SFCC basket.';
    }

    ISML.renderTemplate('vlocity/test/basketview', result);
};

exports.ShowBasket.public = true;



exports.ShowProduct = function() {
    var productId = request.httpParameterMap.pid.stringValue;
    var result = {};

    if (productId) {
        const vlocityProductHelper = require('int_vlocity_cmt').productHelper;

        var product = vlocityProductHelper.getProduct(productId);
        if (product) {
            const vlocityCustomerHelper = require('int_vlocity_cmt').customerHelper;

            var customerContext = vlocityCustomerHelper.getCustomerContext(customer);

            var getOfferDetailsResponse = vlocityProductHelper.getOfferDetails(product, customerContext);
            result.offerDetails = getOfferDetailsResponse;

            result.catalogCode = product.custom.vlocity_cmt_primaryCategory;

            var productStructure = product.custom.vlocity_cmt_productHierarchy;
            if (productStructure) {
                try {
                    result.productStructure = JSON.stringify(JSON.parse(productStructure), null, 4);
                } catch (e) {
                    result.productStructure = 'Invalid JSON data';
                }
            }

            var attributeMetadata = product.custom.vlocity_cmt_attributeMetadata;
            if (attributeMetadata) {
                try {
                    result.attributeMetadata = JSON.stringify(JSON.parse(attributeMetadata), null, 4);
                } catch (e) {
                    result.attributeMetadata = 'Invalid JSON data';
                }
            }

        } else {
            result.message = StringUtils.format('No product with ID {0} exists in SFCC.', productId);
        }
    } else {
        result.message = 'Missing pid questy string parameter value';
    }

    ISML.renderTemplate('vlocity/test/productview', result);
};

exports.ShowProduct.public = true;