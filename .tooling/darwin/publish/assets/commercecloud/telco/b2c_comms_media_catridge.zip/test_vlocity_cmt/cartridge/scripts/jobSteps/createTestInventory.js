'use strict';

const CatalogMgr = require('dw/catalog/CatalogMgr');
const ProductMgr = require('dw/catalog/ProductMgr');
const File = require('dw/io/File');
const FileWriter = require('dw/io/FileWriter');
const XMLStreamWriter = require('dw/io/XMLStreamWriter');
const XMLIndentingStreamWriter = require('dw/io/XMLIndentingStreamWriter');
const Logger = require('dw/system/Logger');
const Status = require('dw/system/Status');

const XML_INDENT = '    ';
const DEFAULT_FOLDER = 'IMPEX/src/test';
const DEFAULT_FILE_NAME = 'test_inventory.xml';
const DEFAULT_ALLOCATION = 100;


function writeTextNode(xmlWriter, nodeName, nodeValue, attributes) {
    xmlWriter.writeStartElement(nodeName);
    if (attributes && typeof attributes === 'object') {
        Object.keys(attributes).forEach(function(attributeID) {
            xmlWriter.writeAttribute(attributeID, attributes[attributeID]);
        });
    }
    xmlWriter.writeCharacters('' + nodeValue);
    xmlWriter.writeEndElement();
}


function writeInventoryRecord(xmlWriter, productId, allocation) {
    xmlWriter.writeStartElement('record');
    xmlWriter.writeAttribute('product-id', productId);
    if (allocation >= 0) {
        writeTextNode(xmlWriter, 'allocation', allocation);
        writeTextNode(xmlWriter, 'perpetual', false);
    } else {
        writeTextNode(xmlWriter, 'perpetual', true);
    }
    xmlWriter.writeEndElement(); // record
}


function writeInventoryRecords(productsIter, xmlWriter, allocation) {
    while(productsIter.hasNext()) {
        var product = productsIter.next();

        if (product.product && !product.master && !product.variant) {
            writeInventoryRecord(xmlWriter, product.ID, allocation);
        } else if (product.master) {
            for (var i = 0; i < product.variants.length; i++) {
                var variant = product.variants[i];
                writeInventoryRecord(xmlWriter, variant.ID, allocation);
            }
        }
    }
}


module.exports.execute = function (args) {
    if (args.IsDisabled) {
        Logger.info('Step disabled - skipping...');
        return new Status(Status.OK);
    }

    var catalogId = args.SourceCatalogID;
    var inventoryListId = args.InventoryListID;
    var targetFolder = args.WorkingFolder ? 'IMPEX/src/' + args.WorkingFolder : DEFAULT_FOLDER;
    var fileName = args.FileName || DEFAULT_FILE_NAME;
    var filePath = targetFolder + File.SEPARATOR + fileName;

    var productsIter;
    var fileWriter;
    var xmlWriter;

    try {
        if (!catalogId) {
            throw new Error('catalog_id parameter value missing');
        }

        if (!inventoryListId) {
            throw new Error('inventory_list_id parameter value missing');
        }

        var allocation = parseInt(args.Allocation);
        if (isNaN(allocation)) {
            allocation = DEFAULT_ALLOCATION;
        }

        var catalog = CatalogMgr.getCatalog(catalogId);
        if (!catalog) {
            throw new Error('Unable to find catalog with id: ' + catalogId);
        }

        productsIter = ProductMgr.queryProductsInCatalogSorted(catalog);

        var folder = new File(targetFolder);
        folder.mkdirs();

        var file = new File(filePath);
        fileWriter = new FileWriter(file, 'UTF-8');
        xmlWriter = new XMLIndentingStreamWriter(fileWriter);

        xmlWriter.indent = XML_INDENT;

        xmlWriter.writeStartDocument();
        xmlWriter.writeStartElement('inventory');
        xmlWriter.writeAttribute('xmlns', 'http://www.demandware.com/xml/impex/inventory/2007-05-31');
        xmlWriter.writeStartElement('inventory-list');

        xmlWriter.writeStartElement('header');
        xmlWriter.writeAttribute('list-id', inventoryListId);
        writeTextNode(xmlWriter, 'default-instock', false);

        xmlWriter.writeEndElement(); // header

        xmlWriter.writeStartElement('records');
        writeInventoryRecords(productsIter, xmlWriter, allocation);
        xmlWriter.writeEndElement(); // records

        xmlWriter.writeEndElement(); // inventory-list
        xmlWriter.writeEndElement(); // inventory
        xmlWriter.writeEndDocument();
    } catch (e) {
        Logger.error(e);
        return new Status(Status.ERROR);
    } finally {
        if (productsIter && 'close' in productsIter) {
            try {
                productsIter.close();
            } catch (e) {}
        }

        if (xmlWriter) {
            try {
                xmlWriter.close();
            } catch (e) {}
        }

        if (fileWriter) {
            try {
                fileWriter.close();
            } catch (e) {}
        }
    }

    return new Status(Status.OK);
};
