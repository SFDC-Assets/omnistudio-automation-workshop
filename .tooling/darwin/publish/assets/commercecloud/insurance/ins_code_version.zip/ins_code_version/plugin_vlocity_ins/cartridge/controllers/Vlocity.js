'use strict';

var server = require('server');
var omnioutHelper = require('*/cartridge/scripts/omniout/omnioutHelper');

server.get('OmniOutList', function (req, res, next) {
    res.render('vlocity/omniout/list', {
        scripts: omnioutHelper.getAvailableScripts()
    });

    next();
});

server.get('OmniOutPage', function (req, res, next) {
    var scriptId = req.querystring.sid;
    // var scriptId = 'Auto_MultiVehicleQuoteInsured_English';
    var pageData = omnioutHelper.getPageData(scriptId);
    res.render('vlocity/omniout/index', pageData);
    next();
});

server.get('OmniOutScript', function (req, res, next) {
    var scriptId = req.querystring.sid;
    if (scriptId) {
        scriptId = '' + scriptId;
        scriptId = scriptId.replace(/\.json$/i, '');
    }
    var scriptContent = omnioutHelper.getLocalScript(scriptId);

    if (scriptContent) {
        res.setContentType('application/json');
        res.base.writer.print(scriptContent);
        return;
    }
    res.setStatusCode(404);
    res.render('error/notFound');

    next();
});

server.get('OmniOutRedirect', function (req, res, next) {
	var CustomerMgr = require('dw/customer/CustomerMgr');
	var Transaction = require('dw/system/Transaction');
    var BasketMgr = require('dw/order/BasketMgr');
    var Resource = require('dw/web/Resource');
    var URLUtils = require('dw/web/URLUtils');
    var CartModel = require('*/cartridge/models/cart');
    var ProductLineItemsModel = require('*/cartridge/models/productLineItems');
    
 	var accountHelpers = require('*/cartridge/scripts/helpers/accountHelpers');
    var cartHelper = require('*/cartridge/scripts/cart/cartHelpers');
    var basketCalculationHelpers = require('*/cartridge/scripts/helpers/basketCalculationHelpers');
	
	//replace password with customer-entered one
	var customer_password = "Tobereplaced123!";
	var authsuccess = false;
	var authenticatedCustomer;
	
    // attempt to create a new user and log that user in.
    try {
        Transaction.wrap(function () {
            var error = {};
            
            // Get existing registered customer or create new customer registration
            var customer = CustomerMgr.getCustomerByLogin(req.querystring.email);
            if (customer === null) {
                customer = CustomerMgr.createCustomer(req.querystring.email, customer_password);
            }

            var authenticateCustomerResult = CustomerMgr.authenticateCustomer(req.querystring.email, customer_password);
            if (authenticateCustomerResult.status !== 'AUTH_OK') {
                error = { authError: true, status: authenticateCustomerResult.status };
                throw error;
            }

            authenticatedCustomer = CustomerMgr.loginCustomer(authenticateCustomerResult, false);

            if (!authenticatedCustomer) {
                error = { authError: true, status: authenticateCustomerResult.status };
                throw error;
            } else {
                // assign values to the profile
                var customerProfile = customer.getProfile();

                customerProfile.firstName = req.querystring.fname;
                customerProfile.lastName = req.querystring.lname;
                customerProfile.email = req.querystring.email;
            }
            authsuccess = true;
        });
    } catch (e) {
    	authsuccess = false;
    }
    
    if (authsuccess) {
        // send a registration email
        accountHelpers.sendCreateAccountEmail(authenticatedCustomer.profile);
    }

    /* Add-to-cart interface consistent with Cart-AddProduct, but works with
     * a GET request instead of POST and requires additional quote ID (qid)
     * parameter containing the ID of the Salesforce Industries quote record
     * containing pricing and other details for the line item.
     */
     
    // add the quote product line item to the cart
    var currentBasket = BasketMgr.getCurrentOrNewBasket();
    var previousBonusDiscountLineItems = currentBasket.getBonusDiscountLineItems();
    var productId = req.querystring.pid;
    var childProducts = Object.hasOwnProperty.call(req.querystring, 'childProducts')
        ? JSON.parse(req.querystring.childProducts)
        : []; 
    var options = req.querystring.options ? JSON.parse(req.querystring.options) : [];
    var quoteId = req.querystring.qid;
    var quantity;
    var result;
    var pidsObj;
    var currentBasket = BasketMgr.getCurrentOrNewBasket();
    var previousBonusDiscountLineItems = currentBasket.getBonusDiscountLineItems();
    var productId = req.querystring.pid;
    var childProducts = Object.hasOwnProperty.call(req.querystring, 'childProducts')
        ? JSON.parse(req.querystring.childProducts)
        : [];
    var options = req.querystring.options ? JSON.parse(req.querystring.options) : [];
    var quoteId = req.querystring.qid;
    var quantity;
    var result;
    var pidsObj;

    if (currentBasket) { 
        Transaction.wrap(function () {
            if (!req.querystring.pidsObj) {
                quantity = parseInt(req.querystring.quantity, 10);
                result = cartHelper.addProductToCart(
                    currentBasket,
                    productId,
                    quantity,
                    childProducts,
                    options,
                    quoteId
                );
            } else {
                // product set
                pidsObj = JSON.parse(req.querystring.pidsObj);
                result = {
                    error: false,
                    message: Resource.msg('text.alert.addedtobasket', 'product', null)
                };

                pidsObj.forEach(function (PIDObj) {
                    quantity = parseInt(PIDObj.qty, 10);
                    var pidOptions = PIDObj.options ? JSON.parse(PIDObj.options) : {};
                    var PIDObjResult = cartHelper.addProductToCart(
                        currentBasket,
                        PIDObj.pid,
                        quantity,
                        childProducts,
                        pidOptions,
                        quoteId
                    );
                    if (PIDObjResult.error) {
                        result.error = PIDObjResult.error;
                        result.message = PIDObjResult.message;
                    }
                });
            }
            if (!result.error) {
                cartHelper.ensureAllShipmentsHaveMethods(currentBasket);
                basketCalculationHelpers.calculateTotals(currentBasket);
            }
        });
    }

    var quantityTotal = ProductLineItemsModel.getTotalQuantity(currentBasket.productLineItems);
    var cartModel = new CartModel(currentBasket);

    var urlObject = {
        url: URLUtils.url('Cart-ChooseBonusProducts').toString(),
        configureProductstUrl: URLUtils.url('Product-ShowBonusProducts').toString(),
        addToCartUrl: URLUtils.url('Cart-AddBonusProducts').toString()
    };

    var newBonusDiscountLineItem =
        cartHelper.getNewBonusDiscountLineItem(
            currentBasket,
            previousBonusDiscountLineItems,
            urlObject,
            result.uuid
        );
    if (newBonusDiscountLineItem) {
        var allLineItems = currentBasket.allProductLineItems;
        var collections = require('*/cartridge/scripts/util/collections');
        collections.forEach(allLineItems, function (pli) {
            if (pli.UUID === result.uuid) {
                Transaction.wrap(function () {
                    pli.custom.bonusProductLineItemUUID = 'bonus'; // eslint-disable-line no-param-reassign
                    pli.custom.preOrderUUID = pli.UUID; // eslint-disable-line no-param-reassign
                });
            }
        });
    }

    var reportingURL = cartHelper.getReportingUrlAddToCart(currentBasket, result.error);

    res.render('vlocity/omniout/redirect', {
        quoteId: req.querystring.qid,
        firstName: req.querystring.fname,
        lastName: req.querystring.lname,
        email: req.querystring.email,
        authsuccess : authsuccess
    });

    next();
});

module.exports = server.exports();
