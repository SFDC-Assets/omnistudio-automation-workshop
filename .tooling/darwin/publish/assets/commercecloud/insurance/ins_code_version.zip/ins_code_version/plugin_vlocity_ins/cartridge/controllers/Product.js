'use strict';

var server = require('server');

server.extend(module.superModule);

server.prepend('Show', function (req, res, next) {
	var URLUtils = require('dw/web/URLUtils');
    var source = req.querystring.source

    //If it comes from MC
    if (source == "igodigital") {
    	res.redirect(URLUtils.url('Login-Show', 'rurl', 2));
        this.done(req, res);
        return;
    }

    next();
});

module.exports = server.exports();
