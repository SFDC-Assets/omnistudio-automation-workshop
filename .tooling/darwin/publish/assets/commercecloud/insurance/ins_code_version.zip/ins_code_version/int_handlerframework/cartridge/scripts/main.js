'use strict';

var path = '~/cartridge/scripts/';

module.exports = {
    commConfig: require(path +'communication/util/handlerConfig')
};
