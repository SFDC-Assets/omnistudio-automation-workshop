'use strict';

const ISML = require('dw/template/ISML');


const API = require('../../../int_vlocity_ins/cartridge/scripts/VlocityService');


const Site = require('dw/system/Site');
const DCAPI_NAMESPACE = Site.current.getCustomPreferenceValue('vlocity_cmt_NamespaceForDCAPI');

exports.ShowQuote = function() {

    var quoteId = '0Q04x0000009IPwCAM'
    // make api call to the getQuoteDetails integration procedure service
    var callResult = API.INSAPI.getQuoteDetails(quoteId);
    var quoteDetails = callResult.result.object.responseObj;
    var testDetails = JSON.parse(quoteDetails);

    ISML.renderTemplate('vlocity/test/quotes', {
        test: testDetails
    });
};

exports.CreatePolicies = function() {

    var quoteIdsCommaSeparated = request.httpParameterMap.quoteIds.stringValue;
    var quoteIds = quoteIdsCommaSeparated ? quoteIdsCommaSeparated.split(',') : [];

    // make api call to the createMultiplePolicies integration procedure service
    var callResult = API.INSAPI.createMultiplePolicies(quoteIds);
    var policyDetails = callResult.result.object.responseObj;
    var testDetails = JSON.parse(policyDetails);

    ISML.renderTemplate('vlocity/test/policies', {
        test: testDetails
    });
};

exports.ShowQuote.public = true;
exports.CreatePolicies.public = true;

