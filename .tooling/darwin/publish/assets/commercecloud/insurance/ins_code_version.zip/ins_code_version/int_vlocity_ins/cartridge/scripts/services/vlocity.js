/* eslint-disable require-jsdoc */
/* eslint-disable valid-jsdoc */
'use strict';

/**
 * @module services/vlocity
 */

/**
 * @type {module:util/helpers}
 */
var helpers = require('../util/helpers');

function getValidAuthToken() {
    var AuthToken = require('~/cartridge/scripts/models/authToken');
    var authToken = new AuthToken();
    var token = authToken.getValidToken();

    return token;
}

function copyQueryStringParams(svc, queryStringObject) {
    if (queryStringObject && typeof queryStringObject === 'object') {
        Object.keys(queryStringObject).forEach(function (key) {
            var value = queryStringObject[key];

            if (value && typeof value === 'object') {
                svc.addParam(key, JSON.stringify(value));
            } else {
                svc.addParam(key, '' + value);
            }
        });
    }
}

/**
 * Inserts auth token into request header and updates the service URL
 *
 * @param {dw.svc.HTTPService} svc
 *
 * @throws {Error} Throws error when no valid auth token is available (i.e.- service error, service down)
 */
function setAuthHeader(svc) {
    /**
     * @type {module:models/authToken~AuthToken}
     */
    var token = getValidAuthToken();
    if (!token || !token.access_token) {
        throw new Error('No auth token available!');
    }

    if (!token.instance_url) {
        throw new Error('No instance URL available in token!');
    }

    svc.setAuthentication('NONE');
    svc.addHeader('Authorization', 'Bearer ' + token.access_token);
    svc.addHeader('Content-Type', 'application/json');

    svc.setURL(token.instance_url);
}

/**
 * Check if 401 due to expired token
 *
 * @param {dw.net.HTTPClient} client
 *
 * @returns {boolean} true if expired auth token
 */
function isValid401(client) {
    var is401 = (client.statusCode === 401);
    var isFailureFromBadToken = false;
    var authResHeader = client.getResponseHeader('WWW-Authenticate');

    if (is401 && authResHeader) {
        isFailureFromBadToken = /^Bearer\s.+?invalid_token/.test(authResHeader);
    }

    return isFailureFromBadToken;
}

/**
 * Check if response type is JSON
 *
 * @param {dw.net.HTTPClient} client
 *
 * @returns {boolean}
 */
function isResponseJSON(client) {
    var contentTypeHeader = client.getResponseHeader('Content-Type');
    return contentTypeHeader && contentTypeHeader.split(';')[0].toLowerCase() === 'application/json';
}

var serviceDefinition = {
    /**
     * Create request for service authentication
     *
     * @param {dw.svc.HTTPService} svc
     *
     * @throws {Error} Throws error when service credentials are missing
     */
    createRequest: function (svc, requestObject) {
        setAuthHeader(svc);

        var URL = svc.getURL();
        if (requestObject.endpoint) {
            var endpointURL = [URL, requestObject.endpoint].join('');
            // eslint-disable-next-line no-unused-vars
            var whatisit = (typeof requestObject.queryString);
            if (requestObject.queryString && typeof requestObject.queryString === 'string') {
                svc.setURL(endpointURL + requestObject.queryString);
            } else {
                svc.setURL(endpointURL);
            }
        }

        if (requestObject.httpMethod) {
            svc.setRequestMethod(requestObject.httpMethod);
        }

        if (requestObject.queryString) {
            copyQueryStringParams(svc, requestObject.queryString);
        }

        if (requestObject.headers && typeof requestObject.headers === 'object') {
            Object.keys(requestObject.headers).forEach(function (headerKey) {
                var headerValue = requestObject.headers[headerKey];
                svc.addHeader(headerKey, headerValue);
            });
        }

        if (requestObject.payload) {
            return JSON.stringify(requestObject.payload);
        }

        return null;
    },

    /**
     * @param {dw.svc.HTTPService} svc
     * @param {dw.net.HTTPClient} client
     *
     * @returns {Object}
     */
    parseResponse: function (svc, client) {
        var isJSON = isResponseJSON(client);
        var parsedBody = client.text;

        if (isJSON) {
            parsedBody = helpers.expandJSON(client.text, {});
        }

        return {
            isValidJSON: isJSON,
            isError: client.statusCode >= 400,
            isAuthError: isValid401(client),
            responseObj: parsedBody,
            errorText: client.errorText
        };
    },

    mockCall: function () {
        var obj = {
        };
        return {
            statusCode: 202,
            statusMessage: 'Accepted',
            text: JSON.stringify(obj)
        };
    }

};

module.exports = serviceDefinition;
