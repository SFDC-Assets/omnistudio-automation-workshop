/* eslint-disable valid-jsdoc */
'use strict';

/**
 * @module services/auth
 */

/**
 * Vlocity AUTH service definition
 */

/**
 * @type {dw.system.Logger}
 */
var Logger = require('dw/system/Logger');
/**
 * @type {dw.system.Site}
 */
var Site = require('dw/system/Site');

/**
 * @type {module:util/helpers}
 */
var helpers = require('../util/helpers');

/**
 * @type {dw.system.Logger}
 */
var LOGGER = Logger.getLogger('int_vlocity_ins', 'vlocity.rest');

/**
 * Attempt to set to site-specific credential to the given service. If it fails, fallback to the original ID
 *
 * @param  {dw.svc.HTTPService} svc
 * @param  {String} id
 *
 * @return {String}
 */
function setCredentialID(svc, id) {
    var siteID = Site.getCurrent().getID();
    var possibleIDs = [
        id + '-' + siteID,
        id
    ];

    possibleIDs.some(function (credentialID) {
        try {
            svc.setCredentialID(credentialID);
            return true;
        } catch (e) {
            return false;
        }
    });
}

var serviceDefinition = {
    /**
     * Create request for Vlocity Insurance getQuoteDetails integration procedure
     *
     * @param {dw.svc.HTTPService} svc
     *
     * @throws {Error} Throws error when valid Bearer token is not available
     */
    createRequest: function (svc, quoteId) {
        setCredentialID(svc, svc.getCredentialID() || svc.getConfiguration().getID());

        LOGGER.debug('Vlocity Connector credential ID: {0}', svc.getCredentialID());

        var AuthToken = require('*/cartridge/scripts/models/authToken');        
            var authToken = new AuthToken();
        var token = authToken.getValidToken();

        if (empty(token.access_token)) {
            throw new Error('Could not obtain valid access token');
        }

        svc.setAuthentication('NONE');
        svc.addHeader('Authorization', 'Bearer ' + token.access_token);
        svc.setRequestMethod('GET');
        svc.addParam('quoteId', quoteId);
    },

    /**
     * @param {dw.svc.HTTPService} svc
     * @param {dw.net.HTTPClient} client
     *
     * @returns {Object}
     */
    parseResponse: function (svc, client) {
        var responseObj;

        try {
            responseObj = helpers.expandJSON(client.text, {});
        } catch (e) {
            responseObj = client.text;
            LOGGER.error('Unable to parse JSON response text: {0}', responseObj);
        }

        return responseObj;
    },

    mockCall: function () {
        var obj = {
              "policyDetails": [
                {
                  "totalSize": 0,
                  "records": [
                    {
                      "displaySequence": -1,
                      "Id": "02i4x000000gnisAAA",
                      "productId": "01t4x000001y3bEAAQ",
                      "accountId": "0014x00000EZOmxAAH",
                      "productName": "Multi Auto",
                      "Name": "Multi Auto",
                      "EffectiveStart": "2021-02-10",
                      "Price": 2484.5,
                      "PricingFormula__c": "SUM(premiumBIPD + premiumCOLL + premiumCCD + premiumMED + premiumUM+premiumRental)",
                      "ProductCode": "autoMulti",
                      "RecordTypeName__c": "Product",
                      "vlocity_ins__TotalTaxAmount__c": 40.2725,
                      "vlocity_ins__TotalFeeAmount__c": 25,
                      "vlocity_ins__TotalTaxForTerm__c": 40.2725,
                      "vlocity_ins__TotalFeeForTerm__c": 25,
                      "vlocity_ins__TotalAmount__c": 2549.77,
                      "vlocity_ins__TotalAmountForTerm__c": 65.27,
                      "hasAttributes": false,
                      "taxesAndFees": [
                        {
                          "currencySymbol": "$",
                          "currencyCode": "USD",
                          "calculatedAmount": 25,
                          "PriceListEntryName__c": "573608e0-7b1c-9b66-a435-d584218c5305",
                          "PriceListEntryId__c": "a3u4x000000cabtAAA",
                          "isRefundable": false,
                          "Amount__c": 25,
                          "AdjustmentType__c": "Fee",
                          "Id": "a0I4x000001Z3ANEA0"
                        },
                        {
                          "currencySymbol": "$",
                          "currencyCode": "USD",
                          "calculatedAmount": 27.85,
                          "PriceListEntryName__c": "7457f382-f935-3308-3429-24d9dfac88f4",
                          "PriceListEntryId__c": "a3u4x000000cabuAAA",
                          "isRefundable": true,
                          "Amount__c": 27.85,
                          "AdjustmentType__c": "Tax",
                          "Id": "a0I4x000001Z3AOEA0"
                        },
                        {
                          "currencySymbol": "$",
                          "currencyCode": "USD",
                          "calculatedAmount": 0,
                          "PriceListEntryName__c": "7eee88c5-37d5-3991-02db-37ef3343982f",
                          "PriceListEntryId__c": "a3u4x000000cabvAAA",
                          "isRefundable": false,
                          "Amount__c": 0,
                          "AdjustmentType__c": "Tax",
                          "Id": "a0I4x000001Z3APEA0"
                        },
                        {
                          "currencySymbol": "$",
                          "currencyCode": "USD",
                          "calculatedAmount": 12.4225,
                          "PriceListEntryName__c": "93b485fc-a7ce-a358-929d-e0381289b239",
                          "PriceListEntryId__c": "a3u4x000000cabwAAA",
                          "isRefundable": true,
                          "Amount__c": 12.4225,
                          "AdjustmentType__c": "Tax",
                          "Id": "a0I4x000001Z3AQEA0"
                        }
                      ],
                      "taxAmount": 40.2725,
                      "feeAmount": 25,
                      "totalTaxFeeAmount": 65.2725,
                      "coverageCount": 0,
                      "childProducts": {
                        "totalSize": 3,
                        "records": [
                          {
                            "displaySequence": -1,
                            "Id": "a0G4x000000X1CaEAK",
                            "currencySymbol": "$",
                            "currencyCode": "USD",
                            "IsDeleted": false,
                            "Name": "2019 BMW M3",
                            "instanceKey": "2019 BMW M3",
                            "CreatedDate": "2021-02-10T17:19:34.000+0000",
                            "CreatedById": "0054x000003KYHhAAO",
                            "LastModifiedDate": "2021-02-10T17:19:34.000+0000",
                            "LastModifiedById": "0054x000003KYHhAAO",
                            "SystemModstamp": "2021-02-10T17:19:34.000+0000",
                            "vlocity_ins__PolicyAssetId__c": "02i4x000000gnisAAA",
                            "vlocity_ins__AttributeSelectedValues__c": "{\"avRestraints\":false,\"ProductCode\":\"autoVehicle\",\"avBodyType\":\"Sedan/Saloon\",\"avBrakes\":false,\"avHistoric\":false,\"avModel\":\"M3\",\"avStabilization\":false,\"avGaragePostalCode\":\"94110\",\"isParent\":true,\"avMake\":\"BMW\",\"avValue\":45000,\"avMileage\":10000,\"avYear\":\"2019\",\"avAntiTheft\":true,\"avAltFuel\":false}",
                            "vlocity_ins__InsuredItemNumber__c": "2019 BMW M3",
                            "vlocity_ins__MarketValue__c": 0,
                            "vlocity_ins__PremiumAmount__c": 1341.43,
                            "Price": 1341.43,
                            "vlocity_ins__Product2Id__c": "01t4x000001y3a0AAA",
                            "vlocity_ins__ProductChildItemId__c": "a484x000000Zh9qAAC",
                            "vlocity_ins__RecordTypeName__c": "InsuredItemSpec",
                            "vlocity_ins__TotalAmount__c": 1341.43,
                            "vlocity_ins__TotalProratedAmount__c": 0,
                            "hasAttributes": true,
                            "PricingFormula__c": "premiumBIPD + premiumCOLL + premiumCCD + premiumMED + premiumUM+premiumRental",
                            "minCount": 1,
                            "maxCount": 1,
                            "productName": "Vehicle",
                            "productId": "01t4x000001y3a0AAA",
                            "ProductCode": "autoVehicle",
                            "pciId": "a484x000000Zh9qAAC",
                            "hasCoverages": true,
                            "attributeCategories": {
                              "totalSize": 1,
                              "records": [
                                {
                                  "displaySequence": 210,
                                  "Code__c": "autoVehicle",
                                  "Name": "Auto Vehicle",
                                  "id": "a0R4P00000J2MJyUAN",
                                  "productAttributes": {
                                    "totalSize": 27,
                                    "records": [
                                      {
                                        "code": "avValue",
                                        "dataType": "currency",
                                        "inputType": "number",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": true,
                                        "disabled": true,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofbUAC",
                                        "label": "Value",
                                        "displaySequence": 0,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": true,
                                            "disabled": true
                                          }
                                        ],
                                        "userValues": 45000
                                      },
                                      {
                                        "code": "avAltFuel",
                                        "dataType": "text",
                                        "inputType": "checkbox",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": true,
                                        "disabled": true,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofCUAS",
                                        "label": "Alternative Fuel",
                                        "displaySequence": 1,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": true,
                                            "disabled": true
                                          }
                                        ],
                                        "userValues": false
                                      },
                                      {
                                        "code": "avAntiTheft",
                                        "dataType": "text",
                                        "inputType": "checkbox",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": true,
                                        "disabled": true,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofDUAS",
                                        "label": "Anti Theft",
                                        "displaySequence": 2,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": true,
                                            "disabled": true
                                          }
                                        ],
                                        "userValues": true
                                      },
                                      {
                                        "code": "avBrakes",
                                        "dataType": "text",
                                        "inputType": "checkbox",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": true,
                                        "disabled": true,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofFUAS",
                                        "label": "Brakes",
                                        "displaySequence": 3,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": true,
                                            "disabled": true
                                          }
                                        ],
                                        "userValues": false
                                      },
                                      {
                                        "code": "avClaimFreq",
                                        "dataType": "number",
                                        "inputType": "number",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": true,
                                        "disabled": true,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofGUAS",
                                        "label": "Claim Frequency",
                                        "displaySequence": 4,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": true,
                                            "disabled": true
                                          }
                                        ],
                                        "userValues": null
                                      },
                                      {
                                        "code": "avClaimSev",
                                        "dataType": "number",
                                        "inputType": "number",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": true,
                                        "disabled": true,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofHUAS",
                                        "label": "Claim Severity",
                                        "displaySequence": 5,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": true,
                                            "disabled": true
                                          }
                                        ],
                                        "userValues": null
                                      },
                                      {
                                        "code": "avLicNum",
                                        "dataType": "text",
                                        "inputType": "text",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": true,
                                        "disabled": true,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofLUAS",
                                        "label": "License Number",
                                        "displaySequence": 6,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": true,
                                            "disabled": true
                                          }
                                        ],
                                        "userValues": null
                                      },
                                      {
                                        "code": "avLicState",
                                        "dataType": "text",
                                        "inputType": "text",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": true,
                                        "disabled": true,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofMUAS",
                                        "label": "License State",
                                        "displaySequence": 7,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": true,
                                            "disabled": true
                                          }
                                        ],
                                        "userValues": null
                                      },
                                      {
                                        "code": "avMake",
                                        "dataType": "text",
                                        "inputType": "text",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": true,
                                        "disabled": true,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofNUAS",
                                        "label": "Make",
                                        "displaySequence": 8,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": true,
                                            "disabled": true
                                          }
                                        ],
                                        "userValues": "BMW"
                                      },
                                      {
                                        "code": "avModel",
                                        "dataType": "text",
                                        "inputType": "text",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": true,
                                        "disabled": true,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofPUAS",
                                        "label": "Model",
                                        "displaySequence": 9,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": true,
                                            "disabled": true
                                          }
                                        ],
                                        "userValues": "M3"
                                      },
                                      {
                                        "code": "avRatedDriver-BIPD",
                                        "dataType": "number",
                                        "inputType": "number",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": true,
                                        "disabled": true,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofQUAS",
                                        "label": "Rated Driver - BIPD",
                                        "displaySequence": 10,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": true,
                                            "disabled": true
                                          }
                                        ],
                                        "userValues": null
                                      },
                                      {
                                        "code": "avRatedDriver-COMP",
                                        "dataType": "number",
                                        "inputType": "number",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": true,
                                        "disabled": true,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofSUAS",
                                        "label": "Rated Driver - Comprehensive",
                                        "displaySequence": 11,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": true,
                                            "disabled": true
                                          }
                                        ],
                                        "userValues": null
                                      },
                                      {
                                        "code": "avRatedDriver-MED",
                                        "dataType": "number",
                                        "inputType": "number",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": true,
                                        "disabled": true,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofTUAS",
                                        "label": "Rated Driver - Medical Payments",
                                        "displaySequence": 12,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": true,
                                            "disabled": true
                                          }
                                        ],
                                        "userValues": null
                                      },
                                      {
                                        "code": "avRatedDriver-UM",
                                        "dataType": "number",
                                        "inputType": "number",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": true,
                                        "disabled": true,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofUUAS",
                                        "label": "Rated Driver - Uninsured Motorist",
                                        "displaySequence": 13,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": true,
                                            "disabled": true
                                          }
                                        ],
                                        "userValues": null
                                      },
                                      {
                                        "code": "avRatedDriverName",
                                        "dataType": "text",
                                        "inputType": "text",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": true,
                                        "disabled": true,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofVUAS",
                                        "label": "Rated Driver Name",
                                        "displaySequence": 14,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": true,
                                            "disabled": true
                                          }
                                        ],
                                        "userValues": null
                                      },
                                      {
                                        "code": "avRestraints",
                                        "dataType": "text",
                                        "inputType": "checkbox",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": true,
                                        "disabled": true,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofWUAS",
                                        "label": "Restraints",
                                        "displaySequence": 15,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": true,
                                            "disabled": true
                                          }
                                        ],
                                        "userValues": false
                                      },
                                      {
                                        "code": "avStabilization",
                                        "dataType": "text",
                                        "inputType": "checkbox",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": true,
                                        "disabled": true,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofXUAS",
                                        "label": "Stablization",
                                        "displaySequence": 16,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": true,
                                            "disabled": true
                                          }
                                        ],
                                        "userValues": false
                                      },
                                      {
                                        "code": "avHistoric",
                                        "dataType": "text",
                                        "inputType": "checkbox",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": false,
                                        "disabled": false,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofKUAS",
                                        "label": "Historic",
                                        "displaySequence": 17,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": false,
                                            "disabled": false
                                          }
                                        ],
                                        "userValues": false
                                      },
                                      {
                                        "code": "avStyle",
                                        "dataType": "text",
                                        "inputType": "text",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": true,
                                        "disabled": true,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofYUAS",
                                        "label": "Style",
                                        "displaySequence": 18,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": true,
                                            "disabled": true
                                          }
                                        ],
                                        "userValues": null
                                      },
                                      {
                                        "code": "avSymbol",
                                        "dataType": "text",
                                        "inputType": "text",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": true,
                                        "disabled": true,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofZUAS",
                                        "label": "Symbol",
                                        "displaySequence": 19,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": true,
                                            "disabled": true
                                          }
                                        ],
                                        "userValues": null
                                      },
                                      {
                                        "code": "avColor",
                                        "dataType": "text",
                                        "inputType": "text",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": true,
                                        "disabled": true,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofIUAS",
                                        "label": "Color",
                                        "displaySequence": 20,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": true,
                                            "disabled": true
                                          }
                                        ],
                                        "userValues": null
                                      },
                                      {
                                        "code": "avVIN",
                                        "dataType": "text",
                                        "inputType": "text",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": true,
                                        "disabled": true,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofaUAC",
                                        "label": "VIN",
                                        "displaySequence": 21,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": true,
                                            "disabled": true
                                          }
                                        ],
                                        "userValues": null
                                      },
                                      {
                                        "code": "avYear",
                                        "dataType": "text",
                                        "inputType": "text",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": true,
                                        "disabled": true,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofcUAC",
                                        "label": "Year",
                                        "displaySequence": 22,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": true,
                                            "disabled": true
                                          }
                                        ],
                                        "userValues": "2019"
                                      },
                                      {
                                        "code": "avMileage",
                                        "dataType": "number",
                                        "inputType": "number",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": true,
                                        "disabled": true,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofOUAS",
                                        "label": "Annual Mileage",
                                        "displaySequence": 23,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": true,
                                            "disabled": true
                                          }
                                        ],
                                        "userValues": 10000
                                      },
                                      {
                                        "code": "avBodyType",
                                        "dataType": "text",
                                        "inputType": "text",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": true,
                                        "disabled": true,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofEUAS",
                                        "label": "Body Type",
                                        "displaySequence": 24,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": true,
                                            "disabled": true
                                          }
                                        ],
                                        "userValues": "Sedan/Saloon"
                                      },
                                      {
                                        "code": "avGaragePostalCode",
                                        "dataType": "text",
                                        "inputType": "text",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": true,
                                        "disabled": true,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofJUAS",
                                        "label": "Garage Location (Postal Code)",
                                        "displaySequence": 25,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": true,
                                            "disabled": true
                                          }
                                        ],
                                        "userValues": "94110"
                                      },
                                      {
                                        "code": "avRatedDriver-COLL",
                                        "dataType": "number",
                                        "inputType": "number",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": true,
                                        "disabled": true,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofRUAS",
                                        "label": "Rated Driver - Collision",
                                        "displaySequence": 26,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": true,
                                            "disabled": true
                                          }
                                        ],
                                        "userValues": null
                                      }
                                    ]
                                  }
                                }
                              ]
                            },
                            "childProducts": {
                              "totalSize": 6,
                              "records": [
                                {
                                  "displaySequence": -1,
                                  "Id": "a0F4x000000wKnJEAU",
                                  "currencySymbol": "$",
                                  "currencyCode": "USD",
                                  "IsDeleted": false,
                                  "Name": "Bodily Injury & Property Damage",
                                  "CreatedDate": "2021-02-10T17:19:34.000+0000",
                                  "CreatedById": "0054x000003KYHhAAO",
                                  "LastModifiedDate": "2021-02-10T17:19:34.000+0000",
                                  "LastModifiedById": "0054x000003KYHhAAO",
                                  "SystemModstamp": "2021-02-10T17:19:34.000+0000",
                                  "vlocity_ins__PolicyAssetId__c": "02i4x000000gnisAAA",
                                  "vlocity_ins__AggregateLimitAmount__c": 0,
                                  "vlocity_ins__AssetInsuredItemId__c": "a0G4x000000X1CaEAK",
                                  "vlocity_ins__AttributeSelectedValues__c": "{\"autoBIPDLimit.autoPDLimClm\":25000,\"autoBIPDLimit.autoBILimClm\":50000,\"autoBIPDLimit.autoBILimClmCov\":25000,\"autoBIPDLimit\":\"25000/50000/25000\"}",
                                  "vlocity_ins__DeductibleAmount__c": 0,
                                  "vlocity_ins__PremiumAmount__c": 16.5,
                                  "Price": 16.5,
                                  "vlocity_ins__Product2Id__c": "01t4x000001y3ZiAAI",
                                  "vlocity_ins__ProductChildItemId__c": "a484x000000ZhDPAA0",
                                  "vlocity_ins__RecordTypeName__c": "CoverageSpec",
                                  "vlocity_ins__StartDate__c": "2021-02-10T08:00:00.000+0000",
                                  "vlocity_ins__TotalAmount__c": 16.5,
                                  "vlocity_ins__TotalProratedAmount__c": 0,
                                  "isOptional": false,
                                  "isSelected": true,
                                  "ProductCode": "autoBIPD",
                                  "productName": "Bodily Injury & Property Damage",
                                  "productId": "01t4x000001y3ZiAAI",
                                  "pciId": "a484x000000ZhDPAA0",
                                  "PricingSource__c": "premiumBIPD",
                                  "attributeCategories": {
                                    "totalSize": 1,
                                    "records": [
                                      {
                                        "displaySequence": 230,
                                        "Code__c": "autoTerms",
                                        "Name": "Auto Terms",
                                        "id": "a0R4P00000JWzkZUAT",
                                        "productAttributes": {
                                          "totalSize": 1,
                                          "records": [
                                            {
                                              "code": "autoBIPDLimit",
                                              "dataType": "text",
                                              "inputType": "dropdown",
                                              "multiselect": false,
                                              "required": false,
                                              "readonly": false,
                                              "disabled": false,
                                              "filterable": true,
                                              "attributeId": "a0S4P000009YMK7UAO",
                                              "label": "BIPD Limit",
                                              "displaySequence": 0,
                                              "hasRules": true,
                                              "hidden": false,
                                              "cloneable": true,
                                              "isNotTranslatable": false,
                                              "values": [
                                                {
                                                  "id": "0",
                                                  "label": "$15000/$30000/$10000",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": "15000/30000/10000"
                                                },
                                                {
                                                  "id": "1",
                                                  "label": "$15000/$30000/$5000",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": "15000/30000/5000"
                                                },
                                                {
                                                  "id": "2",
                                                  "label": "$25000/$50000/$25000",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": "25000/50000/25000"
                                                },
                                                {
                                                  "id": "3",
                                                  "label": "$25000/$50000/$50000",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": "25000/50000/50000"
                                                },
                                                {
                                                  "id": "4",
                                                  "label": "$50000/$100000/$50000",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": "50000/100000/50000"
                                                },
                                                {
                                                  "id": "5",
                                                  "label": "$50000/$100000/$100000",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": "50000/100000/100000"
                                                },
                                                {
                                                  "id": "6",
                                                  "label": "$100000/$300000/$25000",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": "100000/300000/25000"
                                                },
                                                {
                                                  "id": "7",
                                                  "label": "$100000/$300000/$50000",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": "100000/300000/50000"
                                                },
                                                {
                                                  "id": "8",
                                                  "label": "$100000/$300000/$100000",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": "100000/300000/100000"
                                                },
                                                {
                                                  "id": "9",
                                                  "label": "$250000/$500000/$100000",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": "250000/500000/100000"
                                                },
                                                {
                                                  "id": "10",
                                                  "label": "$500000/$500000/100000",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": "500000/500000/100000"
                                                },
                                                {
                                                  "id": "11",
                                                  "label": "$500000/$500000/$500000",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": "500000/500000/500000"
                                                },
                                                {
                                                  "id": "12",
                                                  "label": "$500000/$1000000/$500000",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": "500000/1000000/500000"
                                                }
                                              ],
                                              "userValues": "25000/50000/25000",
                                              "valueDecoder": "autoBILimClmCov/autoBILimClm/autoPDLimClm"
                                            }
                                          ]
                                        }
                                      }
                                    ]
                                  }
                                },
                                {
                                  "displaySequence": -1,
                                  "Id": "a0F4x000000wKnKEAU",
                                  "currencySymbol": "$",
                                  "currencyCode": "USD",
                                  "IsDeleted": false,
                                  "Name": "Collision",
                                  "CreatedDate": "2021-02-10T17:19:34.000+0000",
                                  "CreatedById": "0054x000003KYHhAAO",
                                  "LastModifiedDate": "2021-02-10T17:19:34.000+0000",
                                  "LastModifiedById": "0054x000003KYHhAAO",
                                  "SystemModstamp": "2021-02-10T17:19:34.000+0000",
                                  "vlocity_ins__PolicyAssetId__c": "02i4x000000gnisAAA",
                                  "vlocity_ins__AggregateLimitAmount__c": 0,
                                  "vlocity_ins__AssetInsuredItemId__c": "a0G4x000000X1CaEAK",
                                  "vlocity_ins__AttributeSelectedValues__c": "{\"autoCollDedClmCov\":500}",
                                  "vlocity_ins__DeductibleAmount__c": 0,
                                  "vlocity_ins__PremiumAmount__c": 868.56,
                                  "Price": 868.56,
                                  "vlocity_ins__Product2Id__c": "01t4x000001y3aDAAQ",
                                  "vlocity_ins__ProductChildItemId__c": "a484x000000Zh9pAAC",
                                  "vlocity_ins__RecordTypeName__c": "CoverageSpec",
                                  "vlocity_ins__StartDate__c": "2021-02-10T08:00:00.000+0000",
                                  "vlocity_ins__TotalAmount__c": 868.56,
                                  "vlocity_ins__TotalProratedAmount__c": 0,
                                  "isOptional": false,
                                  "isSelected": true,
                                  "ProductCode": "autoCollision",
                                  "productName": "Collision",
                                  "productId": "01t4x000001y3aDAAQ",
                                  "pciId": "a484x000000Zh9pAAC",
                                  "PricingSource__c": "premiumCOLL",
                                  "attributeCategories": {
                                    "totalSize": 1,
                                    "records": [
                                      {
                                        "displaySequence": 230,
                                        "Code__c": "autoTerms",
                                        "Name": "Auto Terms",
                                        "id": "a0R4P00000JWzkZUAT",
                                        "productAttributes": {
                                          "totalSize": 1,
                                          "records": [
                                            {
                                              "code": "autoCollDedClmCov",
                                              "dataType": "currency",
                                              "inputType": "dropdown",
                                              "multiselect": false,
                                              "required": false,
                                              "readonly": false,
                                              "disabled": false,
                                              "filterable": true,
                                              "attributeId": "a0S4P000009YMK8UAO",
                                              "label": "Collision Deductible",
                                              "displaySequence": 0,
                                              "hasRules": false,
                                              "hidden": false,
                                              "cloneable": true,
                                              "isNotTranslatable": false,
                                              "values": [
                                                {
                                                  "id": "0",
                                                  "label": "$250",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": 250
                                                },
                                                {
                                                  "id": "1",
                                                  "label": "$500",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": 500
                                                },
                                                {
                                                  "id": "2",
                                                  "label": "$750",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": 750
                                                },
                                                {
                                                  "id": "3",
                                                  "label": "$1000",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": 1000
                                                },
                                                {
                                                  "id": "4",
                                                  "label": "$1500",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": 1500
                                                },
                                                {
                                                  "id": "5",
                                                  "label": "$2500",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": 2500
                                                }
                                              ],
                                              "userValues": 500
                                            }
                                          ]
                                        }
                                      }
                                    ]
                                  }
                                },
                                {
                                  "displaySequence": -1,
                                  "Id": "a0F4x000000wKnLEAU",
                                  "currencySymbol": "$",
                                  "currencyCode": "USD",
                                  "IsDeleted": false,
                                  "Name": "Comprehensive",
                                  "CreatedDate": "2021-02-10T17:19:34.000+0000",
                                  "CreatedById": "0054x000003KYHhAAO",
                                  "LastModifiedDate": "2021-02-10T17:19:34.000+0000",
                                  "LastModifiedById": "0054x000003KYHhAAO",
                                  "SystemModstamp": "2021-02-10T17:19:34.000+0000",
                                  "vlocity_ins__PolicyAssetId__c": "02i4x000000gnisAAA",
                                  "vlocity_ins__AggregateLimitAmount__c": 0,
                                  "vlocity_ins__AssetInsuredItemId__c": "a0G4x000000X1CaEAK",
                                  "vlocity_ins__AttributeSelectedValues__c": "{\"autoCompDedClmCov\":100}",
                                  "vlocity_ins__DeductibleAmount__c": 0,
                                  "vlocity_ins__PremiumAmount__c": 350.78,
                                  "Price": 350.78,
                                  "vlocity_ins__Product2Id__c": "01t4x000001y3a1AAA",
                                  "vlocity_ins__ProductChildItemId__c": "a484x000000Zh9nAAC",
                                  "vlocity_ins__RecordTypeName__c": "CoverageSpec",
                                  "vlocity_ins__StartDate__c": "2021-02-10T08:00:00.000+0000",
                                  "vlocity_ins__TotalAmount__c": 350.78,
                                  "vlocity_ins__TotalProratedAmount__c": 0,
                                  "isOptional": false,
                                  "isSelected": true,
                                  "ProductCode": "autoComp",
                                  "productName": "Comprehensive",
                                  "productId": "01t4x000001y3a1AAA",
                                  "pciId": "a484x000000Zh9nAAC",
                                  "PricingSource__c": "premiumCCD",
                                  "attributeCategories": {
                                    "totalSize": 1,
                                    "records": [
                                      {
                                        "displaySequence": 230,
                                        "Code__c": "autoTerms",
                                        "Name": "Auto Terms",
                                        "id": "a0R4P00000JWzkZUAT",
                                        "productAttributes": {
                                          "totalSize": 1,
                                          "records": [
                                            {
                                              "code": "autoCompDedClmCov",
                                              "dataType": "currency",
                                              "inputType": "dropdown",
                                              "multiselect": false,
                                              "required": false,
                                              "readonly": false,
                                              "disabled": false,
                                              "filterable": true,
                                              "attributeId": "a0S4P000009YMK9UAO",
                                              "label": "Comp Deductible",
                                              "displaySequence": 0,
                                              "hasRules": false,
                                              "hidden": false,
                                              "cloneable": true,
                                              "isNotTranslatable": false,
                                              "values": [
                                                {
                                                  "id": "0",
                                                  "label": "$100",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": 100
                                                },
                                                {
                                                  "id": "1",
                                                  "label": "$250",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": 250
                                                },
                                                {
                                                  "id": "2",
                                                  "label": "$500",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": 500
                                                },
                                                {
                                                  "id": "3",
                                                  "label": "$750",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": 750
                                                },
                                                {
                                                  "id": "4",
                                                  "label": "$1000",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": 1000
                                                },
                                                {
                                                  "id": "5",
                                                  "label": "$1500",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": 1500
                                                },
                                                {
                                                  "id": "6",
                                                  "label": "$2500",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": 2500
                                                }
                                              ],
                                              "userValues": 100
                                            }
                                          ]
                                        }
                                      }
                                    ]
                                  }
                                },
                                {
                                  "displaySequence": -1,
                                  "Id": "a0F4x000000wKnMEAU",
                                  "currencySymbol": "$",
                                  "currencyCode": "USD",
                                  "IsDeleted": false,
                                  "Name": "Medical Payments",
                                  "CreatedDate": "2021-02-10T17:19:34.000+0000",
                                  "CreatedById": "0054x000003KYHhAAO",
                                  "LastModifiedDate": "2021-02-10T17:19:34.000+0000",
                                  "LastModifiedById": "0054x000003KYHhAAO",
                                  "SystemModstamp": "2021-02-10T17:19:34.000+0000",
                                  "vlocity_ins__PolicyAssetId__c": "02i4x000000gnisAAA",
                                  "vlocity_ins__AggregateLimitAmount__c": 0,
                                  "vlocity_ins__AssetInsuredItemId__c": "a0G4x000000X1CaEAK",
                                  "vlocity_ins__AttributeSelectedValues__c": "{\"autoMedPayLimClmCov\":1000}",
                                  "vlocity_ins__DeductibleAmount__c": 0,
                                  "vlocity_ins__PremiumAmount__c": 37.37,
                                  "Price": 37.37,
                                  "vlocity_ins__Product2Id__c": "01t4x000001y3aKAAQ",
                                  "vlocity_ins__ProductChildItemId__c": "a484x000000Zh9oAAC",
                                  "vlocity_ins__RecordTypeName__c": "CoverageSpec",
                                  "vlocity_ins__StartDate__c": "2021-02-10T08:00:00.000+0000",
                                  "vlocity_ins__TotalAmount__c": 37.37,
                                  "vlocity_ins__TotalProratedAmount__c": 0,
                                  "isOptional": false,
                                  "isSelected": true,
                                  "ProductCode": "autoMedical",
                                  "productName": "Medical Payments",
                                  "productId": "01t4x000001y3aKAAQ",
                                  "pciId": "a484x000000Zh9oAAC",
                                  "PricingSource__c": "premiumMED",
                                  "attributeCategories": {
                                    "totalSize": 1,
                                    "records": [
                                      {
                                        "displaySequence": 230,
                                        "Code__c": "autoTerms",
                                        "Name": "Auto Terms",
                                        "id": "a0R4P00000JWzkZUAT",
                                        "productAttributes": {
                                          "totalSize": 1,
                                          "records": [
                                            {
                                              "code": "autoMedPayLimClmCov",
                                              "dataType": "currency",
                                              "inputType": "dropdown",
                                              "multiselect": false,
                                              "required": false,
                                              "readonly": false,
                                              "disabled": false,
                                              "filterable": true,
                                              "attributeId": "a0S4P000009YMKCUA4",
                                              "label": "Med Pay Person Limit",
                                              "displaySequence": 0,
                                              "hasRules": false,
                                              "hidden": false,
                                              "cloneable": true,
                                              "isNotTranslatable": false,
                                              "values": [
                                                {
                                                  "id": "0",
                                                  "label": "$1000",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": 1000
                                                },
                                                {
                                                  "id": "1",
                                                  "label": "$2000",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": 2000
                                                },
                                                {
                                                  "id": "2",
                                                  "label": "$5000",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": 5000
                                                }
                                              ],
                                              "userValues": 1000
                                            }
                                          ]
                                        }
                                      }
                                    ]
                                  }
                                },
                                {
                                  "displaySequence": -1,
                                  "Id": "a0F4x000000wKnNEAU",
                                  "currencySymbol": "$",
                                  "currencyCode": "USD",
                                  "IsDeleted": false,
                                  "Name": "Uninsured Motorist",
                                  "CreatedDate": "2021-02-10T17:19:34.000+0000",
                                  "CreatedById": "0054x000003KYHhAAO",
                                  "LastModifiedDate": "2021-02-10T17:19:34.000+0000",
                                  "LastModifiedById": "0054x000003KYHhAAO",
                                  "SystemModstamp": "2021-02-10T17:19:34.000+0000",
                                  "vlocity_ins__PolicyAssetId__c": "02i4x000000gnisAAA",
                                  "vlocity_ins__AggregateLimitAmount__c": 0,
                                  "vlocity_ins__AssetInsuredItemId__c": "a0G4x000000X1CaEAK",
                                  "vlocity_ins__AttributeSelectedValues__c": "{\"autoUMLimit\":\"50/100\"}",
                                  "vlocity_ins__DeductibleAmount__c": 0,
                                  "vlocity_ins__PremiumAmount__c": 68.22,
                                  "Price": 68.22,
                                  "vlocity_ins__Product2Id__c": "01t4x000001y3ZzAAI",
                                  "vlocity_ins__ProductChildItemId__c": "a484x000000Zh9sAAC",
                                  "vlocity_ins__RecordTypeName__c": "CoverageSpec",
                                  "vlocity_ins__StartDate__c": "2021-02-10T08:00:00.000+0000",
                                  "vlocity_ins__TotalAmount__c": 68.22,
                                  "vlocity_ins__TotalProratedAmount__c": 0,
                                  "isOptional": false,
                                  "isSelected": true,
                                  "ProductCode": "autoUM",
                                  "productName": "Uninsured Motorist",
                                  "productId": "01t4x000001y3ZzAAI",
                                  "pciId": "a484x000000Zh9sAAC",
                                  "PricingSource__c": "premiumUM",
                                  "attributeCategories": {
                                    "totalSize": 1,
                                    "records": [
                                      {
                                        "displaySequence": 230,
                                        "Code__c": "autoTerms",
                                        "Name": "Auto Terms",
                                        "id": "a0R4P00000JWzkZUAT",
                                        "productAttributes": {
                                          "totalSize": 1,
                                          "records": [
                                            {
                                              "code": "autoUMLimit",
                                              "dataType": "text",
                                              "inputType": "dropdown",
                                              "multiselect": false,
                                              "required": false,
                                              "readonly": false,
                                              "disabled": false,
                                              "filterable": true,
                                              "attributeId": "a0S4P000009YMKGUA4",
                                              "label": "UM Limit",
                                              "displaySequence": 0,
                                              "hasRules": false,
                                              "hidden": false,
                                              "cloneable": true,
                                              "isNotTranslatable": false,
                                              "values": [
                                                {
                                                  "id": "0",
                                                  "label": "$15,000 / $30,000",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": "15/30"
                                                },
                                                {
                                                  "id": "1",
                                                  "label": "$25,000 / $50,000",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": "25/50"
                                                },
                                                {
                                                  "id": "2",
                                                  "label": "$30,000 / $60,000",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": "30/60"
                                                },
                                                {
                                                  "id": "3",
                                                  "label": "$50,000 / $100,000",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": "50/100"
                                                },
                                                {
                                                  "id": "4",
                                                  "label": "$100,000 / $300,000",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": "100/300"
                                                },
                                                {
                                                  "id": "5",
                                                  "label": "$250,000 / $500,000",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": "250/500"
                                                },
                                                {
                                                  "id": "6",
                                                  "label": "$500,000 / $500,000",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": "500/500"
                                                },
                                                {
                                                  "id": "7",
                                                  "label": "$500,000 / $1,000,000",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": "500/1000"
                                                }
                                              ],
                                              "userValues": "50/100"
                                            }
                                          ]
                                        }
                                      }
                                    ]
                                  }
                                },
                                {
                                  "displaySequence": -1,
                                  "productId": "01t4x000001y3aRAAQ",
                                  "productName": "Rental Car",
                                  "ProductCode": "autoRental",
                                  "Name": "Rental Car",
                                  "pciId": "a484x000000Zh9tAAC",
                                  "isOptional": true,
                                  "isSelected": false,
                                  "vlocity_ins__RecordTypeName__c": "CoverageSpec",
                                  "vlocity_ins__PricingSource__c": "premiumRental",
                                  "attributeCategories": {
                                    "totalSize": 1,
                                    "records": [
                                      {
                                        "displaySequence": 230,
                                        "Code__c": "autoTerms",
                                        "Name": "Auto Terms",
                                        "id": "a0R4P00000JWzkZUAT",
                                        "productAttributes": {
                                          "totalSize": 2,
                                          "records": [
                                            {
                                              "code": "autoRentalLimClmCov",
                                              "dataType": "currency",
                                              "inputType": "number",
                                              "multiselect": false,
                                              "required": false,
                                              "readonly": true,
                                              "disabled": true,
                                              "filterable": true,
                                              "attributeId": "a0S4P000009YMKFUA4",
                                              "label": "Rental Limit",
                                              "displaySequence": 0,
                                              "hasRules": false,
                                              "hidden": false,
                                              "cloneable": true,
                                              "isNotTranslatable": false,
                                              "values": [
                                                {
                                                  "readonly": true,
                                                  "disabled": true
                                                }
                                              ],
                                              "userValues": 2000
                                            },
                                            {
                                              "code": "autoRentalDays",
                                              "dataType": "number",
                                              "inputType": "number",
                                              "multiselect": false,
                                              "required": false,
                                              "readonly": true,
                                              "disabled": true,
                                              "filterable": true,
                                              "attributeId": "a0S4P000009YMKEUA4",
                                              "label": "Number of Days",
                                              "displaySequence": 1,
                                              "hasRules": false,
                                              "hidden": false,
                                              "cloneable": true,
                                              "isNotTranslatable": false,
                                              "values": [
                                                {
                                                  "readonly": true,
                                                  "disabled": true
                                                }
                                              ],
                                              "userValues": 30
                                            }
                                          ]
                                        }
                                      }
                                    ]
                                  }
                                }
                              ]
                            }
                          },
                          {
                            "displaySequence": -1,
                            "Id": "a0G4x000000X1CbEAK",
                            "currencySymbol": "$",
                            "currencyCode": "USD",
                            "IsDeleted": false,
                            "Name": "2020 Mazda CX-30",
                            "instanceKey": "2020 Mazda CX-30",
                            "CreatedDate": "2021-02-10T17:19:34.000+0000",
                            "CreatedById": "0054x000003KYHhAAO",
                            "LastModifiedDate": "2021-02-10T17:19:34.000+0000",
                            "LastModifiedById": "0054x000003KYHhAAO",
                            "SystemModstamp": "2021-02-10T17:19:34.000+0000",
                            "vlocity_ins__PolicyAssetId__c": "02i4x000000gnisAAA",
                            "vlocity_ins__AttributeSelectedValues__c": "{\"avRestraints\":false,\"ProductCode\":\"autoVehicle\",\"avBodyType\":\"Sedan/SUV\",\"avBrakes\":false,\"avHistoric\":false,\"avModel\":\"CX-30\",\"avStabilization\":false,\"avGaragePostalCode\":\"94110\",\"isParent\":true,\"avMake\":\"Mazda\",\"avValue\":26200,\"avMileage\":15000,\"avYear\":\"2020\",\"avAntiTheft\":true,\"avAltFuel\":false}",
                            "vlocity_ins__InsuredItemNumber__c": "2020 Mazda CX-30",
                            "vlocity_ins__MarketValue__c": 0,
                            "vlocity_ins__PremiumAmount__c": 1143.07,
                            "Price": 1143.07,
                            "vlocity_ins__Product2Id__c": "01t4x000001y3a0AAA",
                            "vlocity_ins__ProductChildItemId__c": "a484x000000Zh9qAAC",
                            "vlocity_ins__RecordTypeName__c": "InsuredItemSpec",
                            "vlocity_ins__TotalAmount__c": 1143.07,
                            "vlocity_ins__TotalProratedAmount__c": 0,
                            "hasAttributes": true,
                            "PricingFormula__c": "premiumBIPD + premiumCOLL + premiumCCD + premiumMED + premiumUM+premiumRental",
                            "minCount": 1,
                            "maxCount": 1,
                            "productName": "Vehicle",
                            "productId": "01t4x000001y3a0AAA",
                            "ProductCode": "autoVehicle",
                            "pciId": "a484x000000Zh9qAAC",
                            "hasCoverages": true,
                            "attributeCategories": {
                              "totalSize": 1,
                              "records": [
                                {
                                  "displaySequence": 210,
                                  "Code__c": "autoVehicle",
                                  "Name": "Auto Vehicle",
                                  "id": "a0R4P00000J2MJyUAN",
                                  "productAttributes": {
                                    "totalSize": 27,
                                    "records": [
                                      {
                                        "code": "avValue",
                                        "dataType": "currency",
                                        "inputType": "number",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": true,
                                        "disabled": true,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofbUAC",
                                        "label": "Value",
                                        "displaySequence": 0,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": true,
                                            "disabled": true
                                          }
                                        ],
                                        "userValues": 26200
                                      },
                                      {
                                        "code": "avAltFuel",
                                        "dataType": "text",
                                        "inputType": "checkbox",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": true,
                                        "disabled": true,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofCUAS",
                                        "label": "Alternative Fuel",
                                        "displaySequence": 1,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": true,
                                            "disabled": true
                                          }
                                        ],
                                        "userValues": false
                                      },
                                      {
                                        "code": "avAntiTheft",
                                        "dataType": "text",
                                        "inputType": "checkbox",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": true,
                                        "disabled": true,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofDUAS",
                                        "label": "Anti Theft",
                                        "displaySequence": 2,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": true,
                                            "disabled": true
                                          }
                                        ],
                                        "userValues": true
                                      },
                                      {
                                        "code": "avBrakes",
                                        "dataType": "text",
                                        "inputType": "checkbox",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": true,
                                        "disabled": true,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofFUAS",
                                        "label": "Brakes",
                                        "displaySequence": 3,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": true,
                                            "disabled": true
                                          }
                                        ],
                                        "userValues": false
                                      },
                                      {
                                        "code": "avClaimFreq",
                                        "dataType": "number",
                                        "inputType": "number",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": true,
                                        "disabled": true,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofGUAS",
                                        "label": "Claim Frequency",
                                        "displaySequence": 4,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": true,
                                            "disabled": true
                                          }
                                        ],
                                        "userValues": null
                                      },
                                      {
                                        "code": "avClaimSev",
                                        "dataType": "number",
                                        "inputType": "number",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": true,
                                        "disabled": true,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofHUAS",
                                        "label": "Claim Severity",
                                        "displaySequence": 5,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": true,
                                            "disabled": true
                                          }
                                        ],
                                        "userValues": null
                                      },
                                      {
                                        "code": "avLicNum",
                                        "dataType": "text",
                                        "inputType": "text",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": true,
                                        "disabled": true,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofLUAS",
                                        "label": "License Number",
                                        "displaySequence": 6,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": true,
                                            "disabled": true
                                          }
                                        ],
                                        "userValues": null
                                      },
                                      {
                                        "code": "avLicState",
                                        "dataType": "text",
                                        "inputType": "text",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": true,
                                        "disabled": true,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofMUAS",
                                        "label": "License State",
                                        "displaySequence": 7,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": true,
                                            "disabled": true
                                          }
                                        ],
                                        "userValues": null
                                      },
                                      {
                                        "code": "avMake",
                                        "dataType": "text",
                                        "inputType": "text",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": true,
                                        "disabled": true,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofNUAS",
                                        "label": "Make",
                                        "displaySequence": 8,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": true,
                                            "disabled": true
                                          }
                                        ],
                                        "userValues": "Mazda"
                                      },
                                      {
                                        "code": "avModel",
                                        "dataType": "text",
                                        "inputType": "text",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": true,
                                        "disabled": true,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofPUAS",
                                        "label": "Model",
                                        "displaySequence": 9,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": true,
                                            "disabled": true
                                          }
                                        ],
                                        "userValues": "CX-30"
                                      },
                                      {
                                        "code": "avRatedDriver-BIPD",
                                        "dataType": "number",
                                        "inputType": "number",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": true,
                                        "disabled": true,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofQUAS",
                                        "label": "Rated Driver - BIPD",
                                        "displaySequence": 10,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": true,
                                            "disabled": true
                                          }
                                        ],
                                        "userValues": null
                                      },
                                      {
                                        "code": "avRatedDriver-COMP",
                                        "dataType": "number",
                                        "inputType": "number",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": true,
                                        "disabled": true,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofSUAS",
                                        "label": "Rated Driver - Comprehensive",
                                        "displaySequence": 11,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": true,
                                            "disabled": true
                                          }
                                        ],
                                        "userValues": null
                                      },
                                      {
                                        "code": "avRatedDriver-MED",
                                        "dataType": "number",
                                        "inputType": "number",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": true,
                                        "disabled": true,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofTUAS",
                                        "label": "Rated Driver - Medical Payments",
                                        "displaySequence": 12,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": true,
                                            "disabled": true
                                          }
                                        ],
                                        "userValues": null
                                      },
                                      {
                                        "code": "avRatedDriver-UM",
                                        "dataType": "number",
                                        "inputType": "number",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": true,
                                        "disabled": true,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofUUAS",
                                        "label": "Rated Driver - Uninsured Motorist",
                                        "displaySequence": 13,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": true,
                                            "disabled": true
                                          }
                                        ],
                                        "userValues": null
                                      },
                                      {
                                        "code": "avRatedDriverName",
                                        "dataType": "text",
                                        "inputType": "text",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": true,
                                        "disabled": true,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofVUAS",
                                        "label": "Rated Driver Name",
                                        "displaySequence": 14,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": true,
                                            "disabled": true
                                          }
                                        ],
                                        "userValues": null
                                      },
                                      {
                                        "code": "avRestraints",
                                        "dataType": "text",
                                        "inputType": "checkbox",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": true,
                                        "disabled": true,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofWUAS",
                                        "label": "Restraints",
                                        "displaySequence": 15,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": true,
                                            "disabled": true
                                          }
                                        ],
                                        "userValues": false
                                      },
                                      {
                                        "code": "avStabilization",
                                        "dataType": "text",
                                        "inputType": "checkbox",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": true,
                                        "disabled": true,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofXUAS",
                                        "label": "Stablization",
                                        "displaySequence": 16,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": true,
                                            "disabled": true
                                          }
                                        ],
                                        "userValues": false
                                      },
                                      {
                                        "code": "avHistoric",
                                        "dataType": "text",
                                        "inputType": "checkbox",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": false,
                                        "disabled": false,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofKUAS",
                                        "label": "Historic",
                                        "displaySequence": 17,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": false,
                                            "disabled": false
                                          }
                                        ],
                                        "userValues": false
                                      },
                                      {
                                        "code": "avStyle",
                                        "dataType": "text",
                                        "inputType": "text",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": true,
                                        "disabled": true,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofYUAS",
                                        "label": "Style",
                                        "displaySequence": 18,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": true,
                                            "disabled": true
                                          }
                                        ],
                                        "userValues": null
                                      },
                                      {
                                        "code": "avSymbol",
                                        "dataType": "text",
                                        "inputType": "text",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": true,
                                        "disabled": true,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofZUAS",
                                        "label": "Symbol",
                                        "displaySequence": 19,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": true,
                                            "disabled": true
                                          }
                                        ],
                                        "userValues": null
                                      },
                                      {
                                        "code": "avColor",
                                        "dataType": "text",
                                        "inputType": "text",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": true,
                                        "disabled": true,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofIUAS",
                                        "label": "Color",
                                        "displaySequence": 20,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": true,
                                            "disabled": true
                                          }
                                        ],
                                        "userValues": null
                                      },
                                      {
                                        "code": "avVIN",
                                        "dataType": "text",
                                        "inputType": "text",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": true,
                                        "disabled": true,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofaUAC",
                                        "label": "VIN",
                                        "displaySequence": 21,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": true,
                                            "disabled": true
                                          }
                                        ],
                                        "userValues": null
                                      },
                                      {
                                        "code": "avYear",
                                        "dataType": "text",
                                        "inputType": "text",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": true,
                                        "disabled": true,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofcUAC",
                                        "label": "Year",
                                        "displaySequence": 22,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": true,
                                            "disabled": true
                                          }
                                        ],
                                        "userValues": "2020"
                                      },
                                      {
                                        "code": "avMileage",
                                        "dataType": "number",
                                        "inputType": "number",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": true,
                                        "disabled": true,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofOUAS",
                                        "label": "Annual Mileage",
                                        "displaySequence": 23,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": true,
                                            "disabled": true
                                          }
                                        ],
                                        "userValues": 15000
                                      },
                                      {
                                        "code": "avBodyType",
                                        "dataType": "text",
                                        "inputType": "text",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": true,
                                        "disabled": true,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofEUAS",
                                        "label": "Body Type",
                                        "displaySequence": 24,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": true,
                                            "disabled": true
                                          }
                                        ],
                                        "userValues": "Sedan/SUV"
                                      },
                                      {
                                        "code": "avGaragePostalCode",
                                        "dataType": "text",
                                        "inputType": "text",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": true,
                                        "disabled": true,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofJUAS",
                                        "label": "Garage Location (Postal Code)",
                                        "displaySequence": 25,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": true,
                                            "disabled": true
                                          }
                                        ],
                                        "userValues": "94110"
                                      },
                                      {
                                        "code": "avRatedDriver-COLL",
                                        "dataType": "number",
                                        "inputType": "number",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": true,
                                        "disabled": true,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofRUAS",
                                        "label": "Rated Driver - Collision",
                                        "displaySequence": 26,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": true,
                                            "disabled": true
                                          }
                                        ],
                                        "userValues": null
                                      }
                                    ]
                                  }
                                }
                              ]
                            },
                            "childProducts": {
                              "totalSize": 6,
                              "records": [
                                {
                                  "displaySequence": -1,
                                  "Id": "a0F4x000000wKnEEAU",
                                  "currencySymbol": "$",
                                  "currencyCode": "USD",
                                  "IsDeleted": false,
                                  "Name": "Bodily Injury & Property Damage",
                                  "CreatedDate": "2021-02-10T17:19:34.000+0000",
                                  "CreatedById": "0054x000003KYHhAAO",
                                  "LastModifiedDate": "2021-02-10T17:19:34.000+0000",
                                  "LastModifiedById": "0054x000003KYHhAAO",
                                  "SystemModstamp": "2021-02-10T17:19:34.000+0000",
                                  "vlocity_ins__PolicyAssetId__c": "02i4x000000gnisAAA",
                                  "vlocity_ins__AggregateLimitAmount__c": 0,
                                  "vlocity_ins__AssetInsuredItemId__c": "a0G4x000000X1CbEAK",
                                  "vlocity_ins__AttributeSelectedValues__c": "{\"autoBIPDLimit.autoPDLimClm\":25000,\"autoBIPDLimit.autoBILimClm\":50000,\"autoBIPDLimit.autoBILimClmCov\":25000,\"autoBIPDLimit\":\"25000/50000/25000\"}",
                                  "vlocity_ins__DeductibleAmount__c": 0,
                                  "vlocity_ins__PremiumAmount__c": 19.34,
                                  "Price": 19.34,
                                  "vlocity_ins__Product2Id__c": "01t4x000001y3ZiAAI",
                                  "vlocity_ins__ProductChildItemId__c": "a484x000000ZhDPAA0",
                                  "vlocity_ins__RecordTypeName__c": "CoverageSpec",
                                  "vlocity_ins__StartDate__c": "2021-02-10T08:00:00.000+0000",
                                  "vlocity_ins__TotalAmount__c": 19.34,
                                  "vlocity_ins__TotalProratedAmount__c": 0,
                                  "isOptional": false,
                                  "isSelected": true,
                                  "ProductCode": "autoBIPD",
                                  "productName": "Bodily Injury & Property Damage",
                                  "productId": "01t4x000001y3ZiAAI",
                                  "pciId": "a484x000000ZhDPAA0",
                                  "PricingSource__c": "premiumBIPD",
                                  "attributeCategories": {
                                    "totalSize": 1,
                                    "records": [
                                      {
                                        "displaySequence": 230,
                                        "Code__c": "autoTerms",
                                        "Name": "Auto Terms",
                                        "id": "a0R4P00000JWzkZUAT",
                                        "productAttributes": {
                                          "totalSize": 1,
                                          "records": [
                                            {
                                              "code": "autoBIPDLimit",
                                              "dataType": "text",
                                              "inputType": "dropdown",
                                              "multiselect": false,
                                              "required": false,
                                              "readonly": false,
                                              "disabled": false,
                                              "filterable": true,
                                              "attributeId": "a0S4P000009YMK7UAO",
                                              "label": "BIPD Limit",
                                              "displaySequence": 0,
                                              "hasRules": true,
                                              "hidden": false,
                                              "cloneable": true,
                                              "isNotTranslatable": false,
                                              "values": [
                                                {
                                                  "id": "0",
                                                  "label": "$15000/$30000/$10000",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": "15000/30000/10000"
                                                },
                                                {
                                                  "id": "1",
                                                  "label": "$15000/$30000/$5000",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": "15000/30000/5000"
                                                },
                                                {
                                                  "id": "2",
                                                  "label": "$25000/$50000/$25000",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": "25000/50000/25000"
                                                },
                                                {
                                                  "id": "3",
                                                  "label": "$25000/$50000/$50000",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": "25000/50000/50000"
                                                },
                                                {
                                                  "id": "4",
                                                  "label": "$50000/$100000/$50000",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": "50000/100000/50000"
                                                },
                                                {
                                                  "id": "5",
                                                  "label": "$50000/$100000/$100000",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": "50000/100000/100000"
                                                },
                                                {
                                                  "id": "6",
                                                  "label": "$100000/$300000/$25000",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": "100000/300000/25000"
                                                },
                                                {
                                                  "id": "7",
                                                  "label": "$100000/$300000/$50000",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": "100000/300000/50000"
                                                },
                                                {
                                                  "id": "8",
                                                  "label": "$100000/$300000/$100000",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": "100000/300000/100000"
                                                },
                                                {
                                                  "id": "9",
                                                  "label": "$250000/$500000/$100000",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": "250000/500000/100000"
                                                },
                                                {
                                                  "id": "10",
                                                  "label": "$500000/$500000/100000",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": "500000/500000/100000"
                                                },
                                                {
                                                  "id": "11",
                                                  "label": "$500000/$500000/$500000",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": "500000/500000/500000"
                                                },
                                                {
                                                  "id": "12",
                                                  "label": "$500000/$1000000/$500000",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": "500000/1000000/500000"
                                                }
                                              ],
                                              "userValues": "25000/50000/25000",
                                              "valueDecoder": "autoBILimClmCov/autoBILimClm/autoPDLimClm"
                                            }
                                          ]
                                        }
                                      }
                                    ]
                                  }
                                },
                                {
                                  "displaySequence": -1,
                                  "Id": "a0F4x000000wKnFEAU",
                                  "currencySymbol": "$",
                                  "currencyCode": "USD",
                                  "IsDeleted": false,
                                  "Name": "Collision",
                                  "CreatedDate": "2021-02-10T17:19:34.000+0000",
                                  "CreatedById": "0054x000003KYHhAAO",
                                  "LastModifiedDate": "2021-02-10T17:19:34.000+0000",
                                  "LastModifiedById": "0054x000003KYHhAAO",
                                  "SystemModstamp": "2021-02-10T17:19:34.000+0000",
                                  "vlocity_ins__PolicyAssetId__c": "02i4x000000gnisAAA",
                                  "vlocity_ins__AggregateLimitAmount__c": 0,
                                  "vlocity_ins__AssetInsuredItemId__c": "a0G4x000000X1CbEAK",
                                  "vlocity_ins__AttributeSelectedValues__c": "{\"autoCollDedClmCov\":500}",
                                  "vlocity_ins__DeductibleAmount__c": 0,
                                  "vlocity_ins__PremiumAmount__c": 769.5,
                                  "Price": 769.5,
                                  "vlocity_ins__Product2Id__c": "01t4x000001y3aDAAQ",
                                  "vlocity_ins__ProductChildItemId__c": "a484x000000Zh9pAAC",
                                  "vlocity_ins__RecordTypeName__c": "CoverageSpec",
                                  "vlocity_ins__StartDate__c": "2021-02-10T08:00:00.000+0000",
                                  "vlocity_ins__TotalAmount__c": 769.5,
                                  "vlocity_ins__TotalProratedAmount__c": 0,
                                  "isOptional": false,
                                  "isSelected": true,
                                  "ProductCode": "autoCollision",
                                  "productName": "Collision",
                                  "productId": "01t4x000001y3aDAAQ",
                                  "pciId": "a484x000000Zh9pAAC",
                                  "PricingSource__c": "premiumCOLL",
                                  "attributeCategories": {
                                    "totalSize": 1,
                                    "records": [
                                      {
                                        "displaySequence": 230,
                                        "Code__c": "autoTerms",
                                        "Name": "Auto Terms",
                                        "id": "a0R4P00000JWzkZUAT",
                                        "productAttributes": {
                                          "totalSize": 1,
                                          "records": [
                                            {
                                              "code": "autoCollDedClmCov",
                                              "dataType": "currency",
                                              "inputType": "dropdown",
                                              "multiselect": false,
                                              "required": false,
                                              "readonly": false,
                                              "disabled": false,
                                              "filterable": true,
                                              "attributeId": "a0S4P000009YMK8UAO",
                                              "label": "Collision Deductible",
                                              "displaySequence": 0,
                                              "hasRules": false,
                                              "hidden": false,
                                              "cloneable": true,
                                              "isNotTranslatable": false,
                                              "values": [
                                                {
                                                  "id": "0",
                                                  "label": "$250",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": 250
                                                },
                                                {
                                                  "id": "1",
                                                  "label": "$500",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": 500
                                                },
                                                {
                                                  "id": "2",
                                                  "label": "$750",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": 750
                                                },
                                                {
                                                  "id": "3",
                                                  "label": "$1000",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": 1000
                                                },
                                                {
                                                  "id": "4",
                                                  "label": "$1500",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": 1500
                                                },
                                                {
                                                  "id": "5",
                                                  "label": "$2500",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": 2500
                                                }
                                              ],
                                              "userValues": 500
                                            }
                                          ]
                                        }
                                      }
                                    ]
                                  }
                                },
                                {
                                  "displaySequence": -1,
                                  "Id": "a0F4x000000wKnGEAU",
                                  "currencySymbol": "$",
                                  "currencyCode": "USD",
                                  "IsDeleted": false,
                                  "Name": "Comprehensive",
                                  "CreatedDate": "2021-02-10T17:19:34.000+0000",
                                  "CreatedById": "0054x000003KYHhAAO",
                                  "LastModifiedDate": "2021-02-10T17:19:34.000+0000",
                                  "LastModifiedById": "0054x000003KYHhAAO",
                                  "SystemModstamp": "2021-02-10T17:19:34.000+0000",
                                  "vlocity_ins__PolicyAssetId__c": "02i4x000000gnisAAA",
                                  "vlocity_ins__AggregateLimitAmount__c": 0,
                                  "vlocity_ins__AssetInsuredItemId__c": "a0G4x000000X1CbEAK",
                                  "vlocity_ins__AttributeSelectedValues__c": "{\"autoCompDedClmCov\":100}",
                                  "vlocity_ins__DeductibleAmount__c": 0,
                                  "vlocity_ins__PremiumAmount__c": 248.69,
                                  "Price": 248.69,
                                  "vlocity_ins__Product2Id__c": "01t4x000001y3a1AAA",
                                  "vlocity_ins__ProductChildItemId__c": "a484x000000Zh9nAAC",
                                  "vlocity_ins__RecordTypeName__c": "CoverageSpec",
                                  "vlocity_ins__StartDate__c": "2021-02-10T08:00:00.000+0000",
                                  "vlocity_ins__TotalAmount__c": 248.69,
                                  "vlocity_ins__TotalProratedAmount__c": 0,
                                  "isOptional": false,
                                  "isSelected": true,
                                  "ProductCode": "autoComp",
                                  "productName": "Comprehensive",
                                  "productId": "01t4x000001y3a1AAA",
                                  "pciId": "a484x000000Zh9nAAC",
                                  "PricingSource__c": "premiumCCD",
                                  "attributeCategories": {
                                    "totalSize": 1,
                                    "records": [
                                      {
                                        "displaySequence": 230,
                                        "Code__c": "autoTerms",
                                        "Name": "Auto Terms",
                                        "id": "a0R4P00000JWzkZUAT",
                                        "productAttributes": {
                                          "totalSize": 1,
                                          "records": [
                                            {
                                              "code": "autoCompDedClmCov",
                                              "dataType": "currency",
                                              "inputType": "dropdown",
                                              "multiselect": false,
                                              "required": false,
                                              "readonly": false,
                                              "disabled": false,
                                              "filterable": true,
                                              "attributeId": "a0S4P000009YMK9UAO",
                                              "label": "Comp Deductible",
                                              "displaySequence": 0,
                                              "hasRules": false,
                                              "hidden": false,
                                              "cloneable": true,
                                              "isNotTranslatable": false,
                                              "values": [
                                                {
                                                  "id": "0",
                                                  "label": "$100",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": 100
                                                },
                                                {
                                                  "id": "1",
                                                  "label": "$250",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": 250
                                                },
                                                {
                                                  "id": "2",
                                                  "label": "$500",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": 500
                                                },
                                                {
                                                  "id": "3",
                                                  "label": "$750",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": 750
                                                },
                                                {
                                                  "id": "4",
                                                  "label": "$1000",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": 1000
                                                },
                                                {
                                                  "id": "5",
                                                  "label": "$1500",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": 1500
                                                },
                                                {
                                                  "id": "6",
                                                  "label": "$2500",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": 2500
                                                }
                                              ],
                                              "userValues": 100
                                            }
                                          ]
                                        }
                                      }
                                    ]
                                  }
                                },
                                {
                                  "displaySequence": -1,
                                  "Id": "a0F4x000000wKnHEAU",
                                  "currencySymbol": "$",
                                  "currencyCode": "USD",
                                  "IsDeleted": false,
                                  "Name": "Medical Payments",
                                  "CreatedDate": "2021-02-10T17:19:34.000+0000",
                                  "CreatedById": "0054x000003KYHhAAO",
                                  "LastModifiedDate": "2021-02-10T17:19:34.000+0000",
                                  "LastModifiedById": "0054x000003KYHhAAO",
                                  "SystemModstamp": "2021-02-10T17:19:34.000+0000",
                                  "vlocity_ins__PolicyAssetId__c": "02i4x000000gnisAAA",
                                  "vlocity_ins__AggregateLimitAmount__c": 0,
                                  "vlocity_ins__AssetInsuredItemId__c": "a0G4x000000X1CbEAK",
                                  "vlocity_ins__AttributeSelectedValues__c": "{\"autoMedPayLimClmCov\":1000}",
                                  "vlocity_ins__DeductibleAmount__c": 0,
                                  "vlocity_ins__PremiumAmount__c": 37.32,
                                  "Price": 37.32,
                                  "vlocity_ins__Product2Id__c": "01t4x000001y3aKAAQ",
                                  "vlocity_ins__ProductChildItemId__c": "a484x000000Zh9oAAC",
                                  "vlocity_ins__RecordTypeName__c": "CoverageSpec",
                                  "vlocity_ins__StartDate__c": "2021-02-10T08:00:00.000+0000",
                                  "vlocity_ins__TotalAmount__c": 37.32,
                                  "vlocity_ins__TotalProratedAmount__c": 0,
                                  "isOptional": false,
                                  "isSelected": true,
                                  "ProductCode": "autoMedical",
                                  "productName": "Medical Payments",
                                  "productId": "01t4x000001y3aKAAQ",
                                  "pciId": "a484x000000Zh9oAAC",
                                  "PricingSource__c": "premiumMED",
                                  "attributeCategories": {
                                    "totalSize": 1,
                                    "records": [
                                      {
                                        "displaySequence": 230,
                                        "Code__c": "autoTerms",
                                        "Name": "Auto Terms",
                                        "id": "a0R4P00000JWzkZUAT",
                                        "productAttributes": {
                                          "totalSize": 1,
                                          "records": [
                                            {
                                              "code": "autoMedPayLimClmCov",
                                              "dataType": "currency",
                                              "inputType": "dropdown",
                                              "multiselect": false,
                                              "required": false,
                                              "readonly": false,
                                              "disabled": false,
                                              "filterable": true,
                                              "attributeId": "a0S4P000009YMKCUA4",
                                              "label": "Med Pay Person Limit",
                                              "displaySequence": 0,
                                              "hasRules": false,
                                              "hidden": false,
                                              "cloneable": true,
                                              "isNotTranslatable": false,
                                              "values": [
                                                {
                                                  "id": "0",
                                                  "label": "$1000",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": 1000
                                                },
                                                {
                                                  "id": "1",
                                                  "label": "$2000",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": 2000
                                                },
                                                {
                                                  "id": "2",
                                                  "label": "$5000",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": 5000
                                                }
                                              ],
                                              "userValues": 1000
                                            }
                                          ]
                                        }
                                      }
                                    ]
                                  }
                                },
                                {
                                  "displaySequence": -1,
                                  "Id": "a0F4x000000wKnIEAU",
                                  "currencySymbol": "$",
                                  "currencyCode": "USD",
                                  "IsDeleted": false,
                                  "Name": "Uninsured Motorist",
                                  "CreatedDate": "2021-02-10T17:19:34.000+0000",
                                  "CreatedById": "0054x000003KYHhAAO",
                                  "LastModifiedDate": "2021-02-10T17:19:34.000+0000",
                                  "LastModifiedById": "0054x000003KYHhAAO",
                                  "SystemModstamp": "2021-02-10T17:19:34.000+0000",
                                  "vlocity_ins__PolicyAssetId__c": "02i4x000000gnisAAA",
                                  "vlocity_ins__AggregateLimitAmount__c": 0,
                                  "vlocity_ins__AssetInsuredItemId__c": "a0G4x000000X1CbEAK",
                                  "vlocity_ins__AttributeSelectedValues__c": "{\"autoUMLimit\":\"50/100\"}",
                                  "vlocity_ins__DeductibleAmount__c": 0,
                                  "vlocity_ins__PremiumAmount__c": 68.22,
                                  "Price": 68.22,
                                  "vlocity_ins__Product2Id__c": "01t4x000001y3ZzAAI",
                                  "vlocity_ins__ProductChildItemId__c": "a484x000000Zh9sAAC",
                                  "vlocity_ins__RecordTypeName__c": "CoverageSpec",
                                  "vlocity_ins__StartDate__c": "2021-02-10T08:00:00.000+0000",
                                  "vlocity_ins__TotalAmount__c": 68.22,
                                  "vlocity_ins__TotalProratedAmount__c": 0,
                                  "isOptional": false,
                                  "isSelected": true,
                                  "ProductCode": "autoUM",
                                  "productName": "Uninsured Motorist",
                                  "productId": "01t4x000001y3ZzAAI",
                                  "pciId": "a484x000000Zh9sAAC",
                                  "PricingSource__c": "premiumUM",
                                  "attributeCategories": {
                                    "totalSize": 1,
                                    "records": [
                                      {
                                        "displaySequence": 230,
                                        "Code__c": "autoTerms",
                                        "Name": "Auto Terms",
                                        "id": "a0R4P00000JWzkZUAT",
                                        "productAttributes": {
                                          "totalSize": 1,
                                          "records": [
                                            {
                                              "code": "autoUMLimit",
                                              "dataType": "text",
                                              "inputType": "dropdown",
                                              "multiselect": false,
                                              "required": false,
                                              "readonly": false,
                                              "disabled": false,
                                              "filterable": true,
                                              "attributeId": "a0S4P000009YMKGUA4",
                                              "label": "UM Limit",
                                              "displaySequence": 0,
                                              "hasRules": false,
                                              "hidden": false,
                                              "cloneable": true,
                                              "isNotTranslatable": false,
                                              "values": [
                                                {
                                                  "id": "0",
                                                  "label": "$15,000 / $30,000",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": "15/30"
                                                },
                                                {
                                                  "id": "1",
                                                  "label": "$25,000 / $50,000",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": "25/50"
                                                },
                                                {
                                                  "id": "2",
                                                  "label": "$30,000 / $60,000",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": "30/60"
                                                },
                                                {
                                                  "id": "3",
                                                  "label": "$50,000 / $100,000",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": "50/100"
                                                },
                                                {
                                                  "id": "4",
                                                  "label": "$100,000 / $300,000",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": "100/300"
                                                },
                                                {
                                                  "id": "5",
                                                  "label": "$250,000 / $500,000",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": "250/500"
                                                },
                                                {
                                                  "id": "6",
                                                  "label": "$500,000 / $500,000",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": "500/500"
                                                },
                                                {
                                                  "id": "7",
                                                  "label": "$500,000 / $1,000,000",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": "500/1000"
                                                }
                                              ],
                                              "userValues": "50/100"
                                            }
                                          ]
                                        }
                                      }
                                    ]
                                  }
                                },
                                {
                                  "displaySequence": -1,
                                  "productId": "01t4x000001y3aRAAQ",
                                  "productName": "Rental Car",
                                  "ProductCode": "autoRental",
                                  "Name": "Rental Car",
                                  "pciId": "a484x000000Zh9tAAC",
                                  "isOptional": true,
                                  "isSelected": false,
                                  "vlocity_ins__RecordTypeName__c": "CoverageSpec",
                                  "vlocity_ins__PricingSource__c": "premiumRental",
                                  "attributeCategories": {
                                    "totalSize": 1,
                                    "records": [
                                      {
                                        "displaySequence": 230,
                                        "Code__c": "autoTerms",
                                        "Name": "Auto Terms",
                                        "id": "a0R4P00000JWzkZUAT",
                                        "productAttributes": {
                                          "totalSize": 2,
                                          "records": [
                                            {
                                              "code": "autoRentalLimClmCov",
                                              "dataType": "currency",
                                              "inputType": "number",
                                              "multiselect": false,
                                              "required": false,
                                              "readonly": true,
                                              "disabled": true,
                                              "filterable": true,
                                              "attributeId": "a0S4P000009YMKFUA4",
                                              "label": "Rental Limit",
                                              "displaySequence": 0,
                                              "hasRules": false,
                                              "hidden": false,
                                              "cloneable": true,
                                              "isNotTranslatable": false,
                                              "values": [
                                                {
                                                  "readonly": true,
                                                  "disabled": true
                                                }
                                              ],
                                              "userValues": 2000
                                            },
                                            {
                                              "code": "autoRentalDays",
                                              "dataType": "number",
                                              "inputType": "number",
                                              "multiselect": false,
                                              "required": false,
                                              "readonly": true,
                                              "disabled": true,
                                              "filterable": true,
                                              "attributeId": "a0S4P000009YMKEUA4",
                                              "label": "Number of Days",
                                              "displaySequence": 1,
                                              "hasRules": false,
                                              "hidden": false,
                                              "cloneable": true,
                                              "isNotTranslatable": false,
                                              "values": [
                                                {
                                                  "readonly": true,
                                                  "disabled": true
                                                }
                                              ],
                                              "userValues": 30
                                            }
                                          ]
                                        }
                                      }
                                    ]
                                  }
                                }
                              ]
                            }
                          },
                          {
                            "displaySequence": -1,
                            "Id": "a0H4x000001U2foEAC",
                            "currencySymbol": "$",
                            "currencyCode": "USD",
                            "IsDeleted": false,
                            "Name": "David Flan",
                            "instanceKey": "David Flan",
                            "CreatedDate": "2021-02-10T17:19:34.000+0000",
                            "CreatedById": "0054x000003KYHhAAO",
                            "LastModifiedDate": "2021-02-10T17:19:34.000+0000",
                            "LastModifiedById": "0054x000003KYHhAAO",
                            "SystemModstamp": "2021-02-10T17:19:34.000+0000",
                            "vlocity_ins__AssetId__c": "02i4x000000gnisAAA",
                            "vlocity_ins__AttributeSelectedValues__c": "{\"adAge\":34,\"adBirthdate\":\"1986-02-14T08:00:00.000Z\",\"adAgeLicensed\":16,\"adFirstName\":\"David\",\"adGender\":\"M\",\"adLastName\":\"Flan\",\"adMiddle\":\"M\",\"adMaritalStatus\":\"M\",\"isParent\":false,\"ProductCode\":\"autoDriver\"}",
                            "vlocity_ins__InsuredPartyNumber__c": "David Flan",
                            "vlocity_ins__InsuredPartySpecId__c": "01t4x000001y3ZvAAI",
                            "vlocity_ins__PartyLink__c": "<a href=\"/\" target=\"_parent\"> </a>",
                            "vlocity_ins__PremiumAmount__c": 0,
                            "Price": 0,
                            "vlocity_ins__RecordTypeName__c": "InsuredPartySpec",
                            "vlocity_ins__TotalAmount__c": 0,
                            "vlocity_ins__TotalProratedAmount__c": 0,
                            "vlocity_ins__IsPolicyholder__c": false,
                            "vlocity_ins__LookupKey__c": "David Flan_",
                            "vlocity_ins__PartyAccountCalculatedAddress__c": "<br>",
                            "hasAttributes": true,
                            "minCount": 1,
                            "maxCount": 1,
                            "productName": "Auto Driver",
                            "productId": "01t4x000001y3ZvAAI",
                            "ProductCode": "autoDriver",
                            "pciId": "a484x000000Zh9rAAC",
                            "hasCoverages": false,
                            "attributeCategories": {
                              "totalSize": 1,
                              "records": [
                                {
                                  "displaySequence": 220,
                                  "Code__c": "autoDriver",
                                  "Name": "Auto Driver",
                                  "id": "a0R4P00000J2MJxUAN",
                                  "productAttributes": {
                                    "totalSize": 21,
                                    "records": [
                                      {
                                        "code": "adSuffix",
                                        "dataType": "text",
                                        "inputType": "text",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": false,
                                        "disabled": false,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VoezUAC",
                                        "label": "Suffix",
                                        "displaySequence": 0,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": false,
                                            "disabled": false
                                          }
                                        ],
                                        "userValues": null
                                      },
                                      {
                                        "code": "adFirstName",
                                        "dataType": "text",
                                        "inputType": "text",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": false,
                                        "disabled": false,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VoemUAC",
                                        "label": "First Name",
                                        "displaySequence": 1,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": false,
                                            "disabled": false
                                          }
                                        ],
                                        "userValues": "David"
                                      },
                                      {
                                        "code": "adMiddle",
                                        "dataType": "text",
                                        "inputType": "text",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": false,
                                        "disabled": false,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VoevUAC",
                                        "label": "Middle Name",
                                        "displaySequence": 2,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": false,
                                            "disabled": false
                                          }
                                        ],
                                        "userValues": "M"
                                      },
                                      {
                                        "code": "adLastName",
                                        "dataType": "text",
                                        "inputType": "text",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": false,
                                        "disabled": false,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VoeqUAC",
                                        "label": "Last Name",
                                        "displaySequence": 3,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": false,
                                            "disabled": false
                                          }
                                        ],
                                        "userValues": "Flan"
                                      },
                                      {
                                        "code": "adBirthdate",
                                        "dataType": "date",
                                        "inputType": "date",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": false,
                                        "disabled": false,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VoelUAC",
                                        "label": "Birthdate",
                                        "displaySequence": 4,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": false,
                                            "disabled": false
                                          }
                                        ],
                                        "userValues": "1986-02-14T08:00:00.000Z"
                                      },
                                      {
                                        "code": "adAgeLicensed",
                                        "dataType": "number",
                                        "inputType": "number",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": false,
                                        "disabled": false,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VoekUAC",
                                        "label": "Age First Licensed",
                                        "displaySequence": 5,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": false,
                                            "disabled": false
                                          }
                                        ],
                                        "userValues": 16
                                      },
                                      {
                                        "code": "adGender",
                                        "dataType": "text",
                                        "inputType": "dropdown",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": false,
                                        "disabled": false,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VoeoUAC",
                                        "label": "Gender",
                                        "displaySequence": 6,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "id": "2",
                                            "label": "Male",
                                            "readonly": false,
                                            "disabled": false,
                                            "value": "M"
                                          },
                                          {
                                            "id": "1",
                                            "label": "Female",
                                            "readonly": false,
                                            "disabled": false,
                                            "value": "F"
                                          }
                                        ],
                                        "userValues": "M"
                                      },
                                      {
                                        "code": "adMaritalStatus",
                                        "dataType": "text",
                                        "inputType": "dropdown",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": false,
                                        "disabled": false,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VoeuUAC",
                                        "label": "Marital Status",
                                        "displaySequence": 7,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "id": "1",
                                            "label": "Married",
                                            "readonly": false,
                                            "disabled": false,
                                            "value": "M"
                                          },
                                          {
                                            "id": "0",
                                            "label": "Single",
                                            "readonly": false,
                                            "disabled": false,
                                            "value": "S"
                                          }
                                        ],
                                        "userValues": "M"
                                      },
                                      {
                                        "code": "adAccidentPoints",
                                        "dataType": "number",
                                        "inputType": "number",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": false,
                                        "disabled": false,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VoeiUAC",
                                        "label": "Driver Accident Points",
                                        "displaySequence": 8,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": false,
                                            "disabled": false
                                          }
                                        ],
                                        "userValues": null
                                      },
                                      {
                                        "code": "adMVRPoints",
                                        "dataType": "number",
                                        "inputType": "number",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": false,
                                        "disabled": false,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VoetUAC",
                                        "label": "Driver MVR Points",
                                        "displaySequence": 9,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": false,
                                            "disabled": false
                                          }
                                        ],
                                        "userValues": null
                                      },
                                      {
                                        "code": "adMileage",
                                        "dataType": "number",
                                        "inputType": "number",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": false,
                                        "disabled": false,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VoewUAC",
                                        "label": "Driver Annual Mileage",
                                        "displaySequence": 10,
                                        "hasRules": false,
                                        "hidden": true,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": false,
                                            "disabled": false
                                          }
                                        ],
                                        "userValues": null
                                      },
                                      {
                                        "code": "adGoodStudent",
                                        "dataType": "text",
                                        "inputType": "text",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": false,
                                        "disabled": false,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VoepUAC",
                                        "label": "Good Student",
                                        "displaySequence": 11,
                                        "hasRules": false,
                                        "hidden": true,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": false,
                                            "disabled": false
                                          }
                                        ],
                                        "userValues": null
                                      },
                                      {
                                        "code": "adGPA",
                                        "dataType": "number",
                                        "inputType": "number",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": false,
                                        "disabled": false,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VoenUAC",
                                        "label": "GPA",
                                        "displaySequence": 12,
                                        "hasRules": false,
                                        "hidden": true,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": false,
                                            "disabled": false
                                          }
                                        ],
                                        "userValues": null
                                      },
                                      {
                                        "code": "adLicenseNum",
                                        "dataType": "text",
                                        "inputType": "text",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": false,
                                        "disabled": false,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VoerUAC",
                                        "label": "License Number",
                                        "displaySequence": 13,
                                        "hasRules": false,
                                        "hidden": true,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": false,
                                            "disabled": false
                                          }
                                        ],
                                        "userValues": null
                                      },
                                      {
                                        "code": "adName",
                                        "dataType": "text",
                                        "inputType": "text",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": false,
                                        "disabled": false,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VoexUAC",
                                        "label": "Name",
                                        "displaySequence": 14,
                                        "hasRules": false,
                                        "hidden": true,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": false,
                                            "disabled": false
                                          }
                                        ],
                                        "userValues": null
                                      },
                                      {
                                        "code": "adUse",
                                        "dataType": "text",
                                        "inputType": "text",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": false,
                                        "disabled": false,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004Vof1UAC",
                                        "label": "Primary Use",
                                        "displaySequence": 15,
                                        "hasRules": false,
                                        "hidden": true,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": false,
                                            "disabled": false
                                          }
                                        ],
                                        "userValues": null
                                      },
                                      {
                                        "code": "adSafeDriver",
                                        "dataType": "text",
                                        "inputType": "text",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": false,
                                        "disabled": false,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VoeyUAC",
                                        "label": "Safe Driver",
                                        "displaySequence": 16,
                                        "hasRules": false,
                                        "hidden": true,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": false,
                                            "disabled": false
                                          }
                                        ],
                                        "userValues": null
                                      },
                                      {
                                        "code": "adLicenseState",
                                        "dataType": "text",
                                        "inputType": "text",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": false,
                                        "disabled": false,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VoesUAC",
                                        "label": "State Licensed",
                                        "displaySequence": 17,
                                        "hasRules": false,
                                        "hidden": true,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": false,
                                            "disabled": false
                                          }
                                        ],
                                        "userValues": null
                                      },
                                      {
                                        "code": "adTotalPoints",
                                        "dataType": "number",
                                        "inputType": "number",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": false,
                                        "disabled": false,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004Vof0UAC",
                                        "label": "Total Points",
                                        "displaySequence": 18,
                                        "hasRules": false,
                                        "hidden": true,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": false,
                                            "disabled": false
                                          }
                                        ],
                                        "userValues": null
                                      },
                                      {
                                        "code": "adYrsExp",
                                        "dataType": "number",
                                        "inputType": "number",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": false,
                                        "disabled": false,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004Vof2UAC",
                                        "label": "Years Experience",
                                        "displaySequence": 19,
                                        "hasRules": false,
                                        "hidden": true,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": false,
                                            "disabled": false
                                          }
                                        ],
                                        "userValues": null
                                      },
                                      {
                                        "code": "adAge",
                                        "dataType": "number",
                                        "inputType": "number",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": false,
                                        "disabled": false,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VoejUAC",
                                        "label": "Age",
                                        "displaySequence": 20,
                                        "hasRules": false,
                                        "hidden": true,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": false,
                                            "disabled": false
                                          }
                                        ],
                                        "userValues": 34
                                      }
                                    ]
                                  }
                                }
                              ]
                            }
                          }
                        ]
                      }
                    }
                  ]
                },
                {
                  "totalSize": 0,
                  "records": [
                    {
                      "displaySequence": -1,
                      "Id": "02i4x000000gnixAAA",
                      "productId": "01t4x000001y3bEAAQ",
                      "accountId": "0014x000009kWqOAAU",
                      "productName": "Multi Auto",
                      "Name": "Multi Auto",
                      "EffectiveStart": "2021-02-10",
                      "Price": 2240.03,
                      "PricingFormula__c": "SUM(premiumBIPD + premiumCOLL + premiumCCD + premiumMED + premiumUM+premiumRental)",
                      "ProductCode": "autoMulti",
                      "RecordTypeName__c": "Product",
                      "vlocity_ins__TotalTaxAmount__c": 39.05015,
                      "vlocity_ins__TotalFeeAmount__c": 25,
                      "vlocity_ins__TotalTaxForTerm__c": 39.05015,
                      "vlocity_ins__TotalFeeForTerm__c": 25,
                      "vlocity_ins__TotalAmount__c": 2304.08,
                      "vlocity_ins__TotalAmountForTerm__c": 64.05,
                      "hasAttributes": false,
                      "taxesAndFees": [
                        {
                          "currencySymbol": "$",
                          "currencyCode": "USD",
                          "calculatedAmount": 25,
                          "PriceListEntryName__c": "573608e0-7b1c-9b66-a435-d584218c5305",
                          "PriceListEntryId__c": "a3u4x000000cabtAAA",
                          "isRefundable": false,
                          "Amount__c": 25,
                          "AdjustmentType__c": "Fee",
                          "Id": "a0I4x000001Z3ASEA0"
                        },
                        {
                          "currencySymbol": "$",
                          "currencyCode": "USD",
                          "calculatedAmount": 27.85,
                          "PriceListEntryName__c": "7457f382-f935-3308-3429-24d9dfac88f4",
                          "PriceListEntryId__c": "a3u4x000000cabuAAA",
                          "isRefundable": true,
                          "Amount__c": 27.85,
                          "AdjustmentType__c": "Tax",
                          "Id": "a0I4x000001Z3ATEA0"
                        },
                        {
                          "currencySymbol": "$",
                          "currencyCode": "USD",
                          "calculatedAmount": 0,
                          "PriceListEntryName__c": "7eee88c5-37d5-3991-02db-37ef3343982f",
                          "PriceListEntryId__c": "a3u4x000000cabvAAA",
                          "isRefundable": false,
                          "Amount__c": 0,
                          "AdjustmentType__c": "Tax",
                          "Id": "a0I4x000001Z3AUEA0"
                        },
                        {
                          "currencySymbol": "$",
                          "currencyCode": "USD",
                          "calculatedAmount": 11.20015,
                          "PriceListEntryName__c": "93b485fc-a7ce-a358-929d-e0381289b239",
                          "PriceListEntryId__c": "a3u4x000000cabwAAA",
                          "isRefundable": true,
                          "Amount__c": 11.20015,
                          "AdjustmentType__c": "Tax",
                          "Id": "a0I4x000001Z3AVEA0"
                        }
                      ],
                      "taxAmount": 39.05015,
                      "feeAmount": 25,
                      "totalTaxFeeAmount": 64.05015,
                      "coverageCount": 0,
                      "childProducts": {
                        "totalSize": 3,
                        "records": [
                          {
                            "displaySequence": -1,
                            "Id": "a0G4x000000X1CfEAK",
                            "currencySymbol": "$",
                            "currencyCode": "USD",
                            "IsDeleted": false,
                            "Name": "2019 BMW M3",
                            "instanceKey": "2019 BMW M3",
                            "CreatedDate": "2021-02-10T17:19:59.000+0000",
                            "CreatedById": "0054x000003KYHhAAO",
                            "LastModifiedDate": "2021-02-10T17:19:59.000+0000",
                            "LastModifiedById": "0054x000003KYHhAAO",
                            "SystemModstamp": "2021-02-10T17:19:59.000+0000",
                            "vlocity_ins__PolicyAssetId__c": "02i4x000000gnixAAA",
                            "vlocity_ins__AttributeSelectedValues__c": "{\"avRestraints\":false,\"ProductCode\":\"autoVehicle\",\"avBodyType\":\"Sedan/Saloon\",\"avBrakes\":false,\"avHistoric\":false,\"avModel\":\"M3\",\"avStabilization\":true,\"avGaragePostalCode\":\"94110\",\"isParent\":true,\"avMake\":\"BMW\",\"avValue\":45000,\"avMileage\":10000,\"avYear\":\"2019\",\"avAntiTheft\":true,\"avAltFuel\":false}",
                            "vlocity_ins__InsuredItemNumber__c": "2019 BMW M3",
                            "vlocity_ins__MarketValue__c": 0,
                            "vlocity_ins__PremiumAmount__c": 1096.96,
                            "Price": 1096.96,
                            "vlocity_ins__Product2Id__c": "01t4x000001y3a0AAA",
                            "vlocity_ins__ProductChildItemId__c": "a484x000000Zh9qAAC",
                            "vlocity_ins__RecordTypeName__c": "InsuredItemSpec",
                            "vlocity_ins__TotalAmount__c": 1096.96,
                            "vlocity_ins__TotalProratedAmount__c": 0,
                            "hasAttributes": true,
                            "PricingFormula__c": "premiumBIPD + premiumCOLL + premiumCCD + premiumMED + premiumUM+premiumRental",
                            "minCount": 1,
                            "maxCount": 1,
                            "productName": "Vehicle",
                            "productId": "01t4x000001y3a0AAA",
                            "ProductCode": "autoVehicle",
                            "pciId": "a484x000000Zh9qAAC",
                            "hasCoverages": true,
                            "attributeCategories": {
                              "totalSize": 1,
                              "records": [
                                {
                                  "displaySequence": 210,
                                  "Code__c": "autoVehicle",
                                  "Name": "Auto Vehicle",
                                  "id": "a0R4P00000J2MJyUAN",
                                  "productAttributes": {
                                    "totalSize": 27,
                                    "records": [
                                      {
                                        "code": "avValue",
                                        "dataType": "currency",
                                        "inputType": "number",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": true,
                                        "disabled": true,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofbUAC",
                                        "label": "Value",
                                        "displaySequence": 0,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": true,
                                            "disabled": true
                                          }
                                        ],
                                        "userValues": 45000
                                      },
                                      {
                                        "code": "avAltFuel",
                                        "dataType": "text",
                                        "inputType": "checkbox",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": true,
                                        "disabled": true,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofCUAS",
                                        "label": "Alternative Fuel",
                                        "displaySequence": 1,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": true,
                                            "disabled": true
                                          }
                                        ],
                                        "userValues": false
                                      },
                                      {
                                        "code": "avAntiTheft",
                                        "dataType": "text",
                                        "inputType": "checkbox",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": true,
                                        "disabled": true,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofDUAS",
                                        "label": "Anti Theft",
                                        "displaySequence": 2,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": true,
                                            "disabled": true
                                          }
                                        ],
                                        "userValues": true
                                      },
                                      {
                                        "code": "avBrakes",
                                        "dataType": "text",
                                        "inputType": "checkbox",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": true,
                                        "disabled": true,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofFUAS",
                                        "label": "Brakes",
                                        "displaySequence": 3,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": true,
                                            "disabled": true
                                          }
                                        ],
                                        "userValues": false
                                      },
                                      {
                                        "code": "avClaimFreq",
                                        "dataType": "number",
                                        "inputType": "number",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": true,
                                        "disabled": true,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofGUAS",
                                        "label": "Claim Frequency",
                                        "displaySequence": 4,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": true,
                                            "disabled": true
                                          }
                                        ],
                                        "userValues": null
                                      },
                                      {
                                        "code": "avClaimSev",
                                        "dataType": "number",
                                        "inputType": "number",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": true,
                                        "disabled": true,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofHUAS",
                                        "label": "Claim Severity",
                                        "displaySequence": 5,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": true,
                                            "disabled": true
                                          }
                                        ],
                                        "userValues": null
                                      },
                                      {
                                        "code": "avLicNum",
                                        "dataType": "text",
                                        "inputType": "text",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": true,
                                        "disabled": true,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofLUAS",
                                        "label": "License Number",
                                        "displaySequence": 6,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": true,
                                            "disabled": true
                                          }
                                        ],
                                        "userValues": null
                                      },
                                      {
                                        "code": "avLicState",
                                        "dataType": "text",
                                        "inputType": "text",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": true,
                                        "disabled": true,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofMUAS",
                                        "label": "License State",
                                        "displaySequence": 7,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": true,
                                            "disabled": true
                                          }
                                        ],
                                        "userValues": null
                                      },
                                      {
                                        "code": "avMake",
                                        "dataType": "text",
                                        "inputType": "text",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": true,
                                        "disabled": true,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofNUAS",
                                        "label": "Make",
                                        "displaySequence": 8,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": true,
                                            "disabled": true
                                          }
                                        ],
                                        "userValues": "BMW"
                                      },
                                      {
                                        "code": "avModel",
                                        "dataType": "text",
                                        "inputType": "text",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": true,
                                        "disabled": true,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofPUAS",
                                        "label": "Model",
                                        "displaySequence": 9,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": true,
                                            "disabled": true
                                          }
                                        ],
                                        "userValues": "M3"
                                      },
                                      {
                                        "code": "avRatedDriver-BIPD",
                                        "dataType": "number",
                                        "inputType": "number",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": true,
                                        "disabled": true,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofQUAS",
                                        "label": "Rated Driver - BIPD",
                                        "displaySequence": 10,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": true,
                                            "disabled": true
                                          }
                                        ],
                                        "userValues": null
                                      },
                                      {
                                        "code": "avRatedDriver-COMP",
                                        "dataType": "number",
                                        "inputType": "number",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": true,
                                        "disabled": true,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofSUAS",
                                        "label": "Rated Driver - Comprehensive",
                                        "displaySequence": 11,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": true,
                                            "disabled": true
                                          }
                                        ],
                                        "userValues": null
                                      },
                                      {
                                        "code": "avRatedDriver-MED",
                                        "dataType": "number",
                                        "inputType": "number",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": true,
                                        "disabled": true,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofTUAS",
                                        "label": "Rated Driver - Medical Payments",
                                        "displaySequence": 12,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": true,
                                            "disabled": true
                                          }
                                        ],
                                        "userValues": null
                                      },
                                      {
                                        "code": "avRatedDriver-UM",
                                        "dataType": "number",
                                        "inputType": "number",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": true,
                                        "disabled": true,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofUUAS",
                                        "label": "Rated Driver - Uninsured Motorist",
                                        "displaySequence": 13,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": true,
                                            "disabled": true
                                          }
                                        ],
                                        "userValues": null
                                      },
                                      {
                                        "code": "avRatedDriverName",
                                        "dataType": "text",
                                        "inputType": "text",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": true,
                                        "disabled": true,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofVUAS",
                                        "label": "Rated Driver Name",
                                        "displaySequence": 14,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": true,
                                            "disabled": true
                                          }
                                        ],
                                        "userValues": null
                                      },
                                      {
                                        "code": "avRestraints",
                                        "dataType": "text",
                                        "inputType": "checkbox",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": true,
                                        "disabled": true,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofWUAS",
                                        "label": "Restraints",
                                        "displaySequence": 15,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": true,
                                            "disabled": true
                                          }
                                        ],
                                        "userValues": false
                                      },
                                      {
                                        "code": "avStabilization",
                                        "dataType": "text",
                                        "inputType": "checkbox",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": true,
                                        "disabled": true,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofXUAS",
                                        "label": "Stablization",
                                        "displaySequence": 16,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": true,
                                            "disabled": true
                                          }
                                        ],
                                        "userValues": true
                                      },
                                      {
                                        "code": "avHistoric",
                                        "dataType": "text",
                                        "inputType": "checkbox",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": false,
                                        "disabled": false,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofKUAS",
                                        "label": "Historic",
                                        "displaySequence": 17,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": false,
                                            "disabled": false
                                          }
                                        ],
                                        "userValues": false
                                      },
                                      {
                                        "code": "avStyle",
                                        "dataType": "text",
                                        "inputType": "text",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": true,
                                        "disabled": true,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofYUAS",
                                        "label": "Style",
                                        "displaySequence": 18,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": true,
                                            "disabled": true
                                          }
                                        ],
                                        "userValues": null
                                      },
                                      {
                                        "code": "avSymbol",
                                        "dataType": "text",
                                        "inputType": "text",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": true,
                                        "disabled": true,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofZUAS",
                                        "label": "Symbol",
                                        "displaySequence": 19,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": true,
                                            "disabled": true
                                          }
                                        ],
                                        "userValues": null
                                      },
                                      {
                                        "code": "avColor",
                                        "dataType": "text",
                                        "inputType": "text",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": true,
                                        "disabled": true,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofIUAS",
                                        "label": "Color",
                                        "displaySequence": 20,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": true,
                                            "disabled": true
                                          }
                                        ],
                                        "userValues": null
                                      },
                                      {
                                        "code": "avVIN",
                                        "dataType": "text",
                                        "inputType": "text",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": true,
                                        "disabled": true,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofaUAC",
                                        "label": "VIN",
                                        "displaySequence": 21,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": true,
                                            "disabled": true
                                          }
                                        ],
                                        "userValues": null
                                      },
                                      {
                                        "code": "avYear",
                                        "dataType": "text",
                                        "inputType": "text",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": true,
                                        "disabled": true,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofcUAC",
                                        "label": "Year",
                                        "displaySequence": 22,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": true,
                                            "disabled": true
                                          }
                                        ],
                                        "userValues": "2019"
                                      },
                                      {
                                        "code": "avMileage",
                                        "dataType": "number",
                                        "inputType": "number",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": true,
                                        "disabled": true,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofOUAS",
                                        "label": "Annual Mileage",
                                        "displaySequence": 23,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": true,
                                            "disabled": true
                                          }
                                        ],
                                        "userValues": 10000
                                      },
                                      {
                                        "code": "avBodyType",
                                        "dataType": "text",
                                        "inputType": "text",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": true,
                                        "disabled": true,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofEUAS",
                                        "label": "Body Type",
                                        "displaySequence": 24,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": true,
                                            "disabled": true
                                          }
                                        ],
                                        "userValues": "Sedan/Saloon"
                                      },
                                      {
                                        "code": "avGaragePostalCode",
                                        "dataType": "text",
                                        "inputType": "text",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": true,
                                        "disabled": true,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofJUAS",
                                        "label": "Garage Location (Postal Code)",
                                        "displaySequence": 25,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": true,
                                            "disabled": true
                                          }
                                        ],
                                        "userValues": "94110"
                                      },
                                      {
                                        "code": "avRatedDriver-COLL",
                                        "dataType": "number",
                                        "inputType": "number",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": true,
                                        "disabled": true,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofRUAS",
                                        "label": "Rated Driver - Collision",
                                        "displaySequence": 26,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": true,
                                            "disabled": true
                                          }
                                        ],
                                        "userValues": null
                                      }
                                    ]
                                  }
                                }
                              ]
                            },
                            "childProducts": {
                              "totalSize": 6,
                              "records": [
                                {
                                  "displaySequence": -1,
                                  "Id": "a0F4x000000wKnTEAU",
                                  "currencySymbol": "$",
                                  "currencyCode": "USD",
                                  "IsDeleted": false,
                                  "Name": "Bodily Injury & Property Damage",
                                  "CreatedDate": "2021-02-10T17:19:59.000+0000",
                                  "CreatedById": "0054x000003KYHhAAO",
                                  "LastModifiedDate": "2021-02-10T17:19:59.000+0000",
                                  "LastModifiedById": "0054x000003KYHhAAO",
                                  "SystemModstamp": "2021-02-10T17:19:59.000+0000",
                                  "vlocity_ins__PolicyAssetId__c": "02i4x000000gnixAAA",
                                  "vlocity_ins__AggregateLimitAmount__c": 0,
                                  "vlocity_ins__AssetInsuredItemId__c": "a0G4x000000X1CfEAK",
                                  "vlocity_ins__AttributeSelectedValues__c": "{\"autoBIPDLimit.autoPDLimClm\":25000,\"autoBIPDLimit.autoBILimClm\":50000,\"autoBIPDLimit.autoBILimClmCov\":25000,\"autoBIPDLimit\":\"25000/50000/25000\"}",
                                  "vlocity_ins__DeductibleAmount__c": 0,
                                  "vlocity_ins__PremiumAmount__c": 14.31,
                                  "Price": 14.31,
                                  "vlocity_ins__Product2Id__c": "01t4x000001y3ZiAAI",
                                  "vlocity_ins__ProductChildItemId__c": "a484x000000ZhDPAA0",
                                  "vlocity_ins__RecordTypeName__c": "CoverageSpec",
                                  "vlocity_ins__StartDate__c": "2021-02-10T08:00:00.000+0000",
                                  "vlocity_ins__TotalAmount__c": 14.31,
                                  "vlocity_ins__TotalProratedAmount__c": 0,
                                  "isOptional": false,
                                  "isSelected": true,
                                  "ProductCode": "autoBIPD",
                                  "productName": "Bodily Injury & Property Damage",
                                  "productId": "01t4x000001y3ZiAAI",
                                  "pciId": "a484x000000ZhDPAA0",
                                  "PricingSource__c": "premiumBIPD",
                                  "attributeCategories": {
                                    "totalSize": 1,
                                    "records": [
                                      {
                                        "displaySequence": 230,
                                        "Code__c": "autoTerms",
                                        "Name": "Auto Terms",
                                        "id": "a0R4P00000JWzkZUAT",
                                        "productAttributes": {
                                          "totalSize": 1,
                                          "records": [
                                            {
                                              "code": "autoBIPDLimit",
                                              "dataType": "text",
                                              "inputType": "dropdown",
                                              "multiselect": false,
                                              "required": false,
                                              "readonly": false,
                                              "disabled": false,
                                              "filterable": true,
                                              "attributeId": "a0S4P000009YMK7UAO",
                                              "label": "BIPD Limit",
                                              "displaySequence": 0,
                                              "hasRules": true,
                                              "hidden": false,
                                              "cloneable": true,
                                              "isNotTranslatable": false,
                                              "values": [
                                                {
                                                  "id": "0",
                                                  "label": "$15000/$30000/$10000",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": "15000/30000/10000"
                                                },
                                                {
                                                  "id": "1",
                                                  "label": "$15000/$30000/$5000",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": "15000/30000/5000"
                                                },
                                                {
                                                  "id": "2",
                                                  "label": "$25000/$50000/$25000",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": "25000/50000/25000"
                                                },
                                                {
                                                  "id": "3",
                                                  "label": "$25000/$50000/$50000",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": "25000/50000/50000"
                                                },
                                                {
                                                  "id": "4",
                                                  "label": "$50000/$100000/$50000",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": "50000/100000/50000"
                                                },
                                                {
                                                  "id": "5",
                                                  "label": "$50000/$100000/$100000",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": "50000/100000/100000"
                                                },
                                                {
                                                  "id": "6",
                                                  "label": "$100000/$300000/$25000",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": "100000/300000/25000"
                                                },
                                                {
                                                  "id": "7",
                                                  "label": "$100000/$300000/$50000",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": "100000/300000/50000"
                                                },
                                                {
                                                  "id": "8",
                                                  "label": "$100000/$300000/$100000",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": "100000/300000/100000"
                                                },
                                                {
                                                  "id": "9",
                                                  "label": "$250000/$500000/$100000",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": "250000/500000/100000"
                                                },
                                                {
                                                  "id": "10",
                                                  "label": "$500000/$500000/100000",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": "500000/500000/100000"
                                                },
                                                {
                                                  "id": "11",
                                                  "label": "$500000/$500000/$500000",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": "500000/500000/500000"
                                                },
                                                {
                                                  "id": "12",
                                                  "label": "$500000/$1000000/$500000",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": "500000/1000000/500000"
                                                }
                                              ],
                                              "userValues": "25000/50000/25000",
                                              "valueDecoder": "autoBILimClmCov/autoBILimClm/autoPDLimClm"
                                            }
                                          ]
                                        }
                                      }
                                    ]
                                  }
                                },
                                {
                                  "displaySequence": -1,
                                  "Id": "a0F4x000000wKnUEAU",
                                  "currencySymbol": "$",
                                  "currencyCode": "USD",
                                  "IsDeleted": false,
                                  "Name": "Collision",
                                  "CreatedDate": "2021-02-10T17:19:59.000+0000",
                                  "CreatedById": "0054x000003KYHhAAO",
                                  "LastModifiedDate": "2021-02-10T17:19:59.000+0000",
                                  "LastModifiedById": "0054x000003KYHhAAO",
                                  "SystemModstamp": "2021-02-10T17:19:59.000+0000",
                                  "vlocity_ins__PolicyAssetId__c": "02i4x000000gnixAAA",
                                  "vlocity_ins__AggregateLimitAmount__c": 0,
                                  "vlocity_ins__AssetInsuredItemId__c": "a0G4x000000X1CfEAK",
                                  "vlocity_ins__AttributeSelectedValues__c": "{\"autoCollDedClmCov\":500}",
                                  "vlocity_ins__DeductibleAmount__c": 0,
                                  "vlocity_ins__PremiumAmount__c": 725.63,
                                  "Price": 725.63,
                                  "vlocity_ins__Product2Id__c": "01t4x000001y3aDAAQ",
                                  "vlocity_ins__ProductChildItemId__c": "a484x000000Zh9pAAC",
                                  "vlocity_ins__RecordTypeName__c": "CoverageSpec",
                                  "vlocity_ins__StartDate__c": "2021-02-10T08:00:00.000+0000",
                                  "vlocity_ins__TotalAmount__c": 725.63,
                                  "vlocity_ins__TotalProratedAmount__c": 0,
                                  "isOptional": false,
                                  "isSelected": true,
                                  "ProductCode": "autoCollision",
                                  "productName": "Collision",
                                  "productId": "01t4x000001y3aDAAQ",
                                  "pciId": "a484x000000Zh9pAAC",
                                  "PricingSource__c": "premiumCOLL",
                                  "attributeCategories": {
                                    "totalSize": 1,
                                    "records": [
                                      {
                                        "displaySequence": 230,
                                        "Code__c": "autoTerms",
                                        "Name": "Auto Terms",
                                        "id": "a0R4P00000JWzkZUAT",
                                        "productAttributes": {
                                          "totalSize": 1,
                                          "records": [
                                            {
                                              "code": "autoCollDedClmCov",
                                              "dataType": "currency",
                                              "inputType": "dropdown",
                                              "multiselect": false,
                                              "required": false,
                                              "readonly": false,
                                              "disabled": false,
                                              "filterable": true,
                                              "attributeId": "a0S4P000009YMK8UAO",
                                              "label": "Collision Deductible",
                                              "displaySequence": 0,
                                              "hasRules": false,
                                              "hidden": false,
                                              "cloneable": true,
                                              "isNotTranslatable": false,
                                              "values": [
                                                {
                                                  "id": "0",
                                                  "label": "$250",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": 250
                                                },
                                                {
                                                  "id": "1",
                                                  "label": "$500",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": 500
                                                },
                                                {
                                                  "id": "2",
                                                  "label": "$750",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": 750
                                                },
                                                {
                                                  "id": "3",
                                                  "label": "$1000",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": 1000
                                                },
                                                {
                                                  "id": "4",
                                                  "label": "$1500",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": 1500
                                                },
                                                {
                                                  "id": "5",
                                                  "label": "$2500",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": 2500
                                                }
                                              ],
                                              "userValues": 500
                                            }
                                          ]
                                        }
                                      }
                                    ]
                                  }
                                },
                                {
                                  "displaySequence": -1,
                                  "Id": "a0F4x000000wKnVEAU",
                                  "currencySymbol": "$",
                                  "currencyCode": "USD",
                                  "IsDeleted": false,
                                  "Name": "Comprehensive",
                                  "CreatedDate": "2021-02-10T17:19:59.000+0000",
                                  "CreatedById": "0054x000003KYHhAAO",
                                  "LastModifiedDate": "2021-02-10T17:19:59.000+0000",
                                  "LastModifiedById": "0054x000003KYHhAAO",
                                  "SystemModstamp": "2021-02-10T17:19:59.000+0000",
                                  "vlocity_ins__PolicyAssetId__c": "02i4x000000gnixAAA",
                                  "vlocity_ins__AggregateLimitAmount__c": 0,
                                  "vlocity_ins__AssetInsuredItemId__c": "a0G4x000000X1CfEAK",
                                  "vlocity_ins__AttributeSelectedValues__c": "{\"autoCompDedClmCov\":100}",
                                  "vlocity_ins__DeductibleAmount__c": 0,
                                  "vlocity_ins__PremiumAmount__c": 255.71,
                                  "Price": 255.71,
                                  "vlocity_ins__Product2Id__c": "01t4x000001y3a1AAA",
                                  "vlocity_ins__ProductChildItemId__c": "a484x000000Zh9nAAC",
                                  "vlocity_ins__RecordTypeName__c": "CoverageSpec",
                                  "vlocity_ins__StartDate__c": "2021-02-10T08:00:00.000+0000",
                                  "vlocity_ins__TotalAmount__c": 255.71,
                                  "vlocity_ins__TotalProratedAmount__c": 0,
                                  "isOptional": false,
                                  "isSelected": true,
                                  "ProductCode": "autoComp",
                                  "productName": "Comprehensive",
                                  "productId": "01t4x000001y3a1AAA",
                                  "pciId": "a484x000000Zh9nAAC",
                                  "PricingSource__c": "premiumCCD",
                                  "attributeCategories": {
                                    "totalSize": 1,
                                    "records": [
                                      {
                                        "displaySequence": 230,
                                        "Code__c": "autoTerms",
                                        "Name": "Auto Terms",
                                        "id": "a0R4P00000JWzkZUAT",
                                        "productAttributes": {
                                          "totalSize": 1,
                                          "records": [
                                            {
                                              "code": "autoCompDedClmCov",
                                              "dataType": "currency",
                                              "inputType": "dropdown",
                                              "multiselect": false,
                                              "required": false,
                                              "readonly": false,
                                              "disabled": false,
                                              "filterable": true,
                                              "attributeId": "a0S4P000009YMK9UAO",
                                              "label": "Comp Deductible",
                                              "displaySequence": 0,
                                              "hasRules": false,
                                              "hidden": false,
                                              "cloneable": true,
                                              "isNotTranslatable": false,
                                              "values": [
                                                {
                                                  "id": "0",
                                                  "label": "$100",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": 100
                                                },
                                                {
                                                  "id": "1",
                                                  "label": "$250",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": 250
                                                },
                                                {
                                                  "id": "2",
                                                  "label": "$500",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": 500
                                                },
                                                {
                                                  "id": "3",
                                                  "label": "$750",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": 750
                                                },
                                                {
                                                  "id": "4",
                                                  "label": "$1000",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": 1000
                                                },
                                                {
                                                  "id": "5",
                                                  "label": "$1500",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": 1500
                                                },
                                                {
                                                  "id": "6",
                                                  "label": "$2500",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": 2500
                                                }
                                              ],
                                              "userValues": 100
                                            }
                                          ]
                                        }
                                      }
                                    ]
                                  }
                                },
                                {
                                  "displaySequence": -1,
                                  "Id": "a0F4x000000wKnWEAU",
                                  "currencySymbol": "$",
                                  "currencyCode": "USD",
                                  "IsDeleted": false,
                                  "Name": "Medical Payments",
                                  "CreatedDate": "2021-02-10T17:19:59.000+0000",
                                  "CreatedById": "0054x000003KYHhAAO",
                                  "LastModifiedDate": "2021-02-10T17:19:59.000+0000",
                                  "LastModifiedById": "0054x000003KYHhAAO",
                                  "SystemModstamp": "2021-02-10T17:19:59.000+0000",
                                  "vlocity_ins__PolicyAssetId__c": "02i4x000000gnixAAA",
                                  "vlocity_ins__AggregateLimitAmount__c": 0,
                                  "vlocity_ins__AssetInsuredItemId__c": "a0G4x000000X1CfEAK",
                                  "vlocity_ins__AttributeSelectedValues__c": "{\"autoMedPayLimClmCov\":1000}",
                                  "vlocity_ins__DeductibleAmount__c": 0,
                                  "vlocity_ins__PremiumAmount__c": 33.09,
                                  "Price": 33.09,
                                  "vlocity_ins__Product2Id__c": "01t4x000001y3aKAAQ",
                                  "vlocity_ins__ProductChildItemId__c": "a484x000000Zh9oAAC",
                                  "vlocity_ins__RecordTypeName__c": "CoverageSpec",
                                  "vlocity_ins__StartDate__c": "2021-02-10T08:00:00.000+0000",
                                  "vlocity_ins__TotalAmount__c": 33.09,
                                  "vlocity_ins__TotalProratedAmount__c": 0,
                                  "isOptional": false,
                                  "isSelected": true,
                                  "ProductCode": "autoMedical",
                                  "productName": "Medical Payments",
                                  "productId": "01t4x000001y3aKAAQ",
                                  "pciId": "a484x000000Zh9oAAC",
                                  "PricingSource__c": "premiumMED",
                                  "attributeCategories": {
                                    "totalSize": 1,
                                    "records": [
                                      {
                                        "displaySequence": 230,
                                        "Code__c": "autoTerms",
                                        "Name": "Auto Terms",
                                        "id": "a0R4P00000JWzkZUAT",
                                        "productAttributes": {
                                          "totalSize": 1,
                                          "records": [
                                            {
                                              "code": "autoMedPayLimClmCov",
                                              "dataType": "currency",
                                              "inputType": "dropdown",
                                              "multiselect": false,
                                              "required": false,
                                              "readonly": false,
                                              "disabled": false,
                                              "filterable": true,
                                              "attributeId": "a0S4P000009YMKCUA4",
                                              "label": "Med Pay Person Limit",
                                              "displaySequence": 0,
                                              "hasRules": false,
                                              "hidden": false,
                                              "cloneable": true,
                                              "isNotTranslatable": false,
                                              "values": [
                                                {
                                                  "id": "0",
                                                  "label": "$1000",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": 1000
                                                },
                                                {
                                                  "id": "1",
                                                  "label": "$2000",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": 2000
                                                },
                                                {
                                                  "id": "2",
                                                  "label": "$5000",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": 5000
                                                }
                                              ],
                                              "userValues": 1000
                                            }
                                          ]
                                        }
                                      }
                                    ]
                                  }
                                },
                                {
                                  "displaySequence": -1,
                                  "Id": "a0F4x000000wKnXEAU",
                                  "currencySymbol": "$",
                                  "currencyCode": "USD",
                                  "IsDeleted": false,
                                  "Name": "Uninsured Motorist",
                                  "CreatedDate": "2021-02-10T17:19:59.000+0000",
                                  "CreatedById": "0054x000003KYHhAAO",
                                  "LastModifiedDate": "2021-02-10T17:19:59.000+0000",
                                  "LastModifiedById": "0054x000003KYHhAAO",
                                  "SystemModstamp": "2021-02-10T17:19:59.000+0000",
                                  "vlocity_ins__PolicyAssetId__c": "02i4x000000gnixAAA",
                                  "vlocity_ins__AggregateLimitAmount__c": 0,
                                  "vlocity_ins__AssetInsuredItemId__c": "a0G4x000000X1CfEAK",
                                  "vlocity_ins__AttributeSelectedValues__c": "{\"autoUMLimit\":\"50/100\"}",
                                  "vlocity_ins__DeductibleAmount__c": 0,
                                  "vlocity_ins__PremiumAmount__c": 68.22,
                                  "Price": 68.22,
                                  "vlocity_ins__Product2Id__c": "01t4x000001y3ZzAAI",
                                  "vlocity_ins__ProductChildItemId__c": "a484x000000Zh9sAAC",
                                  "vlocity_ins__RecordTypeName__c": "CoverageSpec",
                                  "vlocity_ins__StartDate__c": "2021-02-10T08:00:00.000+0000",
                                  "vlocity_ins__TotalAmount__c": 68.22,
                                  "vlocity_ins__TotalProratedAmount__c": 0,
                                  "isOptional": false,
                                  "isSelected": true,
                                  "ProductCode": "autoUM",
                                  "productName": "Uninsured Motorist",
                                  "productId": "01t4x000001y3ZzAAI",
                                  "pciId": "a484x000000Zh9sAAC",
                                  "PricingSource__c": "premiumUM",
                                  "attributeCategories": {
                                    "totalSize": 1,
                                    "records": [
                                      {
                                        "displaySequence": 230,
                                        "Code__c": "autoTerms",
                                        "Name": "Auto Terms",
                                        "id": "a0R4P00000JWzkZUAT",
                                        "productAttributes": {
                                          "totalSize": 1,
                                          "records": [
                                            {
                                              "code": "autoUMLimit",
                                              "dataType": "text",
                                              "inputType": "dropdown",
                                              "multiselect": false,
                                              "required": false,
                                              "readonly": false,
                                              "disabled": false,
                                              "filterable": true,
                                              "attributeId": "a0S4P000009YMKGUA4",
                                              "label": "UM Limit",
                                              "displaySequence": 0,
                                              "hasRules": false,
                                              "hidden": false,
                                              "cloneable": true,
                                              "isNotTranslatable": false,
                                              "values": [
                                                {
                                                  "id": "0",
                                                  "label": "$15,000 / $30,000",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": "15/30"
                                                },
                                                {
                                                  "id": "1",
                                                  "label": "$25,000 / $50,000",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": "25/50"
                                                },
                                                {
                                                  "id": "2",
                                                  "label": "$30,000 / $60,000",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": "30/60"
                                                },
                                                {
                                                  "id": "3",
                                                  "label": "$50,000 / $100,000",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": "50/100"
                                                },
                                                {
                                                  "id": "4",
                                                  "label": "$100,000 / $300,000",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": "100/300"
                                                },
                                                {
                                                  "id": "5",
                                                  "label": "$250,000 / $500,000",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": "250/500"
                                                },
                                                {
                                                  "id": "6",
                                                  "label": "$500,000 / $500,000",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": "500/500"
                                                },
                                                {
                                                  "id": "7",
                                                  "label": "$500,000 / $1,000,000",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": "500/1000"
                                                }
                                              ],
                                              "userValues": "50/100"
                                            }
                                          ]
                                        }
                                      }
                                    ]
                                  }
                                },
                                {
                                  "displaySequence": -1,
                                  "productId": "01t4x000001y3aRAAQ",
                                  "productName": "Rental Car",
                                  "ProductCode": "autoRental",
                                  "Name": "Rental Car",
                                  "pciId": "a484x000000Zh9tAAC",
                                  "isOptional": true,
                                  "isSelected": false,
                                  "vlocity_ins__RecordTypeName__c": "CoverageSpec",
                                  "vlocity_ins__PricingSource__c": "premiumRental",
                                  "attributeCategories": {
                                    "totalSize": 1,
                                    "records": [
                                      {
                                        "displaySequence": 230,
                                        "Code__c": "autoTerms",
                                        "Name": "Auto Terms",
                                        "id": "a0R4P00000JWzkZUAT",
                                        "productAttributes": {
                                          "totalSize": 2,
                                          "records": [
                                            {
                                              "code": "autoRentalLimClmCov",
                                              "dataType": "currency",
                                              "inputType": "number",
                                              "multiselect": false,
                                              "required": false,
                                              "readonly": true,
                                              "disabled": true,
                                              "filterable": true,
                                              "attributeId": "a0S4P000009YMKFUA4",
                                              "label": "Rental Limit",
                                              "displaySequence": 0,
                                              "hasRules": false,
                                              "hidden": false,
                                              "cloneable": true,
                                              "isNotTranslatable": false,
                                              "values": [
                                                {
                                                  "readonly": true,
                                                  "disabled": true
                                                }
                                              ],
                                              "userValues": 2000
                                            },
                                            {
                                              "code": "autoRentalDays",
                                              "dataType": "number",
                                              "inputType": "number",
                                              "multiselect": false,
                                              "required": false,
                                              "readonly": true,
                                              "disabled": true,
                                              "filterable": true,
                                              "attributeId": "a0S4P000009YMKEUA4",
                                              "label": "Number of Days",
                                              "displaySequence": 1,
                                              "hasRules": false,
                                              "hidden": false,
                                              "cloneable": true,
                                              "isNotTranslatable": false,
                                              "values": [
                                                {
                                                  "readonly": true,
                                                  "disabled": true
                                                }
                                              ],
                                              "userValues": 30
                                            }
                                          ]
                                        }
                                      }
                                    ]
                                  }
                                }
                              ]
                            }
                          },
                          {
                            "displaySequence": -1,
                            "Id": "a0G4x000000X1CgEAK",
                            "currencySymbol": "$",
                            "currencyCode": "USD",
                            "IsDeleted": false,
                            "Name": "2020 Mazda CX-30",
                            "instanceKey": "2020 Mazda CX-30",
                            "CreatedDate": "2021-02-10T17:19:59.000+0000",
                            "CreatedById": "0054x000003KYHhAAO",
                            "LastModifiedDate": "2021-02-10T17:19:59.000+0000",
                            "LastModifiedById": "0054x000003KYHhAAO",
                            "SystemModstamp": "2021-02-10T17:19:59.000+0000",
                            "vlocity_ins__PolicyAssetId__c": "02i4x000000gnixAAA",
                            "vlocity_ins__AttributeSelectedValues__c": "{\"avRestraints\":false,\"ProductCode\":\"autoVehicle\",\"avBodyType\":\"Sedan/SUV\",\"avBrakes\":false,\"avHistoric\":false,\"avModel\":\"CX-30\",\"avStabilization\":false,\"avGaragePostalCode\":\"94110\",\"isParent\":true,\"avMake\":\"Mazda\",\"avValue\":26200,\"avMileage\":15000,\"avYear\":\"2020\",\"avAntiTheft\":true,\"avAltFuel\":false}",
                            "vlocity_ins__InsuredItemNumber__c": "2020 Mazda CX-30",
                            "vlocity_ins__MarketValue__c": 0,
                            "vlocity_ins__PremiumAmount__c": 1143.07,
                            "Price": 1143.07,
                            "vlocity_ins__Product2Id__c": "01t4x000001y3a0AAA",
                            "vlocity_ins__ProductChildItemId__c": "a484x000000Zh9qAAC",
                            "vlocity_ins__RecordTypeName__c": "InsuredItemSpec",
                            "vlocity_ins__TotalAmount__c": 1143.07,
                            "vlocity_ins__TotalProratedAmount__c": 0,
                            "hasAttributes": true,
                            "PricingFormula__c": "premiumBIPD + premiumCOLL + premiumCCD + premiumMED + premiumUM+premiumRental",
                            "minCount": 1,
                            "maxCount": 1,
                            "productName": "Vehicle",
                            "productId": "01t4x000001y3a0AAA",
                            "ProductCode": "autoVehicle",
                            "pciId": "a484x000000Zh9qAAC",
                            "hasCoverages": true,
                            "attributeCategories": {
                              "totalSize": 1,
                              "records": [
                                {
                                  "displaySequence": 210,
                                  "Code__c": "autoVehicle",
                                  "Name": "Auto Vehicle",
                                  "id": "a0R4P00000J2MJyUAN",
                                  "productAttributes": {
                                    "totalSize": 27,
                                    "records": [
                                      {
                                        "code": "avValue",
                                        "dataType": "currency",
                                        "inputType": "number",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": true,
                                        "disabled": true,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofbUAC",
                                        "label": "Value",
                                        "displaySequence": 0,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": true,
                                            "disabled": true
                                          }
                                        ],
                                        "userValues": 26200
                                      },
                                      {
                                        "code": "avAltFuel",
                                        "dataType": "text",
                                        "inputType": "checkbox",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": true,
                                        "disabled": true,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofCUAS",
                                        "label": "Alternative Fuel",
                                        "displaySequence": 1,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": true,
                                            "disabled": true
                                          }
                                        ],
                                        "userValues": false
                                      },
                                      {
                                        "code": "avAntiTheft",
                                        "dataType": "text",
                                        "inputType": "checkbox",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": true,
                                        "disabled": true,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofDUAS",
                                        "label": "Anti Theft",
                                        "displaySequence": 2,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": true,
                                            "disabled": true
                                          }
                                        ],
                                        "userValues": true
                                      },
                                      {
                                        "code": "avBrakes",
                                        "dataType": "text",
                                        "inputType": "checkbox",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": true,
                                        "disabled": true,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofFUAS",
                                        "label": "Brakes",
                                        "displaySequence": 3,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": true,
                                            "disabled": true
                                          }
                                        ],
                                        "userValues": false
                                      },
                                      {
                                        "code": "avClaimFreq",
                                        "dataType": "number",
                                        "inputType": "number",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": true,
                                        "disabled": true,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofGUAS",
                                        "label": "Claim Frequency",
                                        "displaySequence": 4,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": true,
                                            "disabled": true
                                          }
                                        ],
                                        "userValues": null
                                      },
                                      {
                                        "code": "avClaimSev",
                                        "dataType": "number",
                                        "inputType": "number",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": true,
                                        "disabled": true,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofHUAS",
                                        "label": "Claim Severity",
                                        "displaySequence": 5,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": true,
                                            "disabled": true
                                          }
                                        ],
                                        "userValues": null
                                      },
                                      {
                                        "code": "avLicNum",
                                        "dataType": "text",
                                        "inputType": "text",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": true,
                                        "disabled": true,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofLUAS",
                                        "label": "License Number",
                                        "displaySequence": 6,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": true,
                                            "disabled": true
                                          }
                                        ],
                                        "userValues": null
                                      },
                                      {
                                        "code": "avLicState",
                                        "dataType": "text",
                                        "inputType": "text",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": true,
                                        "disabled": true,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofMUAS",
                                        "label": "License State",
                                        "displaySequence": 7,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": true,
                                            "disabled": true
                                          }
                                        ],
                                        "userValues": null
                                      },
                                      {
                                        "code": "avMake",
                                        "dataType": "text",
                                        "inputType": "text",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": true,
                                        "disabled": true,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofNUAS",
                                        "label": "Make",
                                        "displaySequence": 8,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": true,
                                            "disabled": true
                                          }
                                        ],
                                        "userValues": "Mazda"
                                      },
                                      {
                                        "code": "avModel",
                                        "dataType": "text",
                                        "inputType": "text",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": true,
                                        "disabled": true,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofPUAS",
                                        "label": "Model",
                                        "displaySequence": 9,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": true,
                                            "disabled": true
                                          }
                                        ],
                                        "userValues": "CX-30"
                                      },
                                      {
                                        "code": "avRatedDriver-BIPD",
                                        "dataType": "number",
                                        "inputType": "number",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": true,
                                        "disabled": true,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofQUAS",
                                        "label": "Rated Driver - BIPD",
                                        "displaySequence": 10,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": true,
                                            "disabled": true
                                          }
                                        ],
                                        "userValues": null
                                      },
                                      {
                                        "code": "avRatedDriver-COMP",
                                        "dataType": "number",
                                        "inputType": "number",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": true,
                                        "disabled": true,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofSUAS",
                                        "label": "Rated Driver - Comprehensive",
                                        "displaySequence": 11,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": true,
                                            "disabled": true
                                          }
                                        ],
                                        "userValues": null
                                      },
                                      {
                                        "code": "avRatedDriver-MED",
                                        "dataType": "number",
                                        "inputType": "number",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": true,
                                        "disabled": true,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofTUAS",
                                        "label": "Rated Driver - Medical Payments",
                                        "displaySequence": 12,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": true,
                                            "disabled": true
                                          }
                                        ],
                                        "userValues": null
                                      },
                                      {
                                        "code": "avRatedDriver-UM",
                                        "dataType": "number",
                                        "inputType": "number",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": true,
                                        "disabled": true,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofUUAS",
                                        "label": "Rated Driver - Uninsured Motorist",
                                        "displaySequence": 13,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": true,
                                            "disabled": true
                                          }
                                        ],
                                        "userValues": null
                                      },
                                      {
                                        "code": "avRatedDriverName",
                                        "dataType": "text",
                                        "inputType": "text",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": true,
                                        "disabled": true,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofVUAS",
                                        "label": "Rated Driver Name",
                                        "displaySequence": 14,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": true,
                                            "disabled": true
                                          }
                                        ],
                                        "userValues": null
                                      },
                                      {
                                        "code": "avRestraints",
                                        "dataType": "text",
                                        "inputType": "checkbox",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": true,
                                        "disabled": true,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofWUAS",
                                        "label": "Restraints",
                                        "displaySequence": 15,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": true,
                                            "disabled": true
                                          }
                                        ],
                                        "userValues": false
                                      },
                                      {
                                        "code": "avStabilization",
                                        "dataType": "text",
                                        "inputType": "checkbox",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": true,
                                        "disabled": true,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofXUAS",
                                        "label": "Stablization",
                                        "displaySequence": 16,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": true,
                                            "disabled": true
                                          }
                                        ],
                                        "userValues": false
                                      },
                                      {
                                        "code": "avHistoric",
                                        "dataType": "text",
                                        "inputType": "checkbox",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": false,
                                        "disabled": false,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofKUAS",
                                        "label": "Historic",
                                        "displaySequence": 17,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": false,
                                            "disabled": false
                                          }
                                        ],
                                        "userValues": false
                                      },
                                      {
                                        "code": "avStyle",
                                        "dataType": "text",
                                        "inputType": "text",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": true,
                                        "disabled": true,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofYUAS",
                                        "label": "Style",
                                        "displaySequence": 18,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": true,
                                            "disabled": true
                                          }
                                        ],
                                        "userValues": null
                                      },
                                      {
                                        "code": "avSymbol",
                                        "dataType": "text",
                                        "inputType": "text",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": true,
                                        "disabled": true,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofZUAS",
                                        "label": "Symbol",
                                        "displaySequence": 19,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": true,
                                            "disabled": true
                                          }
                                        ],
                                        "userValues": null
                                      },
                                      {
                                        "code": "avColor",
                                        "dataType": "text",
                                        "inputType": "text",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": true,
                                        "disabled": true,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofIUAS",
                                        "label": "Color",
                                        "displaySequence": 20,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": true,
                                            "disabled": true
                                          }
                                        ],
                                        "userValues": null
                                      },
                                      {
                                        "code": "avVIN",
                                        "dataType": "text",
                                        "inputType": "text",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": true,
                                        "disabled": true,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofaUAC",
                                        "label": "VIN",
                                        "displaySequence": 21,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": true,
                                            "disabled": true
                                          }
                                        ],
                                        "userValues": null
                                      },
                                      {
                                        "code": "avYear",
                                        "dataType": "text",
                                        "inputType": "text",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": true,
                                        "disabled": true,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofcUAC",
                                        "label": "Year",
                                        "displaySequence": 22,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": true,
                                            "disabled": true
                                          }
                                        ],
                                        "userValues": "2020"
                                      },
                                      {
                                        "code": "avMileage",
                                        "dataType": "number",
                                        "inputType": "number",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": true,
                                        "disabled": true,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofOUAS",
                                        "label": "Annual Mileage",
                                        "displaySequence": 23,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": true,
                                            "disabled": true
                                          }
                                        ],
                                        "userValues": 15000
                                      },
                                      {
                                        "code": "avBodyType",
                                        "dataType": "text",
                                        "inputType": "text",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": true,
                                        "disabled": true,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofEUAS",
                                        "label": "Body Type",
                                        "displaySequence": 24,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": true,
                                            "disabled": true
                                          }
                                        ],
                                        "userValues": "Sedan/SUV"
                                      },
                                      {
                                        "code": "avGaragePostalCode",
                                        "dataType": "text",
                                        "inputType": "text",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": true,
                                        "disabled": true,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofJUAS",
                                        "label": "Garage Location (Postal Code)",
                                        "displaySequence": 25,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": true,
                                            "disabled": true
                                          }
                                        ],
                                        "userValues": "94110"
                                      },
                                      {
                                        "code": "avRatedDriver-COLL",
                                        "dataType": "number",
                                        "inputType": "number",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": true,
                                        "disabled": true,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofRUAS",
                                        "label": "Rated Driver - Collision",
                                        "displaySequence": 26,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": true,
                                            "disabled": true
                                          }
                                        ],
                                        "userValues": null
                                      }
                                    ]
                                  }
                                }
                              ]
                            },
                            "childProducts": {
                              "totalSize": 6,
                              "records": [
                                {
                                  "displaySequence": -1,
                                  "Id": "a0F4x000000wKnOEAU",
                                  "currencySymbol": "$",
                                  "currencyCode": "USD",
                                  "IsDeleted": false,
                                  "Name": "Bodily Injury & Property Damage",
                                  "CreatedDate": "2021-02-10T17:19:59.000+0000",
                                  "CreatedById": "0054x000003KYHhAAO",
                                  "LastModifiedDate": "2021-02-10T17:19:59.000+0000",
                                  "LastModifiedById": "0054x000003KYHhAAO",
                                  "SystemModstamp": "2021-02-10T17:19:59.000+0000",
                                  "vlocity_ins__PolicyAssetId__c": "02i4x000000gnixAAA",
                                  "vlocity_ins__AggregateLimitAmount__c": 0,
                                  "vlocity_ins__AssetInsuredItemId__c": "a0G4x000000X1CgEAK",
                                  "vlocity_ins__AttributeSelectedValues__c": "{\"autoBIPDLimit.autoPDLimClm\":25000,\"autoBIPDLimit.autoBILimClm\":50000,\"autoBIPDLimit.autoBILimClmCov\":25000,\"autoBIPDLimit\":\"25000/50000/25000\"}",
                                  "vlocity_ins__DeductibleAmount__c": 0,
                                  "vlocity_ins__PremiumAmount__c": 19.34,
                                  "Price": 19.34,
                                  "vlocity_ins__Product2Id__c": "01t4x000001y3ZiAAI",
                                  "vlocity_ins__ProductChildItemId__c": "a484x000000ZhDPAA0",
                                  "vlocity_ins__RecordTypeName__c": "CoverageSpec",
                                  "vlocity_ins__StartDate__c": "2021-02-10T08:00:00.000+0000",
                                  "vlocity_ins__TotalAmount__c": 19.34,
                                  "vlocity_ins__TotalProratedAmount__c": 0,
                                  "isOptional": false,
                                  "isSelected": true,
                                  "ProductCode": "autoBIPD",
                                  "productName": "Bodily Injury & Property Damage",
                                  "productId": "01t4x000001y3ZiAAI",
                                  "pciId": "a484x000000ZhDPAA0",
                                  "PricingSource__c": "premiumBIPD",
                                  "attributeCategories": {
                                    "totalSize": 1,
                                    "records": [
                                      {
                                        "displaySequence": 230,
                                        "Code__c": "autoTerms",
                                        "Name": "Auto Terms",
                                        "id": "a0R4P00000JWzkZUAT",
                                        "productAttributes": {
                                          "totalSize": 1,
                                          "records": [
                                            {
                                              "code": "autoBIPDLimit",
                                              "dataType": "text",
                                              "inputType": "dropdown",
                                              "multiselect": false,
                                              "required": false,
                                              "readonly": false,
                                              "disabled": false,
                                              "filterable": true,
                                              "attributeId": "a0S4P000009YMK7UAO",
                                              "label": "BIPD Limit",
                                              "displaySequence": 0,
                                              "hasRules": true,
                                              "hidden": false,
                                              "cloneable": true,
                                              "isNotTranslatable": false,
                                              "values": [
                                                {
                                                  "id": "0",
                                                  "label": "$15000/$30000/$10000",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": "15000/30000/10000"
                                                },
                                                {
                                                  "id": "1",
                                                  "label": "$15000/$30000/$5000",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": "15000/30000/5000"
                                                },
                                                {
                                                  "id": "2",
                                                  "label": "$25000/$50000/$25000",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": "25000/50000/25000"
                                                },
                                                {
                                                  "id": "3",
                                                  "label": "$25000/$50000/$50000",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": "25000/50000/50000"
                                                },
                                                {
                                                  "id": "4",
                                                  "label": "$50000/$100000/$50000",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": "50000/100000/50000"
                                                },
                                                {
                                                  "id": "5",
                                                  "label": "$50000/$100000/$100000",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": "50000/100000/100000"
                                                },
                                                {
                                                  "id": "6",
                                                  "label": "$100000/$300000/$25000",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": "100000/300000/25000"
                                                },
                                                {
                                                  "id": "7",
                                                  "label": "$100000/$300000/$50000",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": "100000/300000/50000"
                                                },
                                                {
                                                  "id": "8",
                                                  "label": "$100000/$300000/$100000",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": "100000/300000/100000"
                                                },
                                                {
                                                  "id": "9",
                                                  "label": "$250000/$500000/$100000",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": "250000/500000/100000"
                                                },
                                                {
                                                  "id": "10",
                                                  "label": "$500000/$500000/100000",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": "500000/500000/100000"
                                                },
                                                {
                                                  "id": "11",
                                                  "label": "$500000/$500000/$500000",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": "500000/500000/500000"
                                                },
                                                {
                                                  "id": "12",
                                                  "label": "$500000/$1000000/$500000",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": "500000/1000000/500000"
                                                }
                                              ],
                                              "userValues": "25000/50000/25000",
                                              "valueDecoder": "autoBILimClmCov/autoBILimClm/autoPDLimClm"
                                            }
                                          ]
                                        }
                                      }
                                    ]
                                  }
                                },
                                {
                                  "displaySequence": -1,
                                  "Id": "a0F4x000000wKnPEAU",
                                  "currencySymbol": "$",
                                  "currencyCode": "USD",
                                  "IsDeleted": false,
                                  "Name": "Collision",
                                  "CreatedDate": "2021-02-10T17:19:59.000+0000",
                                  "CreatedById": "0054x000003KYHhAAO",
                                  "LastModifiedDate": "2021-02-10T17:19:59.000+0000",
                                  "LastModifiedById": "0054x000003KYHhAAO",
                                  "SystemModstamp": "2021-02-10T17:19:59.000+0000",
                                  "vlocity_ins__PolicyAssetId__c": "02i4x000000gnixAAA",
                                  "vlocity_ins__AggregateLimitAmount__c": 0,
                                  "vlocity_ins__AssetInsuredItemId__c": "a0G4x000000X1CgEAK",
                                  "vlocity_ins__AttributeSelectedValues__c": "{\"autoCollDedClmCov\":500}",
                                  "vlocity_ins__DeductibleAmount__c": 0,
                                  "vlocity_ins__PremiumAmount__c": 769.5,
                                  "Price": 769.5,
                                  "vlocity_ins__Product2Id__c": "01t4x000001y3aDAAQ",
                                  "vlocity_ins__ProductChildItemId__c": "a484x000000Zh9pAAC",
                                  "vlocity_ins__RecordTypeName__c": "CoverageSpec",
                                  "vlocity_ins__StartDate__c": "2021-02-10T08:00:00.000+0000",
                                  "vlocity_ins__TotalAmount__c": 769.5,
                                  "vlocity_ins__TotalProratedAmount__c": 0,
                                  "isOptional": false,
                                  "isSelected": true,
                                  "ProductCode": "autoCollision",
                                  "productName": "Collision",
                                  "productId": "01t4x000001y3aDAAQ",
                                  "pciId": "a484x000000Zh9pAAC",
                                  "PricingSource__c": "premiumCOLL",
                                  "attributeCategories": {
                                    "totalSize": 1,
                                    "records": [
                                      {
                                        "displaySequence": 230,
                                        "Code__c": "autoTerms",
                                        "Name": "Auto Terms",
                                        "id": "a0R4P00000JWzkZUAT",
                                        "productAttributes": {
                                          "totalSize": 1,
                                          "records": [
                                            {
                                              "code": "autoCollDedClmCov",
                                              "dataType": "currency",
                                              "inputType": "dropdown",
                                              "multiselect": false,
                                              "required": false,
                                              "readonly": false,
                                              "disabled": false,
                                              "filterable": true,
                                              "attributeId": "a0S4P000009YMK8UAO",
                                              "label": "Collision Deductible",
                                              "displaySequence": 0,
                                              "hasRules": false,
                                              "hidden": false,
                                              "cloneable": true,
                                              "isNotTranslatable": false,
                                              "values": [
                                                {
                                                  "id": "0",
                                                  "label": "$250",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": 250
                                                },
                                                {
                                                  "id": "1",
                                                  "label": "$500",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": 500
                                                },
                                                {
                                                  "id": "2",
                                                  "label": "$750",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": 750
                                                },
                                                {
                                                  "id": "3",
                                                  "label": "$1000",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": 1000
                                                },
                                                {
                                                  "id": "4",
                                                  "label": "$1500",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": 1500
                                                },
                                                {
                                                  "id": "5",
                                                  "label": "$2500",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": 2500
                                                }
                                              ],
                                              "userValues": 500
                                            }
                                          ]
                                        }
                                      }
                                    ]
                                  }
                                },
                                {
                                  "displaySequence": -1,
                                  "Id": "a0F4x000000wKnQEAU",
                                  "currencySymbol": "$",
                                  "currencyCode": "USD",
                                  "IsDeleted": false,
                                  "Name": "Comprehensive",
                                  "CreatedDate": "2021-02-10T17:19:59.000+0000",
                                  "CreatedById": "0054x000003KYHhAAO",
                                  "LastModifiedDate": "2021-02-10T17:19:59.000+0000",
                                  "LastModifiedById": "0054x000003KYHhAAO",
                                  "SystemModstamp": "2021-02-10T17:19:59.000+0000",
                                  "vlocity_ins__PolicyAssetId__c": "02i4x000000gnixAAA",
                                  "vlocity_ins__AggregateLimitAmount__c": 0,
                                  "vlocity_ins__AssetInsuredItemId__c": "a0G4x000000X1CgEAK",
                                  "vlocity_ins__AttributeSelectedValues__c": "{\"autoCompDedClmCov\":100}",
                                  "vlocity_ins__DeductibleAmount__c": 0,
                                  "vlocity_ins__PremiumAmount__c": 248.69,
                                  "Price": 248.69,
                                  "vlocity_ins__Product2Id__c": "01t4x000001y3a1AAA",
                                  "vlocity_ins__ProductChildItemId__c": "a484x000000Zh9nAAC",
                                  "vlocity_ins__RecordTypeName__c": "CoverageSpec",
                                  "vlocity_ins__StartDate__c": "2021-02-10T08:00:00.000+0000",
                                  "vlocity_ins__TotalAmount__c": 248.69,
                                  "vlocity_ins__TotalProratedAmount__c": 0,
                                  "isOptional": false,
                                  "isSelected": true,
                                  "ProductCode": "autoComp",
                                  "productName": "Comprehensive",
                                  "productId": "01t4x000001y3a1AAA",
                                  "pciId": "a484x000000Zh9nAAC",
                                  "PricingSource__c": "premiumCCD",
                                  "attributeCategories": {
                                    "totalSize": 1,
                                    "records": [
                                      {
                                        "displaySequence": 230,
                                        "Code__c": "autoTerms",
                                        "Name": "Auto Terms",
                                        "id": "a0R4P00000JWzkZUAT",
                                        "productAttributes": {
                                          "totalSize": 1,
                                          "records": [
                                            {
                                              "code": "autoCompDedClmCov",
                                              "dataType": "currency",
                                              "inputType": "dropdown",
                                              "multiselect": false,
                                              "required": false,
                                              "readonly": false,
                                              "disabled": false,
                                              "filterable": true,
                                              "attributeId": "a0S4P000009YMK9UAO",
                                              "label": "Comp Deductible",
                                              "displaySequence": 0,
                                              "hasRules": false,
                                              "hidden": false,
                                              "cloneable": true,
                                              "isNotTranslatable": false,
                                              "values": [
                                                {
                                                  "id": "0",
                                                  "label": "$100",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": 100
                                                },
                                                {
                                                  "id": "1",
                                                  "label": "$250",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": 250
                                                },
                                                {
                                                  "id": "2",
                                                  "label": "$500",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": 500
                                                },
                                                {
                                                  "id": "3",
                                                  "label": "$750",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": 750
                                                },
                                                {
                                                  "id": "4",
                                                  "label": "$1000",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": 1000
                                                },
                                                {
                                                  "id": "5",
                                                  "label": "$1500",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": 1500
                                                },
                                                {
                                                  "id": "6",
                                                  "label": "$2500",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": 2500
                                                }
                                              ],
                                              "userValues": 100
                                            }
                                          ]
                                        }
                                      }
                                    ]
                                  }
                                },
                                {
                                  "displaySequence": -1,
                                  "Id": "a0F4x000000wKnREAU",
                                  "currencySymbol": "$",
                                  "currencyCode": "USD",
                                  "IsDeleted": false,
                                  "Name": "Medical Payments",
                                  "CreatedDate": "2021-02-10T17:19:59.000+0000",
                                  "CreatedById": "0054x000003KYHhAAO",
                                  "LastModifiedDate": "2021-02-10T17:19:59.000+0000",
                                  "LastModifiedById": "0054x000003KYHhAAO",
                                  "SystemModstamp": "2021-02-10T17:19:59.000+0000",
                                  "vlocity_ins__PolicyAssetId__c": "02i4x000000gnixAAA",
                                  "vlocity_ins__AggregateLimitAmount__c": 0,
                                  "vlocity_ins__AssetInsuredItemId__c": "a0G4x000000X1CgEAK",
                                  "vlocity_ins__AttributeSelectedValues__c": "{\"autoMedPayLimClmCov\":1000}",
                                  "vlocity_ins__DeductibleAmount__c": 0,
                                  "vlocity_ins__PremiumAmount__c": 37.32,
                                  "Price": 37.32,
                                  "vlocity_ins__Product2Id__c": "01t4x000001y3aKAAQ",
                                  "vlocity_ins__ProductChildItemId__c": "a484x000000Zh9oAAC",
                                  "vlocity_ins__RecordTypeName__c": "CoverageSpec",
                                  "vlocity_ins__StartDate__c": "2021-02-10T08:00:00.000+0000",
                                  "vlocity_ins__TotalAmount__c": 37.32,
                                  "vlocity_ins__TotalProratedAmount__c": 0,
                                  "isOptional": false,
                                  "isSelected": true,
                                  "ProductCode": "autoMedical",
                                  "productName": "Medical Payments",
                                  "productId": "01t4x000001y3aKAAQ",
                                  "pciId": "a484x000000Zh9oAAC",
                                  "PricingSource__c": "premiumMED",
                                  "attributeCategories": {
                                    "totalSize": 1,
                                    "records": [
                                      {
                                        "displaySequence": 230,
                                        "Code__c": "autoTerms",
                                        "Name": "Auto Terms",
                                        "id": "a0R4P00000JWzkZUAT",
                                        "productAttributes": {
                                          "totalSize": 1,
                                          "records": [
                                            {
                                              "code": "autoMedPayLimClmCov",
                                              "dataType": "currency",
                                              "inputType": "dropdown",
                                              "multiselect": false,
                                              "required": false,
                                              "readonly": false,
                                              "disabled": false,
                                              "filterable": true,
                                              "attributeId": "a0S4P000009YMKCUA4",
                                              "label": "Med Pay Person Limit",
                                              "displaySequence": 0,
                                              "hasRules": false,
                                              "hidden": false,
                                              "cloneable": true,
                                              "isNotTranslatable": false,
                                              "values": [
                                                {
                                                  "id": "0",
                                                  "label": "$1000",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": 1000
                                                },
                                                {
                                                  "id": "1",
                                                  "label": "$2000",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": 2000
                                                },
                                                {
                                                  "id": "2",
                                                  "label": "$5000",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": 5000
                                                }
                                              ],
                                              "userValues": 1000
                                            }
                                          ]
                                        }
                                      }
                                    ]
                                  }
                                },
                                {
                                  "displaySequence": -1,
                                  "Id": "a0F4x000000wKnSEAU",
                                  "currencySymbol": "$",
                                  "currencyCode": "USD",
                                  "IsDeleted": false,
                                  "Name": "Uninsured Motorist",
                                  "CreatedDate": "2021-02-10T17:19:59.000+0000",
                                  "CreatedById": "0054x000003KYHhAAO",
                                  "LastModifiedDate": "2021-02-10T17:19:59.000+0000",
                                  "LastModifiedById": "0054x000003KYHhAAO",
                                  "SystemModstamp": "2021-02-10T17:19:59.000+0000",
                                  "vlocity_ins__PolicyAssetId__c": "02i4x000000gnixAAA",
                                  "vlocity_ins__AggregateLimitAmount__c": 0,
                                  "vlocity_ins__AssetInsuredItemId__c": "a0G4x000000X1CgEAK",
                                  "vlocity_ins__AttributeSelectedValues__c": "{\"autoUMLimit\":\"50/100\"}",
                                  "vlocity_ins__DeductibleAmount__c": 0,
                                  "vlocity_ins__PremiumAmount__c": 68.22,
                                  "Price": 68.22,
                                  "vlocity_ins__Product2Id__c": "01t4x000001y3ZzAAI",
                                  "vlocity_ins__ProductChildItemId__c": "a484x000000Zh9sAAC",
                                  "vlocity_ins__RecordTypeName__c": "CoverageSpec",
                                  "vlocity_ins__StartDate__c": "2021-02-10T08:00:00.000+0000",
                                  "vlocity_ins__TotalAmount__c": 68.22,
                                  "vlocity_ins__TotalProratedAmount__c": 0,
                                  "isOptional": false,
                                  "isSelected": true,
                                  "ProductCode": "autoUM",
                                  "productName": "Uninsured Motorist",
                                  "productId": "01t4x000001y3ZzAAI",
                                  "pciId": "a484x000000Zh9sAAC",
                                  "PricingSource__c": "premiumUM",
                                  "attributeCategories": {
                                    "totalSize": 1,
                                    "records": [
                                      {
                                        "displaySequence": 230,
                                        "Code__c": "autoTerms",
                                        "Name": "Auto Terms",
                                        "id": "a0R4P00000JWzkZUAT",
                                        "productAttributes": {
                                          "totalSize": 1,
                                          "records": [
                                            {
                                              "code": "autoUMLimit",
                                              "dataType": "text",
                                              "inputType": "dropdown",
                                              "multiselect": false,
                                              "required": false,
                                              "readonly": false,
                                              "disabled": false,
                                              "filterable": true,
                                              "attributeId": "a0S4P000009YMKGUA4",
                                              "label": "UM Limit",
                                              "displaySequence": 0,
                                              "hasRules": false,
                                              "hidden": false,
                                              "cloneable": true,
                                              "isNotTranslatable": false,
                                              "values": [
                                                {
                                                  "id": "0",
                                                  "label": "$15,000 / $30,000",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": "15/30"
                                                },
                                                {
                                                  "id": "1",
                                                  "label": "$25,000 / $50,000",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": "25/50"
                                                },
                                                {
                                                  "id": "2",
                                                  "label": "$30,000 / $60,000",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": "30/60"
                                                },
                                                {
                                                  "id": "3",
                                                  "label": "$50,000 / $100,000",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": "50/100"
                                                },
                                                {
                                                  "id": "4",
                                                  "label": "$100,000 / $300,000",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": "100/300"
                                                },
                                                {
                                                  "id": "5",
                                                  "label": "$250,000 / $500,000",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": "250/500"
                                                },
                                                {
                                                  "id": "6",
                                                  "label": "$500,000 / $500,000",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": "500/500"
                                                },
                                                {
                                                  "id": "7",
                                                  "label": "$500,000 / $1,000,000",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": "500/1000"
                                                }
                                              ],
                                              "userValues": "50/100"
                                            }
                                          ]
                                        }
                                      }
                                    ]
                                  }
                                },
                                {
                                  "displaySequence": -1,
                                  "productId": "01t4x000001y3aRAAQ",
                                  "productName": "Rental Car",
                                  "ProductCode": "autoRental",
                                  "Name": "Rental Car",
                                  "pciId": "a484x000000Zh9tAAC",
                                  "isOptional": true,
                                  "isSelected": false,
                                  "vlocity_ins__RecordTypeName__c": "CoverageSpec",
                                  "vlocity_ins__PricingSource__c": "premiumRental",
                                  "attributeCategories": {
                                    "totalSize": 1,
                                    "records": [
                                      {
                                        "displaySequence": 230,
                                        "Code__c": "autoTerms",
                                        "Name": "Auto Terms",
                                        "id": "a0R4P00000JWzkZUAT",
                                        "productAttributes": {
                                          "totalSize": 2,
                                          "records": [
                                            {
                                              "code": "autoRentalLimClmCov",
                                              "dataType": "currency",
                                              "inputType": "number",
                                              "multiselect": false,
                                              "required": false,
                                              "readonly": true,
                                              "disabled": true,
                                              "filterable": true,
                                              "attributeId": "a0S4P000009YMKFUA4",
                                              "label": "Rental Limit",
                                              "displaySequence": 0,
                                              "hasRules": false,
                                              "hidden": false,
                                              "cloneable": true,
                                              "isNotTranslatable": false,
                                              "values": [
                                                {
                                                  "readonly": true,
                                                  "disabled": true
                                                }
                                              ],
                                              "userValues": 2000
                                            },
                                            {
                                              "code": "autoRentalDays",
                                              "dataType": "number",
                                              "inputType": "number",
                                              "multiselect": false,
                                              "required": false,
                                              "readonly": true,
                                              "disabled": true,
                                              "filterable": true,
                                              "attributeId": "a0S4P000009YMKEUA4",
                                              "label": "Number of Days",
                                              "displaySequence": 1,
                                              "hasRules": false,
                                              "hidden": false,
                                              "cloneable": true,
                                              "isNotTranslatable": false,
                                              "values": [
                                                {
                                                  "readonly": true,
                                                  "disabled": true
                                                }
                                              ],
                                              "userValues": 30
                                            }
                                          ]
                                        }
                                      }
                                    ]
                                  }
                                }
                              ]
                            }
                          },
                          {
                            "displaySequence": -1,
                            "Id": "a0H4x000001U2ftEAC",
                            "currencySymbol": "$",
                            "currencyCode": "USD",
                            "IsDeleted": false,
                            "Name": "Lang Zerner",
                            "instanceKey": "Lang Zerner",
                            "CreatedDate": "2021-02-10T17:19:59.000+0000",
                            "CreatedById": "0054x000003KYHhAAO",
                            "LastModifiedDate": "2021-02-10T17:19:59.000+0000",
                            "LastModifiedById": "0054x000003KYHhAAO",
                            "SystemModstamp": "2021-02-10T17:19:59.000+0000",
                            "vlocity_ins__AssetId__c": "02i4x000000gnixAAA",
                            "vlocity_ins__AttributeSelectedValues__c": "{\"adAge\":56,\"adBirthdate\":\"1964-04-18T08:00:00.000Z\",\"adAgeLicensed\":17,\"adFirstName\":\"Lang\",\"adGender\":\"M\",\"adLastName\":\"Zerner\",\"adMaritalStatus\":\"S\",\"isParent\":false,\"ProductCode\":\"autoDriver\"}",
                            "vlocity_ins__InsuredPartyNumber__c": "Lang Zerner",
                            "vlocity_ins__InsuredPartySpecId__c": "01t4x000001y3ZvAAI",
                            "vlocity_ins__PartyLink__c": "<a href=\"/\" target=\"_parent\"> </a>",
                            "vlocity_ins__PremiumAmount__c": 0,
                            "Price": 0,
                            "vlocity_ins__RecordTypeName__c": "InsuredPartySpec",
                            "vlocity_ins__TotalAmount__c": 0,
                            "vlocity_ins__TotalProratedAmount__c": 0,
                            "vlocity_ins__IsPolicyholder__c": false,
                            "vlocity_ins__LookupKey__c": "Lang Zerner_",
                            "vlocity_ins__PartyAccountCalculatedAddress__c": "<br>",
                            "hasAttributes": true,
                            "minCount": 1,
                            "maxCount": 1,
                            "productName": "Auto Driver",
                            "productId": "01t4x000001y3ZvAAI",
                            "ProductCode": "autoDriver",
                            "pciId": "a484x000000Zh9rAAC",
                            "hasCoverages": false,
                            "attributeCategories": {
                              "totalSize": 1,
                              "records": [
                                {
                                  "displaySequence": 220,
                                  "Code__c": "autoDriver",
                                  "Name": "Auto Driver",
                                  "id": "a0R4P00000J2MJxUAN",
                                  "productAttributes": {
                                    "totalSize": 21,
                                    "records": [
                                      {
                                        "code": "adSuffix",
                                        "dataType": "text",
                                        "inputType": "text",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": false,
                                        "disabled": false,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VoezUAC",
                                        "label": "Suffix",
                                        "displaySequence": 0,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": false,
                                            "disabled": false
                                          }
                                        ],
                                        "userValues": null
                                      },
                                      {
                                        "code": "adFirstName",
                                        "dataType": "text",
                                        "inputType": "text",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": false,
                                        "disabled": false,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VoemUAC",
                                        "label": "First Name",
                                        "displaySequence": 1,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": false,
                                            "disabled": false
                                          }
                                        ],
                                        "userValues": "Lang"
                                      },
                                      {
                                        "code": "adMiddle",
                                        "dataType": "text",
                                        "inputType": "text",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": false,
                                        "disabled": false,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VoevUAC",
                                        "label": "Middle Name",
                                        "displaySequence": 2,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": false,
                                            "disabled": false
                                          }
                                        ],
                                        "userValues": null
                                      },
                                      {
                                        "code": "adLastName",
                                        "dataType": "text",
                                        "inputType": "text",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": false,
                                        "disabled": false,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VoeqUAC",
                                        "label": "Last Name",
                                        "displaySequence": 3,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": false,
                                            "disabled": false
                                          }
                                        ],
                                        "userValues": "Zerner"
                                      },
                                      {
                                        "code": "adBirthdate",
                                        "dataType": "date",
                                        "inputType": "date",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": false,
                                        "disabled": false,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VoelUAC",
                                        "label": "Birthdate",
                                        "displaySequence": 4,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": false,
                                            "disabled": false
                                          }
                                        ],
                                        "userValues": "1964-04-18T08:00:00.000Z"
                                      },
                                      {
                                        "code": "adAgeLicensed",
                                        "dataType": "number",
                                        "inputType": "number",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": false,
                                        "disabled": false,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VoekUAC",
                                        "label": "Age First Licensed",
                                        "displaySequence": 5,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": false,
                                            "disabled": false
                                          }
                                        ],
                                        "userValues": 17
                                      },
                                      {
                                        "code": "adGender",
                                        "dataType": "text",
                                        "inputType": "dropdown",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": false,
                                        "disabled": false,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VoeoUAC",
                                        "label": "Gender",
                                        "displaySequence": 6,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "id": "2",
                                            "label": "Male",
                                            "readonly": false,
                                            "disabled": false,
                                            "value": "M"
                                          },
                                          {
                                            "id": "1",
                                            "label": "Female",
                                            "readonly": false,
                                            "disabled": false,
                                            "value": "F"
                                          }
                                        ],
                                        "userValues": "M"
                                      },
                                      {
                                        "code": "adMaritalStatus",
                                        "dataType": "text",
                                        "inputType": "dropdown",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": false,
                                        "disabled": false,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VoeuUAC",
                                        "label": "Marital Status",
                                        "displaySequence": 7,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "id": "1",
                                            "label": "Married",
                                            "readonly": false,
                                            "disabled": false,
                                            "value": "M"
                                          },
                                          {
                                            "id": "0",
                                            "label": "Single",
                                            "readonly": false,
                                            "disabled": false,
                                            "value": "S"
                                          }
                                        ],
                                        "userValues": "S"
                                      },
                                      {
                                        "code": "adAccidentPoints",
                                        "dataType": "number",
                                        "inputType": "number",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": false,
                                        "disabled": false,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VoeiUAC",
                                        "label": "Driver Accident Points",
                                        "displaySequence": 8,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": false,
                                            "disabled": false
                                          }
                                        ],
                                        "userValues": null
                                      },
                                      {
                                        "code": "adMVRPoints",
                                        "dataType": "number",
                                        "inputType": "number",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": false,
                                        "disabled": false,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VoetUAC",
                                        "label": "Driver MVR Points",
                                        "displaySequence": 9,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": false,
                                            "disabled": false
                                          }
                                        ],
                                        "userValues": null
                                      },
                                      {
                                        "code": "adMileage",
                                        "dataType": "number",
                                        "inputType": "number",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": false,
                                        "disabled": false,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VoewUAC",
                                        "label": "Driver Annual Mileage",
                                        "displaySequence": 10,
                                        "hasRules": false,
                                        "hidden": true,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": false,
                                            "disabled": false
                                          }
                                        ],
                                        "userValues": null
                                      },
                                      {
                                        "code": "adGoodStudent",
                                        "dataType": "text",
                                        "inputType": "text",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": false,
                                        "disabled": false,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VoepUAC",
                                        "label": "Good Student",
                                        "displaySequence": 11,
                                        "hasRules": false,
                                        "hidden": true,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": false,
                                            "disabled": false
                                          }
                                        ],
                                        "userValues": null
                                      },
                                      {
                                        "code": "adGPA",
                                        "dataType": "number",
                                        "inputType": "number",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": false,
                                        "disabled": false,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VoenUAC",
                                        "label": "GPA",
                                        "displaySequence": 12,
                                        "hasRules": false,
                                        "hidden": true,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": false,
                                            "disabled": false
                                          }
                                        ],
                                        "userValues": null
                                      },
                                      {
                                        "code": "adLicenseNum",
                                        "dataType": "text",
                                        "inputType": "text",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": false,
                                        "disabled": false,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VoerUAC",
                                        "label": "License Number",
                                        "displaySequence": 13,
                                        "hasRules": false,
                                        "hidden": true,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": false,
                                            "disabled": false
                                          }
                                        ],
                                        "userValues": null
                                      },
                                      {
                                        "code": "adName",
                                        "dataType": "text",
                                        "inputType": "text",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": false,
                                        "disabled": false,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VoexUAC",
                                        "label": "Name",
                                        "displaySequence": 14,
                                        "hasRules": false,
                                        "hidden": true,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": false,
                                            "disabled": false
                                          }
                                        ],
                                        "userValues": null
                                      },
                                      {
                                        "code": "adUse",
                                        "dataType": "text",
                                        "inputType": "text",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": false,
                                        "disabled": false,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004Vof1UAC",
                                        "label": "Primary Use",
                                        "displaySequence": 15,
                                        "hasRules": false,
                                        "hidden": true,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": false,
                                            "disabled": false
                                          }
                                        ],
                                        "userValues": null
                                      },
                                      {
                                        "code": "adSafeDriver",
                                        "dataType": "text",
                                        "inputType": "text",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": false,
                                        "disabled": false,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VoeyUAC",
                                        "label": "Safe Driver",
                                        "displaySequence": 16,
                                        "hasRules": false,
                                        "hidden": true,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": false,
                                            "disabled": false
                                          }
                                        ],
                                        "userValues": null
                                      },
                                      {
                                        "code": "adLicenseState",
                                        "dataType": "text",
                                        "inputType": "text",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": false,
                                        "disabled": false,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VoesUAC",
                                        "label": "State Licensed",
                                        "displaySequence": 17,
                                        "hasRules": false,
                                        "hidden": true,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": false,
                                            "disabled": false
                                          }
                                        ],
                                        "userValues": null
                                      },
                                      {
                                        "code": "adTotalPoints",
                                        "dataType": "number",
                                        "inputType": "number",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": false,
                                        "disabled": false,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004Vof0UAC",
                                        "label": "Total Points",
                                        "displaySequence": 18,
                                        "hasRules": false,
                                        "hidden": true,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": false,
                                            "disabled": false
                                          }
                                        ],
                                        "userValues": null
                                      },
                                      {
                                        "code": "adYrsExp",
                                        "dataType": "number",
                                        "inputType": "number",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": false,
                                        "disabled": false,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004Vof2UAC",
                                        "label": "Years Experience",
                                        "displaySequence": 19,
                                        "hasRules": false,
                                        "hidden": true,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": false,
                                            "disabled": false
                                          }
                                        ],
                                        "userValues": null
                                      },
                                      {
                                        "code": "adAge",
                                        "dataType": "number",
                                        "inputType": "number",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": false,
                                        "disabled": false,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VoejUAC",
                                        "label": "Age",
                                        "displaySequence": 20,
                                        "hasRules": false,
                                        "hidden": true,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": false,
                                            "disabled": false
                                          }
                                        ],
                                        "userValues": 56
                                      }
                                    ]
                                  }
                                }
                              ]
                            }
                          }
                        ]
                      }
                    }
                  ]
                },
                {
                  "totalSize": 0,
                  "records": [
                    {
                      "displaySequence": -1,
                      "Id": "02i4x000000gnj2AAA",
                      "productId": "01t4x000001y3bEAAQ",
                      "accountId": "0014x00000EYnz8AAD",
                      "productName": "Multi Auto",
                      "Name": "Multi Auto",
                      "EffectiveStart": "2021-02-10",
                      "Price": 2473.12,
                      "PricingFormula__c": "SUM(premiumBIPD + premiumCOLL + premiumCCD + premiumMED + premiumUM+premiumRental)",
                      "ProductCode": "autoMulti",
                      "RecordTypeName__c": "Product",
                      "vlocity_ins__TotalTaxAmount__c": 40.2156,
                      "vlocity_ins__TotalFeeAmount__c": 25,
                      "vlocity_ins__TotalTaxForTerm__c": 40.2156,
                      "vlocity_ins__TotalFeeForTerm__c": 25,
                      "vlocity_ins__TotalAmount__c": 2538.34,
                      "vlocity_ins__TotalAmountForTerm__c": 65.22,
                      "hasAttributes": false,
                      "taxesAndFees": [
                        {
                          "currencySymbol": "$",
                          "currencyCode": "USD",
                          "calculatedAmount": 25,
                          "PriceListEntryName__c": "573608e0-7b1c-9b66-a435-d584218c5305",
                          "PriceListEntryId__c": "a3u4x000000cabtAAA",
                          "isRefundable": false,
                          "Amount__c": 25,
                          "AdjustmentType__c": "Fee",
                          "Id": "a0I4x000001Z3AXEA0"
                        },
                        {
                          "currencySymbol": "$",
                          "currencyCode": "USD",
                          "calculatedAmount": 27.85,
                          "PriceListEntryName__c": "7457f382-f935-3308-3429-24d9dfac88f4",
                          "PriceListEntryId__c": "a3u4x000000cabuAAA",
                          "isRefundable": true,
                          "Amount__c": 27.85,
                          "AdjustmentType__c": "Tax",
                          "Id": "a0I4x000001Z3AYEA0"
                        },
                        {
                          "currencySymbol": "$",
                          "currencyCode": "USD",
                          "calculatedAmount": 0,
                          "PriceListEntryName__c": "7eee88c5-37d5-3991-02db-37ef3343982f",
                          "PriceListEntryId__c": "a3u4x000000cabvAAA",
                          "isRefundable": false,
                          "Amount__c": 0,
                          "AdjustmentType__c": "Tax",
                          "Id": "a0I4x000001Z3AZEA0"
                        },
                        {
                          "currencySymbol": "$",
                          "currencyCode": "USD",
                          "calculatedAmount": 12.3656,
                          "PriceListEntryName__c": "93b485fc-a7ce-a358-929d-e0381289b239",
                          "PriceListEntryId__c": "a3u4x000000cabwAAA",
                          "isRefundable": true,
                          "Amount__c": 12.3656,
                          "AdjustmentType__c": "Tax",
                          "Id": "a0I4x000001Z3AaEAK"
                        }
                      ],
                      "taxAmount": 40.2156,
                      "feeAmount": 25,
                      "totalTaxFeeAmount": 65.2156,
                      "coverageCount": 0,
                      "childProducts": {
                        "totalSize": 3,
                        "records": [
                          {
                            "displaySequence": -1,
                            "Id": "a0G4x000000X1CuEAK",
                            "currencySymbol": "$",
                            "currencyCode": "USD",
                            "IsDeleted": false,
                            "Name": "2019 BMW M3",
                            "instanceKey": "2019 BMW M3",
                            "CreatedDate": "2021-02-10T17:20:22.000+0000",
                            "CreatedById": "0054x000003KYHhAAO",
                            "LastModifiedDate": "2021-02-10T17:20:22.000+0000",
                            "LastModifiedById": "0054x000003KYHhAAO",
                            "SystemModstamp": "2021-02-10T17:20:22.000+0000",
                            "vlocity_ins__PolicyAssetId__c": "02i4x000000gnj2AAA",
                            "vlocity_ins__AttributeSelectedValues__c": "{\"avRestraints\":false,\"ProductCode\":\"autoVehicle\",\"avBodyType\":\"Sedan/Saloon\",\"avBrakes\":false,\"avHistoric\":false,\"avModel\":\"M3\",\"avStabilization\":false,\"avGaragePostalCode\":\"94110\",\"isParent\":true,\"avMake\":\"BMW\",\"avValue\":45000,\"avMileage\":10000,\"avYear\":\"2019\",\"avAntiTheft\":true,\"avAltFuel\":false}",
                            "vlocity_ins__InsuredItemNumber__c": "2019 BMW M3",
                            "vlocity_ins__MarketValue__c": 0,
                            "vlocity_ins__PremiumAmount__c": 1341.43,
                            "Price": 1341.43,
                            "vlocity_ins__Product2Id__c": "01t4x000001y3a0AAA",
                            "vlocity_ins__ProductChildItemId__c": "a484x000000Zh9qAAC",
                            "vlocity_ins__RecordTypeName__c": "InsuredItemSpec",
                            "vlocity_ins__TotalAmount__c": 1341.43,
                            "vlocity_ins__TotalProratedAmount__c": 0,
                            "hasAttributes": true,
                            "PricingFormula__c": "premiumBIPD + premiumCOLL + premiumCCD + premiumMED + premiumUM+premiumRental",
                            "minCount": 1,
                            "maxCount": 1,
                            "productName": "Vehicle",
                            "productId": "01t4x000001y3a0AAA",
                            "ProductCode": "autoVehicle",
                            "pciId": "a484x000000Zh9qAAC",
                            "hasCoverages": true,
                            "attributeCategories": {
                              "totalSize": 1,
                              "records": [
                                {
                                  "displaySequence": 210,
                                  "Code__c": "autoVehicle",
                                  "Name": "Auto Vehicle",
                                  "id": "a0R4P00000J2MJyUAN",
                                  "productAttributes": {
                                    "totalSize": 27,
                                    "records": [
                                      {
                                        "code": "avValue",
                                        "dataType": "currency",
                                        "inputType": "number",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": true,
                                        "disabled": true,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofbUAC",
                                        "label": "Value",
                                        "displaySequence": 0,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": true,
                                            "disabled": true
                                          }
                                        ],
                                        "userValues": 45000
                                      },
                                      {
                                        "code": "avAltFuel",
                                        "dataType": "text",
                                        "inputType": "checkbox",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": true,
                                        "disabled": true,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofCUAS",
                                        "label": "Alternative Fuel",
                                        "displaySequence": 1,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": true,
                                            "disabled": true
                                          }
                                        ],
                                        "userValues": false
                                      },
                                      {
                                        "code": "avAntiTheft",
                                        "dataType": "text",
                                        "inputType": "checkbox",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": true,
                                        "disabled": true,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofDUAS",
                                        "label": "Anti Theft",
                                        "displaySequence": 2,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": true,
                                            "disabled": true
                                          }
                                        ],
                                        "userValues": true
                                      },
                                      {
                                        "code": "avBrakes",
                                        "dataType": "text",
                                        "inputType": "checkbox",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": true,
                                        "disabled": true,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofFUAS",
                                        "label": "Brakes",
                                        "displaySequence": 3,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": true,
                                            "disabled": true
                                          }
                                        ],
                                        "userValues": false
                                      },
                                      {
                                        "code": "avClaimFreq",
                                        "dataType": "number",
                                        "inputType": "number",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": true,
                                        "disabled": true,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofGUAS",
                                        "label": "Claim Frequency",
                                        "displaySequence": 4,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": true,
                                            "disabled": true
                                          }
                                        ],
                                        "userValues": null
                                      },
                                      {
                                        "code": "avClaimSev",
                                        "dataType": "number",
                                        "inputType": "number",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": true,
                                        "disabled": true,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofHUAS",
                                        "label": "Claim Severity",
                                        "displaySequence": 5,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": true,
                                            "disabled": true
                                          }
                                        ],
                                        "userValues": null
                                      },
                                      {
                                        "code": "avLicNum",
                                        "dataType": "text",
                                        "inputType": "text",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": true,
                                        "disabled": true,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofLUAS",
                                        "label": "License Number",
                                        "displaySequence": 6,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": true,
                                            "disabled": true
                                          }
                                        ],
                                        "userValues": null
                                      },
                                      {
                                        "code": "avLicState",
                                        "dataType": "text",
                                        "inputType": "text",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": true,
                                        "disabled": true,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofMUAS",
                                        "label": "License State",
                                        "displaySequence": 7,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": true,
                                            "disabled": true
                                          }
                                        ],
                                        "userValues": null
                                      },
                                      {
                                        "code": "avMake",
                                        "dataType": "text",
                                        "inputType": "text",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": true,
                                        "disabled": true,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofNUAS",
                                        "label": "Make",
                                        "displaySequence": 8,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": true,
                                            "disabled": true
                                          }
                                        ],
                                        "userValues": "BMW"
                                      },
                                      {
                                        "code": "avModel",
                                        "dataType": "text",
                                        "inputType": "text",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": true,
                                        "disabled": true,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofPUAS",
                                        "label": "Model",
                                        "displaySequence": 9,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": true,
                                            "disabled": true
                                          }
                                        ],
                                        "userValues": "M3"
                                      },
                                      {
                                        "code": "avRatedDriver-BIPD",
                                        "dataType": "number",
                                        "inputType": "number",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": true,
                                        "disabled": true,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofQUAS",
                                        "label": "Rated Driver - BIPD",
                                        "displaySequence": 10,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": true,
                                            "disabled": true
                                          }
                                        ],
                                        "userValues": null
                                      },
                                      {
                                        "code": "avRatedDriver-COMP",
                                        "dataType": "number",
                                        "inputType": "number",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": true,
                                        "disabled": true,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofSUAS",
                                        "label": "Rated Driver - Comprehensive",
                                        "displaySequence": 11,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": true,
                                            "disabled": true
                                          }
                                        ],
                                        "userValues": null
                                      },
                                      {
                                        "code": "avRatedDriver-MED",
                                        "dataType": "number",
                                        "inputType": "number",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": true,
                                        "disabled": true,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofTUAS",
                                        "label": "Rated Driver - Medical Payments",
                                        "displaySequence": 12,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": true,
                                            "disabled": true
                                          }
                                        ],
                                        "userValues": null
                                      },
                                      {
                                        "code": "avRatedDriver-UM",
                                        "dataType": "number",
                                        "inputType": "number",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": true,
                                        "disabled": true,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofUUAS",
                                        "label": "Rated Driver - Uninsured Motorist",
                                        "displaySequence": 13,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": true,
                                            "disabled": true
                                          }
                                        ],
                                        "userValues": null
                                      },
                                      {
                                        "code": "avRatedDriverName",
                                        "dataType": "text",
                                        "inputType": "text",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": true,
                                        "disabled": true,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofVUAS",
                                        "label": "Rated Driver Name",
                                        "displaySequence": 14,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": true,
                                            "disabled": true
                                          }
                                        ],
                                        "userValues": null
                                      },
                                      {
                                        "code": "avRestraints",
                                        "dataType": "text",
                                        "inputType": "checkbox",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": true,
                                        "disabled": true,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofWUAS",
                                        "label": "Restraints",
                                        "displaySequence": 15,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": true,
                                            "disabled": true
                                          }
                                        ],
                                        "userValues": false
                                      },
                                      {
                                        "code": "avStabilization",
                                        "dataType": "text",
                                        "inputType": "checkbox",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": true,
                                        "disabled": true,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofXUAS",
                                        "label": "Stablization",
                                        "displaySequence": 16,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": true,
                                            "disabled": true
                                          }
                                        ],
                                        "userValues": false
                                      },
                                      {
                                        "code": "avHistoric",
                                        "dataType": "text",
                                        "inputType": "checkbox",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": false,
                                        "disabled": false,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofKUAS",
                                        "label": "Historic",
                                        "displaySequence": 17,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": false,
                                            "disabled": false
                                          }
                                        ],
                                        "userValues": false
                                      },
                                      {
                                        "code": "avStyle",
                                        "dataType": "text",
                                        "inputType": "text",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": true,
                                        "disabled": true,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofYUAS",
                                        "label": "Style",
                                        "displaySequence": 18,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": true,
                                            "disabled": true
                                          }
                                        ],
                                        "userValues": null
                                      },
                                      {
                                        "code": "avSymbol",
                                        "dataType": "text",
                                        "inputType": "text",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": true,
                                        "disabled": true,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofZUAS",
                                        "label": "Symbol",
                                        "displaySequence": 19,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": true,
                                            "disabled": true
                                          }
                                        ],
                                        "userValues": null
                                      },
                                      {
                                        "code": "avColor",
                                        "dataType": "text",
                                        "inputType": "text",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": true,
                                        "disabled": true,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofIUAS",
                                        "label": "Color",
                                        "displaySequence": 20,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": true,
                                            "disabled": true
                                          }
                                        ],
                                        "userValues": null
                                      },
                                      {
                                        "code": "avVIN",
                                        "dataType": "text",
                                        "inputType": "text",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": true,
                                        "disabled": true,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofaUAC",
                                        "label": "VIN",
                                        "displaySequence": 21,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": true,
                                            "disabled": true
                                          }
                                        ],
                                        "userValues": null
                                      },
                                      {
                                        "code": "avYear",
                                        "dataType": "text",
                                        "inputType": "text",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": true,
                                        "disabled": true,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofcUAC",
                                        "label": "Year",
                                        "displaySequence": 22,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": true,
                                            "disabled": true
                                          }
                                        ],
                                        "userValues": "2019"
                                      },
                                      {
                                        "code": "avMileage",
                                        "dataType": "number",
                                        "inputType": "number",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": true,
                                        "disabled": true,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofOUAS",
                                        "label": "Annual Mileage",
                                        "displaySequence": 23,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": true,
                                            "disabled": true
                                          }
                                        ],
                                        "userValues": 10000
                                      },
                                      {
                                        "code": "avBodyType",
                                        "dataType": "text",
                                        "inputType": "text",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": true,
                                        "disabled": true,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofEUAS",
                                        "label": "Body Type",
                                        "displaySequence": 24,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": true,
                                            "disabled": true
                                          }
                                        ],
                                        "userValues": "Sedan/Saloon"
                                      },
                                      {
                                        "code": "avGaragePostalCode",
                                        "dataType": "text",
                                        "inputType": "text",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": true,
                                        "disabled": true,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofJUAS",
                                        "label": "Garage Location (Postal Code)",
                                        "displaySequence": 25,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": true,
                                            "disabled": true
                                          }
                                        ],
                                        "userValues": "94110"
                                      },
                                      {
                                        "code": "avRatedDriver-COLL",
                                        "dataType": "number",
                                        "inputType": "number",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": true,
                                        "disabled": true,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofRUAS",
                                        "label": "Rated Driver - Collision",
                                        "displaySequence": 26,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": true,
                                            "disabled": true
                                          }
                                        ],
                                        "userValues": null
                                      }
                                    ]
                                  }
                                }
                              ]
                            },
                            "childProducts": {
                              "totalSize": 6,
                              "records": [
                                {
                                  "displaySequence": -1,
                                  "Id": "a0F4x000000wKnYEAU",
                                  "currencySymbol": "$",
                                  "currencyCode": "USD",
                                  "IsDeleted": false,
                                  "Name": "Bodily Injury & Property Damage",
                                  "CreatedDate": "2021-02-10T17:20:22.000+0000",
                                  "CreatedById": "0054x000003KYHhAAO",
                                  "LastModifiedDate": "2021-02-10T17:20:22.000+0000",
                                  "LastModifiedById": "0054x000003KYHhAAO",
                                  "SystemModstamp": "2021-02-10T17:20:22.000+0000",
                                  "vlocity_ins__PolicyAssetId__c": "02i4x000000gnj2AAA",
                                  "vlocity_ins__AggregateLimitAmount__c": 0,
                                  "vlocity_ins__AssetInsuredItemId__c": "a0G4x000000X1CuEAK",
                                  "vlocity_ins__AttributeSelectedValues__c": "{\"autoBIPDLimit.autoPDLimClm\":25000,\"autoBIPDLimit.autoBILimClm\":50000,\"autoBIPDLimit.autoBILimClmCov\":25000,\"autoBIPDLimit\":\"25000/50000/25000\"}",
                                  "vlocity_ins__DeductibleAmount__c": 0,
                                  "vlocity_ins__PremiumAmount__c": 16.5,
                                  "Price": 16.5,
                                  "vlocity_ins__Product2Id__c": "01t4x000001y3ZiAAI",
                                  "vlocity_ins__ProductChildItemId__c": "a484x000000ZhDPAA0",
                                  "vlocity_ins__RecordTypeName__c": "CoverageSpec",
                                  "vlocity_ins__StartDate__c": "2021-02-10T08:00:00.000+0000",
                                  "vlocity_ins__TotalAmount__c": 16.5,
                                  "vlocity_ins__TotalProratedAmount__c": 0,
                                  "isOptional": false,
                                  "isSelected": true,
                                  "ProductCode": "autoBIPD",
                                  "productName": "Bodily Injury & Property Damage",
                                  "productId": "01t4x000001y3ZiAAI",
                                  "pciId": "a484x000000ZhDPAA0",
                                  "PricingSource__c": "premiumBIPD",
                                  "attributeCategories": {
                                    "totalSize": 1,
                                    "records": [
                                      {
                                        "displaySequence": 230,
                                        "Code__c": "autoTerms",
                                        "Name": "Auto Terms",
                                        "id": "a0R4P00000JWzkZUAT",
                                        "productAttributes": {
                                          "totalSize": 1,
                                          "records": [
                                            {
                                              "code": "autoBIPDLimit",
                                              "dataType": "text",
                                              "inputType": "dropdown",
                                              "multiselect": false,
                                              "required": false,
                                              "readonly": false,
                                              "disabled": false,
                                              "filterable": true,
                                              "attributeId": "a0S4P000009YMK7UAO",
                                              "label": "BIPD Limit",
                                              "displaySequence": 0,
                                              "hasRules": true,
                                              "hidden": false,
                                              "cloneable": true,
                                              "isNotTranslatable": false,
                                              "values": [
                                                {
                                                  "id": "0",
                                                  "label": "$15000/$30000/$10000",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": "15000/30000/10000"
                                                },
                                                {
                                                  "id": "1",
                                                  "label": "$15000/$30000/$5000",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": "15000/30000/5000"
                                                },
                                                {
                                                  "id": "2",
                                                  "label": "$25000/$50000/$25000",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": "25000/50000/25000"
                                                },
                                                {
                                                  "id": "3",
                                                  "label": "$25000/$50000/$50000",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": "25000/50000/50000"
                                                },
                                                {
                                                  "id": "4",
                                                  "label": "$50000/$100000/$50000",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": "50000/100000/50000"
                                                },
                                                {
                                                  "id": "5",
                                                  "label": "$50000/$100000/$100000",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": "50000/100000/100000"
                                                },
                                                {
                                                  "id": "6",
                                                  "label": "$100000/$300000/$25000",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": "100000/300000/25000"
                                                },
                                                {
                                                  "id": "7",
                                                  "label": "$100000/$300000/$50000",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": "100000/300000/50000"
                                                },
                                                {
                                                  "id": "8",
                                                  "label": "$100000/$300000/$100000",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": "100000/300000/100000"
                                                },
                                                {
                                                  "id": "9",
                                                  "label": "$250000/$500000/$100000",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": "250000/500000/100000"
                                                },
                                                {
                                                  "id": "10",
                                                  "label": "$500000/$500000/100000",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": "500000/500000/100000"
                                                },
                                                {
                                                  "id": "11",
                                                  "label": "$500000/$500000/$500000",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": "500000/500000/500000"
                                                },
                                                {
                                                  "id": "12",
                                                  "label": "$500000/$1000000/$500000",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": "500000/1000000/500000"
                                                }
                                              ],
                                              "userValues": "25000/50000/25000",
                                              "valueDecoder": "autoBILimClmCov/autoBILimClm/autoPDLimClm"
                                            }
                                          ]
                                        }
                                      }
                                    ]
                                  }
                                },
                                {
                                  "displaySequence": -1,
                                  "Id": "a0F4x000000wKnZEAU",
                                  "currencySymbol": "$",
                                  "currencyCode": "USD",
                                  "IsDeleted": false,
                                  "Name": "Collision",
                                  "CreatedDate": "2021-02-10T17:20:22.000+0000",
                                  "CreatedById": "0054x000003KYHhAAO",
                                  "LastModifiedDate": "2021-02-10T17:20:22.000+0000",
                                  "LastModifiedById": "0054x000003KYHhAAO",
                                  "SystemModstamp": "2021-02-10T17:20:22.000+0000",
                                  "vlocity_ins__PolicyAssetId__c": "02i4x000000gnj2AAA",
                                  "vlocity_ins__AggregateLimitAmount__c": 0,
                                  "vlocity_ins__AssetInsuredItemId__c": "a0G4x000000X1CuEAK",
                                  "vlocity_ins__AttributeSelectedValues__c": "{\"autoCollDedClmCov\":500}",
                                  "vlocity_ins__DeductibleAmount__c": 0,
                                  "vlocity_ins__PremiumAmount__c": 868.56,
                                  "Price": 868.56,
                                  "vlocity_ins__Product2Id__c": "01t4x000001y3aDAAQ",
                                  "vlocity_ins__ProductChildItemId__c": "a484x000000Zh9pAAC",
                                  "vlocity_ins__RecordTypeName__c": "CoverageSpec",
                                  "vlocity_ins__StartDate__c": "2021-02-10T08:00:00.000+0000",
                                  "vlocity_ins__TotalAmount__c": 868.56,
                                  "vlocity_ins__TotalProratedAmount__c": 0,
                                  "isOptional": false,
                                  "isSelected": true,
                                  "ProductCode": "autoCollision",
                                  "productName": "Collision",
                                  "productId": "01t4x000001y3aDAAQ",
                                  "pciId": "a484x000000Zh9pAAC",
                                  "PricingSource__c": "premiumCOLL",
                                  "attributeCategories": {
                                    "totalSize": 1,
                                    "records": [
                                      {
                                        "displaySequence": 230,
                                        "Code__c": "autoTerms",
                                        "Name": "Auto Terms",
                                        "id": "a0R4P00000JWzkZUAT",
                                        "productAttributes": {
                                          "totalSize": 1,
                                          "records": [
                                            {
                                              "code": "autoCollDedClmCov",
                                              "dataType": "currency",
                                              "inputType": "dropdown",
                                              "multiselect": false,
                                              "required": false,
                                              "readonly": false,
                                              "disabled": false,
                                              "filterable": true,
                                              "attributeId": "a0S4P000009YMK8UAO",
                                              "label": "Collision Deductible",
                                              "displaySequence": 0,
                                              "hasRules": false,
                                              "hidden": false,
                                              "cloneable": true,
                                              "isNotTranslatable": false,
                                              "values": [
                                                {
                                                  "id": "0",
                                                  "label": "$250",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": 250
                                                },
                                                {
                                                  "id": "1",
                                                  "label": "$500",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": 500
                                                },
                                                {
                                                  "id": "2",
                                                  "label": "$750",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": 750
                                                },
                                                {
                                                  "id": "3",
                                                  "label": "$1000",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": 1000
                                                },
                                                {
                                                  "id": "4",
                                                  "label": "$1500",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": 1500
                                                },
                                                {
                                                  "id": "5",
                                                  "label": "$2500",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": 2500
                                                }
                                              ],
                                              "userValues": 500
                                            }
                                          ]
                                        }
                                      }
                                    ]
                                  }
                                },
                                {
                                  "displaySequence": -1,
                                  "Id": "a0F4x000000wKnaEAE",
                                  "currencySymbol": "$",
                                  "currencyCode": "USD",
                                  "IsDeleted": false,
                                  "Name": "Comprehensive",
                                  "CreatedDate": "2021-02-10T17:20:22.000+0000",
                                  "CreatedById": "0054x000003KYHhAAO",
                                  "LastModifiedDate": "2021-02-10T17:20:22.000+0000",
                                  "LastModifiedById": "0054x000003KYHhAAO",
                                  "SystemModstamp": "2021-02-10T17:20:22.000+0000",
                                  "vlocity_ins__PolicyAssetId__c": "02i4x000000gnj2AAA",
                                  "vlocity_ins__AggregateLimitAmount__c": 0,
                                  "vlocity_ins__AssetInsuredItemId__c": "a0G4x000000X1CuEAK",
                                  "vlocity_ins__AttributeSelectedValues__c": "{\"autoCompDedClmCov\":100}",
                                  "vlocity_ins__DeductibleAmount__c": 0,
                                  "vlocity_ins__PremiumAmount__c": 350.78,
                                  "Price": 350.78,
                                  "vlocity_ins__Product2Id__c": "01t4x000001y3a1AAA",
                                  "vlocity_ins__ProductChildItemId__c": "a484x000000Zh9nAAC",
                                  "vlocity_ins__RecordTypeName__c": "CoverageSpec",
                                  "vlocity_ins__StartDate__c": "2021-02-10T08:00:00.000+0000",
                                  "vlocity_ins__TotalAmount__c": 350.78,
                                  "vlocity_ins__TotalProratedAmount__c": 0,
                                  "isOptional": false,
                                  "isSelected": true,
                                  "ProductCode": "autoComp",
                                  "productName": "Comprehensive",
                                  "productId": "01t4x000001y3a1AAA",
                                  "pciId": "a484x000000Zh9nAAC",
                                  "PricingSource__c": "premiumCCD",
                                  "attributeCategories": {
                                    "totalSize": 1,
                                    "records": [
                                      {
                                        "displaySequence": 230,
                                        "Code__c": "autoTerms",
                                        "Name": "Auto Terms",
                                        "id": "a0R4P00000JWzkZUAT",
                                        "productAttributes": {
                                          "totalSize": 1,
                                          "records": [
                                            {
                                              "code": "autoCompDedClmCov",
                                              "dataType": "currency",
                                              "inputType": "dropdown",
                                              "multiselect": false,
                                              "required": false,
                                              "readonly": false,
                                              "disabled": false,
                                              "filterable": true,
                                              "attributeId": "a0S4P000009YMK9UAO",
                                              "label": "Comp Deductible",
                                              "displaySequence": 0,
                                              "hasRules": false,
                                              "hidden": false,
                                              "cloneable": true,
                                              "isNotTranslatable": false,
                                              "values": [
                                                {
                                                  "id": "0",
                                                  "label": "$100",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": 100
                                                },
                                                {
                                                  "id": "1",
                                                  "label": "$250",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": 250
                                                },
                                                {
                                                  "id": "2",
                                                  "label": "$500",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": 500
                                                },
                                                {
                                                  "id": "3",
                                                  "label": "$750",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": 750
                                                },
                                                {
                                                  "id": "4",
                                                  "label": "$1000",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": 1000
                                                },
                                                {
                                                  "id": "5",
                                                  "label": "$1500",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": 1500
                                                },
                                                {
                                                  "id": "6",
                                                  "label": "$2500",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": 2500
                                                }
                                              ],
                                              "userValues": 100
                                            }
                                          ]
                                        }
                                      }
                                    ]
                                  }
                                },
                                {
                                  "displaySequence": -1,
                                  "Id": "a0F4x000000wKnbEAE",
                                  "currencySymbol": "$",
                                  "currencyCode": "USD",
                                  "IsDeleted": false,
                                  "Name": "Medical Payments",
                                  "CreatedDate": "2021-02-10T17:20:22.000+0000",
                                  "CreatedById": "0054x000003KYHhAAO",
                                  "LastModifiedDate": "2021-02-10T17:20:22.000+0000",
                                  "LastModifiedById": "0054x000003KYHhAAO",
                                  "SystemModstamp": "2021-02-10T17:20:22.000+0000",
                                  "vlocity_ins__PolicyAssetId__c": "02i4x000000gnj2AAA",
                                  "vlocity_ins__AggregateLimitAmount__c": 0,
                                  "vlocity_ins__AssetInsuredItemId__c": "a0G4x000000X1CuEAK",
                                  "vlocity_ins__AttributeSelectedValues__c": "{\"autoMedPayLimClmCov\":1000}",
                                  "vlocity_ins__DeductibleAmount__c": 0,
                                  "vlocity_ins__PremiumAmount__c": 37.37,
                                  "Price": 37.37,
                                  "vlocity_ins__Product2Id__c": "01t4x000001y3aKAAQ",
                                  "vlocity_ins__ProductChildItemId__c": "a484x000000Zh9oAAC",
                                  "vlocity_ins__RecordTypeName__c": "CoverageSpec",
                                  "vlocity_ins__StartDate__c": "2021-02-10T08:00:00.000+0000",
                                  "vlocity_ins__TotalAmount__c": 37.37,
                                  "vlocity_ins__TotalProratedAmount__c": 0,
                                  "isOptional": false,
                                  "isSelected": true,
                                  "ProductCode": "autoMedical",
                                  "productName": "Medical Payments",
                                  "productId": "01t4x000001y3aKAAQ",
                                  "pciId": "a484x000000Zh9oAAC",
                                  "PricingSource__c": "premiumMED",
                                  "attributeCategories": {
                                    "totalSize": 1,
                                    "records": [
                                      {
                                        "displaySequence": 230,
                                        "Code__c": "autoTerms",
                                        "Name": "Auto Terms",
                                        "id": "a0R4P00000JWzkZUAT",
                                        "productAttributes": {
                                          "totalSize": 1,
                                          "records": [
                                            {
                                              "code": "autoMedPayLimClmCov",
                                              "dataType": "currency",
                                              "inputType": "dropdown",
                                              "multiselect": false,
                                              "required": false,
                                              "readonly": false,
                                              "disabled": false,
                                              "filterable": true,
                                              "attributeId": "a0S4P000009YMKCUA4",
                                              "label": "Med Pay Person Limit",
                                              "displaySequence": 0,
                                              "hasRules": false,
                                              "hidden": false,
                                              "cloneable": true,
                                              "isNotTranslatable": false,
                                              "values": [
                                                {
                                                  "id": "0",
                                                  "label": "$1000",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": 1000
                                                },
                                                {
                                                  "id": "1",
                                                  "label": "$2000",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": 2000
                                                },
                                                {
                                                  "id": "2",
                                                  "label": "$5000",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": 5000
                                                }
                                              ],
                                              "userValues": 1000
                                            }
                                          ]
                                        }
                                      }
                                    ]
                                  }
                                },
                                {
                                  "displaySequence": -1,
                                  "Id": "a0F4x000000wKncEAE",
                                  "currencySymbol": "$",
                                  "currencyCode": "USD",
                                  "IsDeleted": false,
                                  "Name": "Uninsured Motorist",
                                  "CreatedDate": "2021-02-10T17:20:22.000+0000",
                                  "CreatedById": "0054x000003KYHhAAO",
                                  "LastModifiedDate": "2021-02-10T17:20:22.000+0000",
                                  "LastModifiedById": "0054x000003KYHhAAO",
                                  "SystemModstamp": "2021-02-10T17:20:22.000+0000",
                                  "vlocity_ins__PolicyAssetId__c": "02i4x000000gnj2AAA",
                                  "vlocity_ins__AggregateLimitAmount__c": 0,
                                  "vlocity_ins__AssetInsuredItemId__c": "a0G4x000000X1CuEAK",
                                  "vlocity_ins__AttributeSelectedValues__c": "{\"autoUMLimit\":\"50/100\"}",
                                  "vlocity_ins__DeductibleAmount__c": 0,
                                  "vlocity_ins__PremiumAmount__c": 68.22,
                                  "Price": 68.22,
                                  "vlocity_ins__Product2Id__c": "01t4x000001y3ZzAAI",
                                  "vlocity_ins__ProductChildItemId__c": "a484x000000Zh9sAAC",
                                  "vlocity_ins__RecordTypeName__c": "CoverageSpec",
                                  "vlocity_ins__StartDate__c": "2021-02-10T08:00:00.000+0000",
                                  "vlocity_ins__TotalAmount__c": 68.22,
                                  "vlocity_ins__TotalProratedAmount__c": 0,
                                  "isOptional": false,
                                  "isSelected": true,
                                  "ProductCode": "autoUM",
                                  "productName": "Uninsured Motorist",
                                  "productId": "01t4x000001y3ZzAAI",
                                  "pciId": "a484x000000Zh9sAAC",
                                  "PricingSource__c": "premiumUM",
                                  "attributeCategories": {
                                    "totalSize": 1,
                                    "records": [
                                      {
                                        "displaySequence": 230,
                                        "Code__c": "autoTerms",
                                        "Name": "Auto Terms",
                                        "id": "a0R4P00000JWzkZUAT",
                                        "productAttributes": {
                                          "totalSize": 1,
                                          "records": [
                                            {
                                              "code": "autoUMLimit",
                                              "dataType": "text",
                                              "inputType": "dropdown",
                                              "multiselect": false,
                                              "required": false,
                                              "readonly": false,
                                              "disabled": false,
                                              "filterable": true,
                                              "attributeId": "a0S4P000009YMKGUA4",
                                              "label": "UM Limit",
                                              "displaySequence": 0,
                                              "hasRules": false,
                                              "hidden": false,
                                              "cloneable": true,
                                              "isNotTranslatable": false,
                                              "values": [
                                                {
                                                  "id": "0",
                                                  "label": "$15,000 / $30,000",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": "15/30"
                                                },
                                                {
                                                  "id": "1",
                                                  "label": "$25,000 / $50,000",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": "25/50"
                                                },
                                                {
                                                  "id": "2",
                                                  "label": "$30,000 / $60,000",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": "30/60"
                                                },
                                                {
                                                  "id": "3",
                                                  "label": "$50,000 / $100,000",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": "50/100"
                                                },
                                                {
                                                  "id": "4",
                                                  "label": "$100,000 / $300,000",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": "100/300"
                                                },
                                                {
                                                  "id": "5",
                                                  "label": "$250,000 / $500,000",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": "250/500"
                                                },
                                                {
                                                  "id": "6",
                                                  "label": "$500,000 / $500,000",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": "500/500"
                                                },
                                                {
                                                  "id": "7",
                                                  "label": "$500,000 / $1,000,000",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": "500/1000"
                                                }
                                              ],
                                              "userValues": "50/100"
                                            }
                                          ]
                                        }
                                      }
                                    ]
                                  }
                                },
                                {
                                  "displaySequence": -1,
                                  "productId": "01t4x000001y3aRAAQ",
                                  "productName": "Rental Car",
                                  "ProductCode": "autoRental",
                                  "Name": "Rental Car",
                                  "pciId": "a484x000000Zh9tAAC",
                                  "isOptional": true,
                                  "isSelected": false,
                                  "vlocity_ins__RecordTypeName__c": "CoverageSpec",
                                  "vlocity_ins__PricingSource__c": "premiumRental",
                                  "attributeCategories": {
                                    "totalSize": 1,
                                    "records": [
                                      {
                                        "displaySequence": 230,
                                        "Code__c": "autoTerms",
                                        "Name": "Auto Terms",
                                        "id": "a0R4P00000JWzkZUAT",
                                        "productAttributes": {
                                          "totalSize": 2,
                                          "records": [
                                            {
                                              "code": "autoRentalLimClmCov",
                                              "dataType": "currency",
                                              "inputType": "number",
                                              "multiselect": false,
                                              "required": false,
                                              "readonly": true,
                                              "disabled": true,
                                              "filterable": true,
                                              "attributeId": "a0S4P000009YMKFUA4",
                                              "label": "Rental Limit",
                                              "displaySequence": 0,
                                              "hasRules": false,
                                              "hidden": false,
                                              "cloneable": true,
                                              "isNotTranslatable": false,
                                              "values": [
                                                {
                                                  "readonly": true,
                                                  "disabled": true
                                                }
                                              ],
                                              "userValues": 2000
                                            },
                                            {
                                              "code": "autoRentalDays",
                                              "dataType": "number",
                                              "inputType": "number",
                                              "multiselect": false,
                                              "required": false,
                                              "readonly": true,
                                              "disabled": true,
                                              "filterable": true,
                                              "attributeId": "a0S4P000009YMKEUA4",
                                              "label": "Number of Days",
                                              "displaySequence": 1,
                                              "hasRules": false,
                                              "hidden": false,
                                              "cloneable": true,
                                              "isNotTranslatable": false,
                                              "values": [
                                                {
                                                  "readonly": true,
                                                  "disabled": true
                                                }
                                              ],
                                              "userValues": 30
                                            }
                                          ]
                                        }
                                      }
                                    ]
                                  }
                                }
                              ]
                            }
                          },
                          {
                            "displaySequence": -1,
                            "Id": "a0G4x000000X1CvEAK",
                            "currencySymbol": "$",
                            "currencyCode": "USD",
                            "IsDeleted": false,
                            "Name": "2020 Mazda CX-30",
                            "instanceKey": "2020 Mazda CX-30",
                            "CreatedDate": "2021-02-10T17:20:22.000+0000",
                            "CreatedById": "0054x000003KYHhAAO",
                            "LastModifiedDate": "2021-02-10T17:20:22.000+0000",
                            "LastModifiedById": "0054x000003KYHhAAO",
                            "SystemModstamp": "2021-02-10T17:20:22.000+0000",
                            "vlocity_ins__PolicyAssetId__c": "02i4x000000gnj2AAA",
                            "vlocity_ins__AttributeSelectedValues__c": "{\"avRestraints\":false,\"ProductCode\":\"autoVehicle\",\"avBodyType\":\"Sedan/SUV\",\"avBrakes\":true,\"avHistoric\":false,\"avModel\":\"CX-30\",\"avStabilization\":true,\"avGaragePostalCode\":\"94110\",\"isParent\":true,\"avMake\":\"Mazda\",\"avValue\":26200,\"avMileage\":15000,\"avYear\":\"2020\",\"avAntiTheft\":false,\"avAltFuel\":false}",
                            "vlocity_ins__InsuredItemNumber__c": "2020 Mazda CX-30",
                            "vlocity_ins__MarketValue__c": 0,
                            "vlocity_ins__PremiumAmount__c": 1131.69,
                            "Price": 1131.69,
                            "vlocity_ins__Product2Id__c": "01t4x000001y3a0AAA",
                            "vlocity_ins__ProductChildItemId__c": "a484x000000Zh9qAAC",
                            "vlocity_ins__RecordTypeName__c": "InsuredItemSpec",
                            "vlocity_ins__TotalAmount__c": 1131.69,
                            "vlocity_ins__TotalProratedAmount__c": 0,
                            "hasAttributes": true,
                            "PricingFormula__c": "premiumBIPD + premiumCOLL + premiumCCD + premiumMED + premiumUM+premiumRental",
                            "minCount": 1,
                            "maxCount": 1,
                            "productName": "Vehicle",
                            "productId": "01t4x000001y3a0AAA",
                            "ProductCode": "autoVehicle",
                            "pciId": "a484x000000Zh9qAAC",
                            "hasCoverages": true,
                            "attributeCategories": {
                              "totalSize": 1,
                              "records": [
                                {
                                  "displaySequence": 210,
                                  "Code__c": "autoVehicle",
                                  "Name": "Auto Vehicle",
                                  "id": "a0R4P00000J2MJyUAN",
                                  "productAttributes": {
                                    "totalSize": 27,
                                    "records": [
                                      {
                                        "code": "avValue",
                                        "dataType": "currency",
                                        "inputType": "number",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": true,
                                        "disabled": true,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofbUAC",
                                        "label": "Value",
                                        "displaySequence": 0,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": true,
                                            "disabled": true
                                          }
                                        ],
                                        "userValues": 26200
                                      },
                                      {
                                        "code": "avAltFuel",
                                        "dataType": "text",
                                        "inputType": "checkbox",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": true,
                                        "disabled": true,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofCUAS",
                                        "label": "Alternative Fuel",
                                        "displaySequence": 1,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": true,
                                            "disabled": true
                                          }
                                        ],
                                        "userValues": false
                                      },
                                      {
                                        "code": "avAntiTheft",
                                        "dataType": "text",
                                        "inputType": "checkbox",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": true,
                                        "disabled": true,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofDUAS",
                                        "label": "Anti Theft",
                                        "displaySequence": 2,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": true,
                                            "disabled": true
                                          }
                                        ],
                                        "userValues": false
                                      },
                                      {
                                        "code": "avBrakes",
                                        "dataType": "text",
                                        "inputType": "checkbox",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": true,
                                        "disabled": true,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofFUAS",
                                        "label": "Brakes",
                                        "displaySequence": 3,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": true,
                                            "disabled": true
                                          }
                                        ],
                                        "userValues": true
                                      },
                                      {
                                        "code": "avClaimFreq",
                                        "dataType": "number",
                                        "inputType": "number",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": true,
                                        "disabled": true,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofGUAS",
                                        "label": "Claim Frequency",
                                        "displaySequence": 4,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": true,
                                            "disabled": true
                                          }
                                        ],
                                        "userValues": null
                                      },
                                      {
                                        "code": "avClaimSev",
                                        "dataType": "number",
                                        "inputType": "number",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": true,
                                        "disabled": true,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofHUAS",
                                        "label": "Claim Severity",
                                        "displaySequence": 5,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": true,
                                            "disabled": true
                                          }
                                        ],
                                        "userValues": null
                                      },
                                      {
                                        "code": "avLicNum",
                                        "dataType": "text",
                                        "inputType": "text",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": true,
                                        "disabled": true,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofLUAS",
                                        "label": "License Number",
                                        "displaySequence": 6,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": true,
                                            "disabled": true
                                          }
                                        ],
                                        "userValues": null
                                      },
                                      {
                                        "code": "avLicState",
                                        "dataType": "text",
                                        "inputType": "text",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": true,
                                        "disabled": true,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofMUAS",
                                        "label": "License State",
                                        "displaySequence": 7,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": true,
                                            "disabled": true
                                          }
                                        ],
                                        "userValues": null
                                      },
                                      {
                                        "code": "avMake",
                                        "dataType": "text",
                                        "inputType": "text",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": true,
                                        "disabled": true,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofNUAS",
                                        "label": "Make",
                                        "displaySequence": 8,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": true,
                                            "disabled": true
                                          }
                                        ],
                                        "userValues": "Mazda"
                                      },
                                      {
                                        "code": "avModel",
                                        "dataType": "text",
                                        "inputType": "text",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": true,
                                        "disabled": true,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofPUAS",
                                        "label": "Model",
                                        "displaySequence": 9,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": true,
                                            "disabled": true
                                          }
                                        ],
                                        "userValues": "CX-30"
                                      },
                                      {
                                        "code": "avRatedDriver-BIPD",
                                        "dataType": "number",
                                        "inputType": "number",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": true,
                                        "disabled": true,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofQUAS",
                                        "label": "Rated Driver - BIPD",
                                        "displaySequence": 10,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": true,
                                            "disabled": true
                                          }
                                        ],
                                        "userValues": null
                                      },
                                      {
                                        "code": "avRatedDriver-COMP",
                                        "dataType": "number",
                                        "inputType": "number",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": true,
                                        "disabled": true,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofSUAS",
                                        "label": "Rated Driver - Comprehensive",
                                        "displaySequence": 11,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": true,
                                            "disabled": true
                                          }
                                        ],
                                        "userValues": null
                                      },
                                      {
                                        "code": "avRatedDriver-MED",
                                        "dataType": "number",
                                        "inputType": "number",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": true,
                                        "disabled": true,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofTUAS",
                                        "label": "Rated Driver - Medical Payments",
                                        "displaySequence": 12,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": true,
                                            "disabled": true
                                          }
                                        ],
                                        "userValues": null
                                      },
                                      {
                                        "code": "avRatedDriver-UM",
                                        "dataType": "number",
                                        "inputType": "number",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": true,
                                        "disabled": true,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofUUAS",
                                        "label": "Rated Driver - Uninsured Motorist",
                                        "displaySequence": 13,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": true,
                                            "disabled": true
                                          }
                                        ],
                                        "userValues": null
                                      },
                                      {
                                        "code": "avRatedDriverName",
                                        "dataType": "text",
                                        "inputType": "text",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": true,
                                        "disabled": true,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofVUAS",
                                        "label": "Rated Driver Name",
                                        "displaySequence": 14,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": true,
                                            "disabled": true
                                          }
                                        ],
                                        "userValues": null
                                      },
                                      {
                                        "code": "avRestraints",
                                        "dataType": "text",
                                        "inputType": "checkbox",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": true,
                                        "disabled": true,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofWUAS",
                                        "label": "Restraints",
                                        "displaySequence": 15,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": true,
                                            "disabled": true
                                          }
                                        ],
                                        "userValues": false
                                      },
                                      {
                                        "code": "avStabilization",
                                        "dataType": "text",
                                        "inputType": "checkbox",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": true,
                                        "disabled": true,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofXUAS",
                                        "label": "Stablization",
                                        "displaySequence": 16,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": true,
                                            "disabled": true
                                          }
                                        ],
                                        "userValues": true
                                      },
                                      {
                                        "code": "avHistoric",
                                        "dataType": "text",
                                        "inputType": "checkbox",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": false,
                                        "disabled": false,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofKUAS",
                                        "label": "Historic",
                                        "displaySequence": 17,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": false,
                                            "disabled": false
                                          }
                                        ],
                                        "userValues": false
                                      },
                                      {
                                        "code": "avStyle",
                                        "dataType": "text",
                                        "inputType": "text",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": true,
                                        "disabled": true,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofYUAS",
                                        "label": "Style",
                                        "displaySequence": 18,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": true,
                                            "disabled": true
                                          }
                                        ],
                                        "userValues": null
                                      },
                                      {
                                        "code": "avSymbol",
                                        "dataType": "text",
                                        "inputType": "text",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": true,
                                        "disabled": true,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofZUAS",
                                        "label": "Symbol",
                                        "displaySequence": 19,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": true,
                                            "disabled": true
                                          }
                                        ],
                                        "userValues": null
                                      },
                                      {
                                        "code": "avColor",
                                        "dataType": "text",
                                        "inputType": "text",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": true,
                                        "disabled": true,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofIUAS",
                                        "label": "Color",
                                        "displaySequence": 20,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": true,
                                            "disabled": true
                                          }
                                        ],
                                        "userValues": null
                                      },
                                      {
                                        "code": "avVIN",
                                        "dataType": "text",
                                        "inputType": "text",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": true,
                                        "disabled": true,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofaUAC",
                                        "label": "VIN",
                                        "displaySequence": 21,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": true,
                                            "disabled": true
                                          }
                                        ],
                                        "userValues": null
                                      },
                                      {
                                        "code": "avYear",
                                        "dataType": "text",
                                        "inputType": "text",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": true,
                                        "disabled": true,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofcUAC",
                                        "label": "Year",
                                        "displaySequence": 22,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": true,
                                            "disabled": true
                                          }
                                        ],
                                        "userValues": "2020"
                                      },
                                      {
                                        "code": "avMileage",
                                        "dataType": "number",
                                        "inputType": "number",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": true,
                                        "disabled": true,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofOUAS",
                                        "label": "Annual Mileage",
                                        "displaySequence": 23,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": true,
                                            "disabled": true
                                          }
                                        ],
                                        "userValues": 15000
                                      },
                                      {
                                        "code": "avBodyType",
                                        "dataType": "text",
                                        "inputType": "text",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": true,
                                        "disabled": true,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofEUAS",
                                        "label": "Body Type",
                                        "displaySequence": 24,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": true,
                                            "disabled": true
                                          }
                                        ],
                                        "userValues": "Sedan/SUV"
                                      },
                                      {
                                        "code": "avGaragePostalCode",
                                        "dataType": "text",
                                        "inputType": "text",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": true,
                                        "disabled": true,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofJUAS",
                                        "label": "Garage Location (Postal Code)",
                                        "displaySequence": 25,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": true,
                                            "disabled": true
                                          }
                                        ],
                                        "userValues": "94110"
                                      },
                                      {
                                        "code": "avRatedDriver-COLL",
                                        "dataType": "number",
                                        "inputType": "number",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": true,
                                        "disabled": true,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VofRUAS",
                                        "label": "Rated Driver - Collision",
                                        "displaySequence": 26,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": true,
                                            "disabled": true
                                          }
                                        ],
                                        "userValues": null
                                      }
                                    ]
                                  }
                                }
                              ]
                            },
                            "childProducts": {
                              "totalSize": 6,
                              "records": [
                                {
                                  "displaySequence": -1,
                                  "Id": "a0F4x000000wKndEAE",
                                  "currencySymbol": "$",
                                  "currencyCode": "USD",
                                  "IsDeleted": false,
                                  "Name": "Bodily Injury & Property Damage",
                                  "CreatedDate": "2021-02-10T17:20:22.000+0000",
                                  "CreatedById": "0054x000003KYHhAAO",
                                  "LastModifiedDate": "2021-02-10T17:20:22.000+0000",
                                  "LastModifiedById": "0054x000003KYHhAAO",
                                  "SystemModstamp": "2021-02-10T17:20:22.000+0000",
                                  "vlocity_ins__PolicyAssetId__c": "02i4x000000gnj2AAA",
                                  "vlocity_ins__AggregateLimitAmount__c": 0,
                                  "vlocity_ins__AssetInsuredItemId__c": "a0G4x000000X1CvEAK",
                                  "vlocity_ins__AttributeSelectedValues__c": "{\"autoBIPDLimit.autoPDLimClm\":25000,\"autoBIPDLimit.autoBILimClm\":50000,\"autoBIPDLimit.autoBILimClmCov\":25000,\"autoBIPDLimit\":\"25000/50000/25000\"}",
                                  "vlocity_ins__DeductibleAmount__c": 0,
                                  "vlocity_ins__PremiumAmount__c": 18.39,
                                  "Price": 18.39,
                                  "vlocity_ins__Product2Id__c": "01t4x000001y3ZiAAI",
                                  "vlocity_ins__ProductChildItemId__c": "a484x000000ZhDPAA0",
                                  "vlocity_ins__RecordTypeName__c": "CoverageSpec",
                                  "vlocity_ins__StartDate__c": "2021-02-10T08:00:00.000+0000",
                                  "vlocity_ins__TotalAmount__c": 18.39,
                                  "vlocity_ins__TotalProratedAmount__c": 0,
                                  "isOptional": false,
                                  "isSelected": true,
                                  "ProductCode": "autoBIPD",
                                  "productName": "Bodily Injury & Property Damage",
                                  "productId": "01t4x000001y3ZiAAI",
                                  "pciId": "a484x000000ZhDPAA0",
                                  "PricingSource__c": "premiumBIPD",
                                  "attributeCategories": {
                                    "totalSize": 1,
                                    "records": [
                                      {
                                        "displaySequence": 230,
                                        "Code__c": "autoTerms",
                                        "Name": "Auto Terms",
                                        "id": "a0R4P00000JWzkZUAT",
                                        "productAttributes": {
                                          "totalSize": 1,
                                          "records": [
                                            {
                                              "code": "autoBIPDLimit",
                                              "dataType": "text",
                                              "inputType": "dropdown",
                                              "multiselect": false,
                                              "required": false,
                                              "readonly": false,
                                              "disabled": false,
                                              "filterable": true,
                                              "attributeId": "a0S4P000009YMK7UAO",
                                              "label": "BIPD Limit",
                                              "displaySequence": 0,
                                              "hasRules": true,
                                              "hidden": false,
                                              "cloneable": true,
                                              "isNotTranslatable": false,
                                              "values": [
                                                {
                                                  "id": "0",
                                                  "label": "$15000/$30000/$10000",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": "15000/30000/10000"
                                                },
                                                {
                                                  "id": "1",
                                                  "label": "$15000/$30000/$5000",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": "15000/30000/5000"
                                                },
                                                {
                                                  "id": "2",
                                                  "label": "$25000/$50000/$25000",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": "25000/50000/25000"
                                                },
                                                {
                                                  "id": "3",
                                                  "label": "$25000/$50000/$50000",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": "25000/50000/50000"
                                                },
                                                {
                                                  "id": "4",
                                                  "label": "$50000/$100000/$50000",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": "50000/100000/50000"
                                                },
                                                {
                                                  "id": "5",
                                                  "label": "$50000/$100000/$100000",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": "50000/100000/100000"
                                                },
                                                {
                                                  "id": "6",
                                                  "label": "$100000/$300000/$25000",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": "100000/300000/25000"
                                                },
                                                {
                                                  "id": "7",
                                                  "label": "$100000/$300000/$50000",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": "100000/300000/50000"
                                                },
                                                {
                                                  "id": "8",
                                                  "label": "$100000/$300000/$100000",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": "100000/300000/100000"
                                                },
                                                {
                                                  "id": "9",
                                                  "label": "$250000/$500000/$100000",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": "250000/500000/100000"
                                                },
                                                {
                                                  "id": "10",
                                                  "label": "$500000/$500000/100000",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": "500000/500000/100000"
                                                },
                                                {
                                                  "id": "11",
                                                  "label": "$500000/$500000/$500000",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": "500000/500000/500000"
                                                },
                                                {
                                                  "id": "12",
                                                  "label": "$500000/$1000000/$500000",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": "500000/1000000/500000"
                                                }
                                              ],
                                              "userValues": "25000/50000/25000",
                                              "valueDecoder": "autoBILimClmCov/autoBILimClm/autoPDLimClm"
                                            }
                                          ]
                                        }
                                      }
                                    ]
                                  }
                                },
                                {
                                  "displaySequence": -1,
                                  "Id": "a0F4x000000wKneEAE",
                                  "currencySymbol": "$",
                                  "currencyCode": "USD",
                                  "IsDeleted": false,
                                  "Name": "Collision",
                                  "CreatedDate": "2021-02-10T17:20:22.000+0000",
                                  "CreatedById": "0054x000003KYHhAAO",
                                  "LastModifiedDate": "2021-02-10T17:20:22.000+0000",
                                  "LastModifiedById": "0054x000003KYHhAAO",
                                  "SystemModstamp": "2021-02-10T17:20:22.000+0000",
                                  "vlocity_ins__PolicyAssetId__c": "02i4x000000gnj2AAA",
                                  "vlocity_ins__AggregateLimitAmount__c": 0,
                                  "vlocity_ins__AssetInsuredItemId__c": "a0G4x000000X1CvEAK",
                                  "vlocity_ins__AttributeSelectedValues__c": "{\"autoCollDedClmCov\":500}",
                                  "vlocity_ins__DeductibleAmount__c": 0,
                                  "vlocity_ins__PremiumAmount__c": 717,
                                  "Price": 717,
                                  "vlocity_ins__Product2Id__c": "01t4x000001y3aDAAQ",
                                  "vlocity_ins__ProductChildItemId__c": "a484x000000Zh9pAAC",
                                  "vlocity_ins__RecordTypeName__c": "CoverageSpec",
                                  "vlocity_ins__StartDate__c": "2021-02-10T08:00:00.000+0000",
                                  "vlocity_ins__TotalAmount__c": 717,
                                  "vlocity_ins__TotalProratedAmount__c": 0,
                                  "isOptional": false,
                                  "isSelected": true,
                                  "ProductCode": "autoCollision",
                                  "productName": "Collision",
                                  "productId": "01t4x000001y3aDAAQ",
                                  "pciId": "a484x000000Zh9pAAC",
                                  "PricingSource__c": "premiumCOLL",
                                  "attributeCategories": {
                                    "totalSize": 1,
                                    "records": [
                                      {
                                        "displaySequence": 230,
                                        "Code__c": "autoTerms",
                                        "Name": "Auto Terms",
                                        "id": "a0R4P00000JWzkZUAT",
                                        "productAttributes": {
                                          "totalSize": 1,
                                          "records": [
                                            {
                                              "code": "autoCollDedClmCov",
                                              "dataType": "currency",
                                              "inputType": "dropdown",
                                              "multiselect": false,
                                              "required": false,
                                              "readonly": false,
                                              "disabled": false,
                                              "filterable": true,
                                              "attributeId": "a0S4P000009YMK8UAO",
                                              "label": "Collision Deductible",
                                              "displaySequence": 0,
                                              "hasRules": false,
                                              "hidden": false,
                                              "cloneable": true,
                                              "isNotTranslatable": false,
                                              "values": [
                                                {
                                                  "id": "0",
                                                  "label": "$250",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": 250
                                                },
                                                {
                                                  "id": "1",
                                                  "label": "$500",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": 500
                                                },
                                                {
                                                  "id": "2",
                                                  "label": "$750",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": 750
                                                },
                                                {
                                                  "id": "3",
                                                  "label": "$1000",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": 1000
                                                },
                                                {
                                                  "id": "4",
                                                  "label": "$1500",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": 1500
                                                },
                                                {
                                                  "id": "5",
                                                  "label": "$2500",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": 2500
                                                }
                                              ],
                                              "userValues": 500
                                            }
                                          ]
                                        }
                                      }
                                    ]
                                  }
                                },
                                {
                                  "displaySequence": -1,
                                  "Id": "a0F4x000000wKnfEAE",
                                  "currencySymbol": "$",
                                  "currencyCode": "USD",
                                  "IsDeleted": false,
                                  "Name": "Comprehensive",
                                  "CreatedDate": "2021-02-10T17:20:22.000+0000",
                                  "CreatedById": "0054x000003KYHhAAO",
                                  "LastModifiedDate": "2021-02-10T17:20:22.000+0000",
                                  "LastModifiedById": "0054x000003KYHhAAO",
                                  "SystemModstamp": "2021-02-10T17:20:22.000+0000",
                                  "vlocity_ins__PolicyAssetId__c": "02i4x000000gnj2AAA",
                                  "vlocity_ins__AggregateLimitAmount__c": 0,
                                  "vlocity_ins__AssetInsuredItemId__c": "a0G4x000000X1CvEAK",
                                  "vlocity_ins__AttributeSelectedValues__c": "{\"autoCompDedClmCov\":100}",
                                  "vlocity_ins__DeductibleAmount__c": 0,
                                  "vlocity_ins__PremiumAmount__c": 292.37,
                                  "Price": 292.37,
                                  "vlocity_ins__Product2Id__c": "01t4x000001y3a1AAA",
                                  "vlocity_ins__ProductChildItemId__c": "a484x000000Zh9nAAC",
                                  "vlocity_ins__RecordTypeName__c": "CoverageSpec",
                                  "vlocity_ins__StartDate__c": "2021-02-10T08:00:00.000+0000",
                                  "vlocity_ins__TotalAmount__c": 292.37,
                                  "vlocity_ins__TotalProratedAmount__c": 0,
                                  "isOptional": false,
                                  "isSelected": true,
                                  "ProductCode": "autoComp",
                                  "productName": "Comprehensive",
                                  "productId": "01t4x000001y3a1AAA",
                                  "pciId": "a484x000000Zh9nAAC",
                                  "PricingSource__c": "premiumCCD",
                                  "attributeCategories": {
                                    "totalSize": 1,
                                    "records": [
                                      {
                                        "displaySequence": 230,
                                        "Code__c": "autoTerms",
                                        "Name": "Auto Terms",
                                        "id": "a0R4P00000JWzkZUAT",
                                        "productAttributes": {
                                          "totalSize": 1,
                                          "records": [
                                            {
                                              "code": "autoCompDedClmCov",
                                              "dataType": "currency",
                                              "inputType": "dropdown",
                                              "multiselect": false,
                                              "required": false,
                                              "readonly": false,
                                              "disabled": false,
                                              "filterable": true,
                                              "attributeId": "a0S4P000009YMK9UAO",
                                              "label": "Comp Deductible",
                                              "displaySequence": 0,
                                              "hasRules": false,
                                              "hidden": false,
                                              "cloneable": true,
                                              "isNotTranslatable": false,
                                              "values": [
                                                {
                                                  "id": "0",
                                                  "label": "$100",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": 100
                                                },
                                                {
                                                  "id": "1",
                                                  "label": "$250",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": 250
                                                },
                                                {
                                                  "id": "2",
                                                  "label": "$500",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": 500
                                                },
                                                {
                                                  "id": "3",
                                                  "label": "$750",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": 750
                                                },
                                                {
                                                  "id": "4",
                                                  "label": "$1000",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": 1000
                                                },
                                                {
                                                  "id": "5",
                                                  "label": "$1500",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": 1500
                                                },
                                                {
                                                  "id": "6",
                                                  "label": "$2500",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": 2500
                                                }
                                              ],
                                              "userValues": 100
                                            }
                                          ]
                                        }
                                      }
                                    ]
                                  }
                                },
                                {
                                  "displaySequence": -1,
                                  "Id": "a0F4x000000wKngEAE",
                                  "currencySymbol": "$",
                                  "currencyCode": "USD",
                                  "IsDeleted": false,
                                  "Name": "Medical Payments",
                                  "CreatedDate": "2021-02-10T17:20:22.000+0000",
                                  "CreatedById": "0054x000003KYHhAAO",
                                  "LastModifiedDate": "2021-02-10T17:20:22.000+0000",
                                  "LastModifiedById": "0054x000003KYHhAAO",
                                  "SystemModstamp": "2021-02-10T17:20:22.000+0000",
                                  "vlocity_ins__PolicyAssetId__c": "02i4x000000gnj2AAA",
                                  "vlocity_ins__AggregateLimitAmount__c": 0,
                                  "vlocity_ins__AssetInsuredItemId__c": "a0G4x000000X1CvEAK",
                                  "vlocity_ins__AttributeSelectedValues__c": "{\"autoMedPayLimClmCov\":1000}",
                                  "vlocity_ins__DeductibleAmount__c": 0,
                                  "vlocity_ins__PremiumAmount__c": 35.71,
                                  "Price": 35.71,
                                  "vlocity_ins__Product2Id__c": "01t4x000001y3aKAAQ",
                                  "vlocity_ins__ProductChildItemId__c": "a484x000000Zh9oAAC",
                                  "vlocity_ins__RecordTypeName__c": "CoverageSpec",
                                  "vlocity_ins__StartDate__c": "2021-02-10T08:00:00.000+0000",
                                  "vlocity_ins__TotalAmount__c": 35.71,
                                  "vlocity_ins__TotalProratedAmount__c": 0,
                                  "isOptional": false,
                                  "isSelected": true,
                                  "ProductCode": "autoMedical",
                                  "productName": "Medical Payments",
                                  "productId": "01t4x000001y3aKAAQ",
                                  "pciId": "a484x000000Zh9oAAC",
                                  "PricingSource__c": "premiumMED",
                                  "attributeCategories": {
                                    "totalSize": 1,
                                    "records": [
                                      {
                                        "displaySequence": 230,
                                        "Code__c": "autoTerms",
                                        "Name": "Auto Terms",
                                        "id": "a0R4P00000JWzkZUAT",
                                        "productAttributes": {
                                          "totalSize": 1,
                                          "records": [
                                            {
                                              "code": "autoMedPayLimClmCov",
                                              "dataType": "currency",
                                              "inputType": "dropdown",
                                              "multiselect": false,
                                              "required": false,
                                              "readonly": false,
                                              "disabled": false,
                                              "filterable": true,
                                              "attributeId": "a0S4P000009YMKCUA4",
                                              "label": "Med Pay Person Limit",
                                              "displaySequence": 0,
                                              "hasRules": false,
                                              "hidden": false,
                                              "cloneable": true,
                                              "isNotTranslatable": false,
                                              "values": [
                                                {
                                                  "id": "0",
                                                  "label": "$1000",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": 1000
                                                },
                                                {
                                                  "id": "1",
                                                  "label": "$2000",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": 2000
                                                },
                                                {
                                                  "id": "2",
                                                  "label": "$5000",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": 5000
                                                }
                                              ],
                                              "userValues": 1000
                                            }
                                          ]
                                        }
                                      }
                                    ]
                                  }
                                },
                                {
                                  "displaySequence": -1,
                                  "Id": "a0F4x000000wKnhEAE",
                                  "currencySymbol": "$",
                                  "currencyCode": "USD",
                                  "IsDeleted": false,
                                  "Name": "Uninsured Motorist",
                                  "CreatedDate": "2021-02-10T17:20:22.000+0000",
                                  "CreatedById": "0054x000003KYHhAAO",
                                  "LastModifiedDate": "2021-02-10T17:20:22.000+0000",
                                  "LastModifiedById": "0054x000003KYHhAAO",
                                  "SystemModstamp": "2021-02-10T17:20:22.000+0000",
                                  "vlocity_ins__PolicyAssetId__c": "02i4x000000gnj2AAA",
                                  "vlocity_ins__AggregateLimitAmount__c": 0,
                                  "vlocity_ins__AssetInsuredItemId__c": "a0G4x000000X1CvEAK",
                                  "vlocity_ins__AttributeSelectedValues__c": "{\"autoUMLimit\":\"50/100\"}",
                                  "vlocity_ins__DeductibleAmount__c": 0,
                                  "vlocity_ins__PremiumAmount__c": 68.22,
                                  "Price": 68.22,
                                  "vlocity_ins__Product2Id__c": "01t4x000001y3ZzAAI",
                                  "vlocity_ins__ProductChildItemId__c": "a484x000000Zh9sAAC",
                                  "vlocity_ins__RecordTypeName__c": "CoverageSpec",
                                  "vlocity_ins__StartDate__c": "2021-02-10T08:00:00.000+0000",
                                  "vlocity_ins__TotalAmount__c": 68.22,
                                  "vlocity_ins__TotalProratedAmount__c": 0,
                                  "isOptional": false,
                                  "isSelected": true,
                                  "ProductCode": "autoUM",
                                  "productName": "Uninsured Motorist",
                                  "productId": "01t4x000001y3ZzAAI",
                                  "pciId": "a484x000000Zh9sAAC",
                                  "PricingSource__c": "premiumUM",
                                  "attributeCategories": {
                                    "totalSize": 1,
                                    "records": [
                                      {
                                        "displaySequence": 230,
                                        "Code__c": "autoTerms",
                                        "Name": "Auto Terms",
                                        "id": "a0R4P00000JWzkZUAT",
                                        "productAttributes": {
                                          "totalSize": 1,
                                          "records": [
                                            {
                                              "code": "autoUMLimit",
                                              "dataType": "text",
                                              "inputType": "dropdown",
                                              "multiselect": false,
                                              "required": false,
                                              "readonly": false,
                                              "disabled": false,
                                              "filterable": true,
                                              "attributeId": "a0S4P000009YMKGUA4",
                                              "label": "UM Limit",
                                              "displaySequence": 0,
                                              "hasRules": false,
                                              "hidden": false,
                                              "cloneable": true,
                                              "isNotTranslatable": false,
                                              "values": [
                                                {
                                                  "id": "0",
                                                  "label": "$15,000 / $30,000",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": "15/30"
                                                },
                                                {
                                                  "id": "1",
                                                  "label": "$25,000 / $50,000",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": "25/50"
                                                },
                                                {
                                                  "id": "2",
                                                  "label": "$30,000 / $60,000",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": "30/60"
                                                },
                                                {
                                                  "id": "3",
                                                  "label": "$50,000 / $100,000",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": "50/100"
                                                },
                                                {
                                                  "id": "4",
                                                  "label": "$100,000 / $300,000",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": "100/300"
                                                },
                                                {
                                                  "id": "5",
                                                  "label": "$250,000 / $500,000",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": "250/500"
                                                },
                                                {
                                                  "id": "6",
                                                  "label": "$500,000 / $500,000",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": "500/500"
                                                },
                                                {
                                                  "id": "7",
                                                  "label": "$500,000 / $1,000,000",
                                                  "readonly": false,
                                                  "disabled": false,
                                                  "value": "500/1000"
                                                }
                                              ],
                                              "userValues": "50/100"
                                            }
                                          ]
                                        }
                                      }
                                    ]
                                  }
                                },
                                {
                                  "displaySequence": -1,
                                  "productId": "01t4x000001y3aRAAQ",
                                  "productName": "Rental Car",
                                  "ProductCode": "autoRental",
                                  "Name": "Rental Car",
                                  "pciId": "a484x000000Zh9tAAC",
                                  "isOptional": true,
                                  "isSelected": false,
                                  "vlocity_ins__RecordTypeName__c": "CoverageSpec",
                                  "vlocity_ins__PricingSource__c": "premiumRental",
                                  "attributeCategories": {
                                    "totalSize": 1,
                                    "records": [
                                      {
                                        "displaySequence": 230,
                                        "Code__c": "autoTerms",
                                        "Name": "Auto Terms",
                                        "id": "a0R4P00000JWzkZUAT",
                                        "productAttributes": {
                                          "totalSize": 2,
                                          "records": [
                                            {
                                              "code": "autoRentalLimClmCov",
                                              "dataType": "currency",
                                              "inputType": "number",
                                              "multiselect": false,
                                              "required": false,
                                              "readonly": true,
                                              "disabled": true,
                                              "filterable": true,
                                              "attributeId": "a0S4P000009YMKFUA4",
                                              "label": "Rental Limit",
                                              "displaySequence": 0,
                                              "hasRules": false,
                                              "hidden": false,
                                              "cloneable": true,
                                              "isNotTranslatable": false,
                                              "values": [
                                                {
                                                  "readonly": true,
                                                  "disabled": true
                                                }
                                              ],
                                              "userValues": 2000
                                            },
                                            {
                                              "code": "autoRentalDays",
                                              "dataType": "number",
                                              "inputType": "number",
                                              "multiselect": false,
                                              "required": false,
                                              "readonly": true,
                                              "disabled": true,
                                              "filterable": true,
                                              "attributeId": "a0S4P000009YMKEUA4",
                                              "label": "Number of Days",
                                              "displaySequence": 1,
                                              "hasRules": false,
                                              "hidden": false,
                                              "cloneable": true,
                                              "isNotTranslatable": false,
                                              "values": [
                                                {
                                                  "readonly": true,
                                                  "disabled": true
                                                }
                                              ],
                                              "userValues": 30
                                            }
                                          ]
                                        }
                                      }
                                    ]
                                  }
                                }
                              ]
                            }
                          },
                          {
                            "displaySequence": -1,
                            "Id": "a0H4x000001U2fyEAC",
                            "currencySymbol": "$",
                            "currencyCode": "USD",
                            "IsDeleted": false,
                            "Name": "David Flan",
                            "instanceKey": "David Flan",
                            "CreatedDate": "2021-02-10T17:20:22.000+0000",
                            "CreatedById": "0054x000003KYHhAAO",
                            "LastModifiedDate": "2021-02-10T17:20:22.000+0000",
                            "LastModifiedById": "0054x000003KYHhAAO",
                            "SystemModstamp": "2021-02-10T17:20:22.000+0000",
                            "vlocity_ins__AssetId__c": "02i4x000000gnj2AAA",
                            "vlocity_ins__AttributeSelectedValues__c": "{\"adAge\":34,\"adBirthdate\":\"1986-02-14T08:00:00.000Z\",\"adAgeLicensed\":16,\"adFirstName\":\"David\",\"adGender\":\"M\",\"adLastName\":\"Flan\",\"adMiddle\":\"M\",\"adMaritalStatus\":\"M\",\"isParent\":false,\"ProductCode\":\"autoDriver\"}",
                            "vlocity_ins__InsuredPartyNumber__c": "David Flan",
                            "vlocity_ins__InsuredPartySpecId__c": "01t4x000001y3ZvAAI",
                            "vlocity_ins__PartyLink__c": "<a href=\"/\" target=\"_parent\"> </a>",
                            "vlocity_ins__PremiumAmount__c": 0,
                            "Price": 0,
                            "vlocity_ins__RecordTypeName__c": "InsuredPartySpec",
                            "vlocity_ins__TotalAmount__c": 0,
                            "vlocity_ins__TotalProratedAmount__c": 0,
                            "vlocity_ins__IsPolicyholder__c": false,
                            "vlocity_ins__LookupKey__c": "David Flan_",
                            "vlocity_ins__PartyAccountCalculatedAddress__c": "<br>",
                            "hasAttributes": true,
                            "minCount": 1,
                            "maxCount": 1,
                            "productName": "Auto Driver",
                            "productId": "01t4x000001y3ZvAAI",
                            "ProductCode": "autoDriver",
                            "pciId": "a484x000000Zh9rAAC",
                            "hasCoverages": false,
                            "attributeCategories": {
                              "totalSize": 1,
                              "records": [
                                {
                                  "displaySequence": 220,
                                  "Code__c": "autoDriver",
                                  "Name": "Auto Driver",
                                  "id": "a0R4P00000J2MJxUAN",
                                  "productAttributes": {
                                    "totalSize": 21,
                                    "records": [
                                      {
                                        "code": "adSuffix",
                                        "dataType": "text",
                                        "inputType": "text",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": false,
                                        "disabled": false,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VoezUAC",
                                        "label": "Suffix",
                                        "displaySequence": 0,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": false,
                                            "disabled": false
                                          }
                                        ],
                                        "userValues": null
                                      },
                                      {
                                        "code": "adFirstName",
                                        "dataType": "text",
                                        "inputType": "text",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": false,
                                        "disabled": false,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VoemUAC",
                                        "label": "First Name",
                                        "displaySequence": 1,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": false,
                                            "disabled": false
                                          }
                                        ],
                                        "userValues": "David"
                                      },
                                      {
                                        "code": "adMiddle",
                                        "dataType": "text",
                                        "inputType": "text",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": false,
                                        "disabled": false,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VoevUAC",
                                        "label": "Middle Name",
                                        "displaySequence": 2,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": false,
                                            "disabled": false
                                          }
                                        ],
                                        "userValues": "M"
                                      },
                                      {
                                        "code": "adLastName",
                                        "dataType": "text",
                                        "inputType": "text",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": false,
                                        "disabled": false,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VoeqUAC",
                                        "label": "Last Name",
                                        "displaySequence": 3,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": false,
                                            "disabled": false
                                          }
                                        ],
                                        "userValues": "Flan"
                                      },
                                      {
                                        "code": "adBirthdate",
                                        "dataType": "date",
                                        "inputType": "date",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": false,
                                        "disabled": false,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VoelUAC",
                                        "label": "Birthdate",
                                        "displaySequence": 4,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": false,
                                            "disabled": false
                                          }
                                        ],
                                        "userValues": "1986-02-14T08:00:00.000Z"
                                      },
                                      {
                                        "code": "adAgeLicensed",
                                        "dataType": "number",
                                        "inputType": "number",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": false,
                                        "disabled": false,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VoekUAC",
                                        "label": "Age First Licensed",
                                        "displaySequence": 5,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": false,
                                            "disabled": false
                                          }
                                        ],
                                        "userValues": 16
                                      },
                                      {
                                        "code": "adGender",
                                        "dataType": "text",
                                        "inputType": "dropdown",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": false,
                                        "disabled": false,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VoeoUAC",
                                        "label": "Gender",
                                        "displaySequence": 6,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "id": "2",
                                            "label": "Male",
                                            "readonly": false,
                                            "disabled": false,
                                            "value": "M"
                                          },
                                          {
                                            "id": "1",
                                            "label": "Female",
                                            "readonly": false,
                                            "disabled": false,
                                            "value": "F"
                                          }
                                        ],
                                        "userValues": "M"
                                      },
                                      {
                                        "code": "adMaritalStatus",
                                        "dataType": "text",
                                        "inputType": "dropdown",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": false,
                                        "disabled": false,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VoeuUAC",
                                        "label": "Marital Status",
                                        "displaySequence": 7,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "id": "1",
                                            "label": "Married",
                                            "readonly": false,
                                            "disabled": false,
                                            "value": "M"
                                          },
                                          {
                                            "id": "0",
                                            "label": "Single",
                                            "readonly": false,
                                            "disabled": false,
                                            "value": "S"
                                          }
                                        ],
                                        "userValues": "M"
                                      },
                                      {
                                        "code": "adAccidentPoints",
                                        "dataType": "number",
                                        "inputType": "number",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": false,
                                        "disabled": false,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VoeiUAC",
                                        "label": "Driver Accident Points",
                                        "displaySequence": 8,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": false,
                                            "disabled": false
                                          }
                                        ],
                                        "userValues": null
                                      },
                                      {
                                        "code": "adMVRPoints",
                                        "dataType": "number",
                                        "inputType": "number",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": false,
                                        "disabled": false,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VoetUAC",
                                        "label": "Driver MVR Points",
                                        "displaySequence": 9,
                                        "hasRules": false,
                                        "hidden": false,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": false,
                                            "disabled": false
                                          }
                                        ],
                                        "userValues": null
                                      },
                                      {
                                        "code": "adMileage",
                                        "dataType": "number",
                                        "inputType": "number",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": false,
                                        "disabled": false,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VoewUAC",
                                        "label": "Driver Annual Mileage",
                                        "displaySequence": 10,
                                        "hasRules": false,
                                        "hidden": true,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": false,
                                            "disabled": false
                                          }
                                        ],
                                        "userValues": null
                                      },
                                      {
                                        "code": "adGoodStudent",
                                        "dataType": "text",
                                        "inputType": "text",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": false,
                                        "disabled": false,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VoepUAC",
                                        "label": "Good Student",
                                        "displaySequence": 11,
                                        "hasRules": false,
                                        "hidden": true,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": false,
                                            "disabled": false
                                          }
                                        ],
                                        "userValues": null
                                      },
                                      {
                                        "code": "adGPA",
                                        "dataType": "number",
                                        "inputType": "number",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": false,
                                        "disabled": false,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VoenUAC",
                                        "label": "GPA",
                                        "displaySequence": 12,
                                        "hasRules": false,
                                        "hidden": true,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": false,
                                            "disabled": false
                                          }
                                        ],
                                        "userValues": null
                                      },
                                      {
                                        "code": "adLicenseNum",
                                        "dataType": "text",
                                        "inputType": "text",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": false,
                                        "disabled": false,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VoerUAC",
                                        "label": "License Number",
                                        "displaySequence": 13,
                                        "hasRules": false,
                                        "hidden": true,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": false,
                                            "disabled": false
                                          }
                                        ],
                                        "userValues": null
                                      },
                                      {
                                        "code": "adName",
                                        "dataType": "text",
                                        "inputType": "text",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": false,
                                        "disabled": false,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VoexUAC",
                                        "label": "Name",
                                        "displaySequence": 14,
                                        "hasRules": false,
                                        "hidden": true,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": false,
                                            "disabled": false
                                          }
                                        ],
                                        "userValues": null
                                      },
                                      {
                                        "code": "adUse",
                                        "dataType": "text",
                                        "inputType": "text",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": false,
                                        "disabled": false,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004Vof1UAC",
                                        "label": "Primary Use",
                                        "displaySequence": 15,
                                        "hasRules": false,
                                        "hidden": true,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": false,
                                            "disabled": false
                                          }
                                        ],
                                        "userValues": null
                                      },
                                      {
                                        "code": "adSafeDriver",
                                        "dataType": "text",
                                        "inputType": "text",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": false,
                                        "disabled": false,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VoeyUAC",
                                        "label": "Safe Driver",
                                        "displaySequence": 16,
                                        "hasRules": false,
                                        "hidden": true,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": false,
                                            "disabled": false
                                          }
                                        ],
                                        "userValues": null
                                      },
                                      {
                                        "code": "adLicenseState",
                                        "dataType": "text",
                                        "inputType": "text",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": false,
                                        "disabled": false,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VoesUAC",
                                        "label": "State Licensed",
                                        "displaySequence": 17,
                                        "hasRules": false,
                                        "hidden": true,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": false,
                                            "disabled": false
                                          }
                                        ],
                                        "userValues": null
                                      },
                                      {
                                        "code": "adTotalPoints",
                                        "dataType": "number",
                                        "inputType": "number",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": false,
                                        "disabled": false,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004Vof0UAC",
                                        "label": "Total Points",
                                        "displaySequence": 18,
                                        "hasRules": false,
                                        "hidden": true,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": false,
                                            "disabled": false
                                          }
                                        ],
                                        "userValues": null
                                      },
                                      {
                                        "code": "adYrsExp",
                                        "dataType": "number",
                                        "inputType": "number",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": false,
                                        "disabled": false,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004Vof2UAC",
                                        "label": "Years Experience",
                                        "displaySequence": 19,
                                        "hasRules": false,
                                        "hidden": true,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": false,
                                            "disabled": false
                                          }
                                        ],
                                        "userValues": null
                                      },
                                      {
                                        "code": "adAge",
                                        "dataType": "number",
                                        "inputType": "number",
                                        "multiselect": false,
                                        "required": false,
                                        "readonly": false,
                                        "disabled": false,
                                        "filterable": true,
                                        "attributeId": "a0S4P000004VoejUAC",
                                        "label": "Age",
                                        "displaySequence": 20,
                                        "hasRules": false,
                                        "hidden": true,
                                        "cloneable": true,
                                        "isNotTranslatable": false,
                                        "values": [
                                          {
                                            "readonly": false,
                                            "disabled": false
                                          }
                                        ],
                                        "userValues": 34
                                      }
                                    ]
                                  }
                                }
                              ]
                            }
                          }
                        ]
                      }
                    }
                  ]
                }
              ]
            };
        return {
            statusCode: 200,
            statusMessage: 'Success',
            text: JSON.stringify(obj)
        };
    }
};

module.exports = serviceDefinition;
