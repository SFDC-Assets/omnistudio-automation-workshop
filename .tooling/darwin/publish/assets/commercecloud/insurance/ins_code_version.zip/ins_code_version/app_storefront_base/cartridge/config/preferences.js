'use strict';

module.exports = {
    maxOrderQty: 10,
    defaultPageSize: 12,
    plpBackButtonOn: true,
    plpBackButtonLimit: 10
};
