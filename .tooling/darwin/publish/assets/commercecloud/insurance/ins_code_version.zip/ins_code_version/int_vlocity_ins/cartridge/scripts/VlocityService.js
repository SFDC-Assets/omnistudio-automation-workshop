/* eslint-disable valid-jsdoc */
/* eslint-disable require-jsdoc */
'use strict';

var LocalServiceRegistry = require('dw/svc/LocalServiceRegistry');
var StringUtils = require('dw/util/StringUtils');
var ENDPOINTS = require('~/cartridge/config/vlocityServiceEndpoints.json');

function resultIsOK(result) {
    return result.ok &&
        result.status === 'OK' &&
        result.object &&
        !result.object.isError &&
        result.object.responseObj;
}

function VlocityServiceException(errorMessage, errorContext, requestObject) {
    var reqObject = requestObject || {};

    this.message = errorMessage;
    this.errorMessage = errorMessage;
    this.errorContext = errorContext;
    this.endpoint = reqObject.endpoint;
    this.httpMethod = reqObject.httpMethod;

    this.toString = function () {
        return StringUtils.format('Vlocity Service exception: {0}; context: {1}; endpoint: {2}; method: {3}', this.message, this.errorContext, this.endpoint, this.httpMethod);
    };
}

function throwVlocityServiceException(requestObject, result) {
    if (!result.ok) {
        throw new VlocityServiceException(result.errorMessage, 'result', requestObject);
    } else if (result.object && result.object.isError) {
        throw new VlocityServiceException(result.object.errorText, 'result.object', requestObject);
    } else if (result.object && result.object.responseObj && result.object.responseObj.error && (result.object.responseObj.error !== 'OK')) {
        throw new VlocityServiceException(result.object.responseObj.error, 'result.object.responseObj', requestObject);
    } else {
        throw new VlocityServiceException('Unknown error', 'unknown', requestObject);
    }
}

function callService(requestObject) {
    if (!requestObject) {
        throw new Error('Required requestObject parameter missing or incorrect.');
    }

    var service = LocalServiceRegistry.createService('vlocity.rest', require('./services/vlocity'));
    var callResult = service.call(requestObject);

    if (!resultIsOK(callResult)) {
        throwVlocityServiceException(requestObject, callResult);
    }
    return callResult;
}

module.exports.INSAPI = {
    getQuoteDetails: function (quoteId) {

        // TODO: need to fetch vlocity_ins from custom preference
        var requestObject = {
            httpMethod: 'GET',
            endpoint: StringUtils.format(ENDPOINTS.INSAPI_GET_QUOTES,'vlocity_ins',quoteId)
        }


        var result = callService(requestObject);
        return {
            result: result
        }
    },
    
    createMultiplePolicies: function (quoteIds) {
        
        var quoteIds = quoteIds || [];
        var quoteIdsPayload = quoteIds.map(function(quoteId) {
                if (quoteId) {
                    return {Id: quoteId};
                }
            });
        
        var endpoint = StringUtils.format(ENDPOINTS.INSAPI_CREATE_POLICIES,'vlocity_ins');
        var payload = {
		    Quotes: {
		        Ids: quoteIdsPayload
		    }
		}
        
        // TODO: need to fetch vlocity_ins from custom preference
        var requestObject = {
            httpMethod: 'POST',
            endpoint: endpoint,
            payload: payload
        }

        var result = callService(requestObject);
        var parsedResponse = JSON.parse(result.object.responseObj);
        
        // If response includes completed policy details on first call (it almost never does), return it
        if (parsedResponse && parsedResponse.policyDetails) {
            return result;
        }
        
        // If response comes back with "InProgress" on first call (it almost always does), poll for completion status
        var maxCallsAllowed = 15;
        var callsMade = 1;
        while (parsedResponse && parsedResponse.vlcIPData && parsedResponse.vlcStatus === 'InProgress') {
            requestObject = {
                httpMethod: 'POST',
                endpoint: endpoint,
                headers: {
                    vlcIPData: parsedResponse.vlcIPData,
                    q: parsedResponse.vlcIPData
                },
                payload: {}
            }
            
            result = callService(requestObject);
            
            parsedResponse = JSON.parse(result.object.responseObj);

            if ( (parsedResponse && parsedResponse.policyDetails) || ++callsMade >= maxCallsAllowed ) {
                return result;
            }
        }
    }
};

module.exports.Exception = VlocityServiceException;
