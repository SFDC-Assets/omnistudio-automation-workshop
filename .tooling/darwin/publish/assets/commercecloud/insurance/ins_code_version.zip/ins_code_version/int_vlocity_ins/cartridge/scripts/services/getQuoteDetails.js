/* eslint-disable valid-jsdoc */
'use strict';

/**
 * @module services/auth
 */

/**
 * Vlocity AUTH service definition
 */

/**
 * @type {dw.system.Logger}
 */
var Logger = require('dw/system/Logger');
/**
 * @type {dw.system.Site}
 */
var Site = require('dw/system/Site');

/**
 * @type {module:util/helpers}
 */
var helpers = require('../util/helpers');

/**
 * @type {dw.system.Logger}
 */
var LOGGER = Logger.getLogger('int_vlocity_ins', 'vlocity.rest');

/**
 * Attempt to set to site-specific credential to the given service. If it fails, fallback to the original ID
 *
 * @param  {dw.svc.HTTPService} svc
 * @param  {String} id
 *
 * @return {String}
 */
function setCredentialID(svc, id) {
    var siteID = Site.getCurrent().getID();
    var possibleIDs = [
        id + '-' + siteID,
        id
    ];

    possibleIDs.some(function (credentialID) {
        try {
            svc.setCredentialID(credentialID);
            return true;
        } catch (e) {
            return false;
        }
    });
}

var serviceDefinition = {
    /**
     * Create request for Vlocity Insurance getQuoteDetails integration procedure
     *
     * @param {dw.svc.HTTPService} svc
     *
     * @throws {Error} Throws error when valid Bearer token is not available
     */
    createRequest: function (svc, quoteId) {
        setCredentialID(svc, svc.getCredentialID() || svc.getConfiguration().getID());

        LOGGER.debug('Vlocity Connector credential ID: {0}', svc.getCredentialID());

	    var AuthToken = require('*/cartridge/scripts/models/authToken');		
   	 	var authToken = new AuthToken();
    	var token = authToken.getValidToken();

        if (empty(token.access_token)) {
            throw new Error('Could not obtain valid access token');
        }

        svc.setAuthentication('NONE');
        svc.addHeader('Authorization', 'Bearer ' + token.access_token);
        svc.setRequestMethod('GET');
        svc.addParam('quoteId', quoteId);
    },

    /**
     * @param {dw.svc.HTTPService} svc
     * @param {dw.net.HTTPClient} client
     *
     * @returns {Object}
     */
    parseResponse: function (svc, client) {
        var responseObj;

        try {
            responseObj = helpers.expandJSON(client.text, {});
        } catch (e) {
            responseObj = client.text;
            LOGGER.error('Unable to parse JSON response text: {0}', responseObj);
        }

        return responseObj;
    },

    mockCall: function () {
        var obj = {
            "productConfigurationDetail": {
                "records": [
                    {
                        "childProducts": {
                            "records": [
                                {
                                    "attributeCategories": {
                                        "records": [
                                            {
                                                "productAttributes": {
                                                    "records": [
                                                        {
                                                            "userValues": null,
                                                            "values": [
                                                                {
                                                                    "disabled": false,
                                                                    "readonly": false
                                                                }
                                                            ],
                                                            "isNotTranslatable": false,
                                                            "cloneable": true,
                                                            "hidden": false,
                                                            "hasRules": false,
                                                            "displaySequence": 0,
                                                            "label": "Suffix",
                                                            "attributeId": "a0S4P000004VoezUAC",
                                                            "filterable": true,
                                                            "disabled": false,
                                                            "readonly": false,
                                                            "required": false,
                                                            "multiselect": false,
                                                            "inputType": "text",
                                                            "dataType": "text",
                                                            "code": "adSuffix"
                                                        },
                                                        {
                                                            "userValues": "David",
                                                            "values": [
                                                                {
                                                                    "disabled": false,
                                                                    "readonly": false
                                                                }
                                                            ],
                                                            "isNotTranslatable": false,
                                                            "cloneable": true,
                                                            "hidden": false,
                                                            "hasRules": false,
                                                            "displaySequence": 1,
                                                            "label": "First Name",
                                                            "attributeId": "a0S4P000004VoemUAC",
                                                            "filterable": true,
                                                            "disabled": false,
                                                            "readonly": false,
                                                            "required": false,
                                                            "multiselect": false,
                                                            "inputType": "text",
                                                            "dataType": "text",
                                                            "code": "adFirstName"
                                                        },
                                                        {
                                                            "userValues": "M",
                                                            "values": [
                                                                {
                                                                    "disabled": false,
                                                                    "readonly": false
                                                                }
                                                            ],
                                                            "isNotTranslatable": false,
                                                            "cloneable": true,
                                                            "hidden": false,
                                                            "hasRules": false,
                                                            "displaySequence": 2,
                                                            "label": "Middle Name",
                                                            "attributeId": "a0S4P000004VoevUAC",
                                                            "filterable": true,
                                                            "disabled": false,
                                                            "readonly": false,
                                                            "required": false,
                                                            "multiselect": false,
                                                            "inputType": "text",
                                                            "dataType": "text",
                                                            "code": "adMiddle"
                                                        },
                                                        {
                                                            "userValues": "Flan",
                                                            "values": [
                                                                {
                                                                    "disabled": false,
                                                                    "readonly": false
                                                                }
                                                            ],
                                                            "isNotTranslatable": false,
                                                            "cloneable": true,
                                                            "hidden": false,
                                                            "hasRules": false,
                                                            "displaySequence": 3,
                                                            "label": "Last Name",
                                                            "attributeId": "a0S4P000004VoeqUAC",
                                                            "filterable": true,
                                                            "disabled": false,
                                                            "readonly": false,
                                                            "required": false,
                                                            "multiselect": false,
                                                            "inputType": "text",
                                                            "dataType": "text",
                                                            "code": "adLastName"
                                                        },
                                                        {
                                                            "userValues": "1986-02-14T08:00:00.000Z",
                                                            "values": [
                                                                {
                                                                    "disabled": false,
                                                                    "readonly": false
                                                                }
                                                            ],
                                                            "isNotTranslatable": false,
                                                            "cloneable": true,
                                                            "hidden": false,
                                                            "hasRules": false,
                                                            "displaySequence": 4,
                                                            "label": "Birthdate",
                                                            "attributeId": "a0S4P000004VoelUAC",
                                                            "filterable": true,
                                                            "disabled": false,
                                                            "readonly": false,
                                                            "required": false,
                                                            "multiselect": false,
                                                            "inputType": "date",
                                                            "dataType": "date",
                                                            "code": "adBirthdate"
                                                        },
                                                        {
                                                            "userValues": 16,
                                                            "values": [
                                                                {
                                                                    "disabled": false,
                                                                    "readonly": false
                                                                }
                                                            ],
                                                            "isNotTranslatable": false,
                                                            "cloneable": true,
                                                            "hidden": false,
                                                            "hasRules": false,
                                                            "displaySequence": 5,
                                                            "label": "Age First Licensed",
                                                            "attributeId": "a0S4P000004VoekUAC",
                                                            "filterable": true,
                                                            "disabled": false,
                                                            "readonly": false,
                                                            "required": false,
                                                            "multiselect": false,
                                                            "inputType": "number",
                                                            "dataType": "number",
                                                            "code": "adAgeLicensed"
                                                        },
                                                        {
                                                            "userValues": "M",
                                                            "values": [
                                                                {
                                                                    "value": "M",
                                                                    "disabled": false,
                                                                    "readonly": false,
                                                                    "label": "Male",
                                                                    "id": "2"
                                                                },
                                                                {
                                                                    "value": "F",
                                                                    "disabled": false,
                                                                    "readonly": false,
                                                                    "label": "Female",
                                                                    "id": "1"
                                                                }
                                                            ],
                                                            "isNotTranslatable": false,
                                                            "cloneable": true,
                                                            "hidden": false,
                                                            "hasRules": false,
                                                            "displaySequence": 6,
                                                            "label": "Gender",
                                                            "attributeId": "a0S4P000004VoeoUAC",
                                                            "filterable": true,
                                                            "disabled": false,
                                                            "readonly": false,
                                                            "required": false,
                                                            "multiselect": false,
                                                            "inputType": "dropdown",
                                                            "dataType": "text",
                                                            "code": "adGender"
                                                        },
                                                        {
                                                            "userValues": "M",
                                                            "values": [
                                                                {
                                                                    "value": "M",
                                                                    "disabled": false,
                                                                    "readonly": false,
                                                                    "label": "Married",
                                                                    "id": "1"
                                                                },
                                                                {
                                                                    "value": "S",
                                                                    "disabled": false,
                                                                    "readonly": false,
                                                                    "label": "Single",
                                                                    "id": "0"
                                                                }
                                                            ],
                                                            "isNotTranslatable": false,
                                                            "cloneable": true,
                                                            "hidden": false,
                                                            "hasRules": false,
                                                            "displaySequence": 7,
                                                            "label": "Marital Status",
                                                            "attributeId": "a0S4P000004VoeuUAC",
                                                            "filterable": true,
                                                            "disabled": false,
                                                            "readonly": false,
                                                            "required": false,
                                                            "multiselect": false,
                                                            "inputType": "dropdown",
                                                            "dataType": "text",
                                                            "code": "adMaritalStatus"
                                                        },
                                                        {
                                                            "userValues": null,
                                                            "values": [
                                                                {
                                                                    "disabled": false,
                                                                    "readonly": false
                                                                }
                                                            ],
                                                            "isNotTranslatable": false,
                                                            "cloneable": true,
                                                            "hidden": false,
                                                            "hasRules": false,
                                                            "displaySequence": 8,
                                                            "label": "Driver Accident Points",
                                                            "attributeId": "a0S4P000004VoeiUAC",
                                                            "filterable": true,
                                                            "disabled": false,
                                                            "readonly": false,
                                                            "required": false,
                                                            "multiselect": false,
                                                            "inputType": "number",
                                                            "dataType": "number",
                                                            "code": "adAccidentPoints"
                                                        },
                                                        {
                                                            "userValues": null,
                                                            "values": [
                                                                {
                                                                    "disabled": false,
                                                                    "readonly": false
                                                                }
                                                            ],
                                                            "isNotTranslatable": false,
                                                            "cloneable": true,
                                                            "hidden": false,
                                                            "hasRules": false,
                                                            "displaySequence": 9,
                                                            "label": "Driver MVR Points",
                                                            "attributeId": "a0S4P000004VoetUAC",
                                                            "filterable": true,
                                                            "disabled": false,
                                                            "readonly": false,
                                                            "required": false,
                                                            "multiselect": false,
                                                            "inputType": "number",
                                                            "dataType": "number",
                                                            "code": "adMVRPoints"
                                                        },
                                                        {
                                                            "userValues": null,
                                                            "values": [
                                                                {
                                                                    "disabled": false,
                                                                    "readonly": false
                                                                }
                                                            ],
                                                            "isNotTranslatable": false,
                                                            "cloneable": true,
                                                            "hidden": true,
                                                            "hasRules": false,
                                                            "displaySequence": 10,
                                                            "label": "Driver Annual Mileage",
                                                            "attributeId": "a0S4P000004VoewUAC",
                                                            "filterable": true,
                                                            "disabled": false,
                                                            "readonly": false,
                                                            "required": false,
                                                            "multiselect": false,
                                                            "inputType": "number",
                                                            "dataType": "number",
                                                            "code": "adMileage"
                                                        },
                                                        {
                                                            "userValues": null,
                                                            "values": [
                                                                {
                                                                    "disabled": false,
                                                                    "readonly": false
                                                                }
                                                            ],
                                                            "isNotTranslatable": false,
                                                            "cloneable": true,
                                                            "hidden": true,
                                                            "hasRules": false,
                                                            "displaySequence": 11,
                                                            "label": "Good Student",
                                                            "attributeId": "a0S4P000004VoepUAC",
                                                            "filterable": true,
                                                            "disabled": false,
                                                            "readonly": false,
                                                            "required": false,
                                                            "multiselect": false,
                                                            "inputType": "text",
                                                            "dataType": "text",
                                                            "code": "adGoodStudent"
                                                        },
                                                        {
                                                            "userValues": null,
                                                            "values": [
                                                                {
                                                                    "disabled": false,
                                                                    "readonly": false
                                                                }
                                                            ],
                                                            "isNotTranslatable": false,
                                                            "cloneable": true,
                                                            "hidden": true,
                                                            "hasRules": false,
                                                            "displaySequence": 12,
                                                            "label": "GPA",
                                                            "attributeId": "a0S4P000004VoenUAC",
                                                            "filterable": true,
                                                            "disabled": false,
                                                            "readonly": false,
                                                            "required": false,
                                                            "multiselect": false,
                                                            "inputType": "number",
                                                            "dataType": "number",
                                                            "code": "adGPA"
                                                        },
                                                        {
                                                            "userValues": null,
                                                            "values": [
                                                                {
                                                                    "disabled": false,
                                                                    "readonly": false
                                                                }
                                                            ],
                                                            "isNotTranslatable": false,
                                                            "cloneable": true,
                                                            "hidden": true,
                                                            "hasRules": false,
                                                            "displaySequence": 13,
                                                            "label": "License Number",
                                                            "attributeId": "a0S4P000004VoerUAC",
                                                            "filterable": true,
                                                            "disabled": false,
                                                            "readonly": false,
                                                            "required": false,
                                                            "multiselect": false,
                                                            "inputType": "text",
                                                            "dataType": "text",
                                                            "code": "adLicenseNum"
                                                        },
                                                        {
                                                            "userValues": null,
                                                            "values": [
                                                                {
                                                                    "disabled": false,
                                                                    "readonly": false
                                                                }
                                                            ],
                                                            "isNotTranslatable": false,
                                                            "cloneable": true,
                                                            "hidden": true,
                                                            "hasRules": false,
                                                            "displaySequence": 14,
                                                            "label": "Name",
                                                            "attributeId": "a0S4P000004VoexUAC",
                                                            "filterable": true,
                                                            "disabled": false,
                                                            "readonly": false,
                                                            "required": false,
                                                            "multiselect": false,
                                                            "inputType": "text",
                                                            "dataType": "text",
                                                            "code": "adName"
                                                        },
                                                        {
                                                            "userValues": null,
                                                            "values": [
                                                                {
                                                                    "disabled": false,
                                                                    "readonly": false
                                                                }
                                                            ],
                                                            "isNotTranslatable": false,
                                                            "cloneable": true,
                                                            "hidden": true,
                                                            "hasRules": false,
                                                            "displaySequence": 15,
                                                            "label": "Primary Use",
                                                            "attributeId": "a0S4P000004Vof1UAC",
                                                            "filterable": true,
                                                            "disabled": false,
                                                            "readonly": false,
                                                            "required": false,
                                                            "multiselect": false,
                                                            "inputType": "text",
                                                            "dataType": "text",
                                                            "code": "adUse"
                                                        },
                                                        {
                                                            "userValues": null,
                                                            "values": [
                                                                {
                                                                    "disabled": false,
                                                                    "readonly": false
                                                                }
                                                            ],
                                                            "isNotTranslatable": false,
                                                            "cloneable": true,
                                                            "hidden": true,
                                                            "hasRules": false,
                                                            "displaySequence": 16,
                                                            "label": "Safe Driver",
                                                            "attributeId": "a0S4P000004VoeyUAC",
                                                            "filterable": true,
                                                            "disabled": false,
                                                            "readonly": false,
                                                            "required": false,
                                                            "multiselect": false,
                                                            "inputType": "text",
                                                            "dataType": "text",
                                                            "code": "adSafeDriver"
                                                        },
                                                        {
                                                            "userValues": null,
                                                            "values": [
                                                                {
                                                                    "disabled": false,
                                                                    "readonly": false
                                                                }
                                                            ],
                                                            "isNotTranslatable": false,
                                                            "cloneable": true,
                                                            "hidden": true,
                                                            "hasRules": false,
                                                            "displaySequence": 17,
                                                            "label": "State Licensed",
                                                            "attributeId": "a0S4P000004VoesUAC",
                                                            "filterable": true,
                                                            "disabled": false,
                                                            "readonly": false,
                                                            "required": false,
                                                            "multiselect": false,
                                                            "inputType": "text",
                                                            "dataType": "text",
                                                            "code": "adLicenseState"
                                                        },
                                                        {
                                                            "userValues": null,
                                                            "values": [
                                                                {
                                                                    "disabled": false,
                                                                    "readonly": false
                                                                }
                                                            ],
                                                            "isNotTranslatable": false,
                                                            "cloneable": true,
                                                            "hidden": true,
                                                            "hasRules": false,
                                                            "displaySequence": 18,
                                                            "label": "Total Points",
                                                            "attributeId": "a0S4P000004Vof0UAC",
                                                            "filterable": true,
                                                            "disabled": false,
                                                            "readonly": false,
                                                            "required": false,
                                                            "multiselect": false,
                                                            "inputType": "number",
                                                            "dataType": "number",
                                                            "code": "adTotalPoints"
                                                        },
                                                        {
                                                            "userValues": null,
                                                            "values": [
                                                                {
                                                                    "disabled": false,
                                                                    "readonly": false
                                                                }
                                                            ],
                                                            "isNotTranslatable": false,
                                                            "cloneable": true,
                                                            "hidden": true,
                                                            "hasRules": false,
                                                            "displaySequence": 19,
                                                            "label": "Years Experience",
                                                            "attributeId": "a0S4P000004Vof2UAC",
                                                            "filterable": true,
                                                            "disabled": false,
                                                            "readonly": false,
                                                            "required": false,
                                                            "multiselect": false,
                                                            "inputType": "number",
                                                            "dataType": "number",
                                                            "code": "adYrsExp"
                                                        },
                                                        {
                                                            "userValues": 34,
                                                            "values": [
                                                                {
                                                                    "disabled": false,
                                                                    "readonly": false
                                                                }
                                                            ],
                                                            "isNotTranslatable": false,
                                                            "cloneable": true,
                                                            "hidden": true,
                                                            "hasRules": false,
                                                            "displaySequence": 20,
                                                            "label": "Age",
                                                            "attributeId": "a0S4P000004VoejUAC",
                                                            "filterable": true,
                                                            "disabled": false,
                                                            "readonly": false,
                                                            "required": false,
                                                            "multiselect": false,
                                                            "inputType": "number",
                                                            "dataType": "number",
                                                            "code": "adAge"
                                                        }
                                                    ],
                                                    "totalSize": 21
                                                },
                                                "id": "a0R4P00000J2MJxUAN",
                                                "Name": "Auto Driver",
                                                "Code__c": "autoDriver",
                                                "displaySequence": 220
                                            }
                                        ],
                                        "totalSize": 1
                                    },
                                    "hasCoverages": false,
                                    "pciId": "a484x000000Zh9rAAC",
                                    "lineRecordType": "InsuredPartySpec",
                                    "isPrimary": true,
                                    "instanceKey": "David Flan",
                                    "Name": "David Flan",
                                    "quoteLineItemId": "0QL4x000000lAXiGAM",
                                    "ProductCode": "autoDriver",
                                    "hasAttributes": true,
                                    "needCustomProcess": false,
                                    "productName": "Auto Driver",
                                    "maxCount": 1,
                                    "minCount": 1,
                                    "vlocity_ins__NeedReprice__c": false,
                                    "needReprice": false,
                                    "vlocity_ins__ProductChildItemSequence__c": 0,
                                    "vlocity_ins__TotalAmount__c": 0,
                                    "vlocity_ins__ProductName__c": "Auto Driver",
                                    "LastModifiedDate": "2021-02-03T16:11:02.000+0000",
                                    "TotalPrice": 0,
                                    "vlocity_ins__Type__c": "Auto",
                                    "vlocity_ins__RecordTypeName__c": "InsuredPartySpec",
                                    "UnitPrice": 0,
                                    "Price": 0,
                                    "QuoteId": "0Q04x000000l6zPCAQ",
                                    "vlocity_ins__AttributeSelectedValues__c": "{\"isParent\":false,\"adMaritalStatus\":\"M\",\"adMiddle\":\"M\",\"adLastName\":\"Flan\",\"adGender\":\"M\",\"adFirstName\":\"David\",\"adAgeLicensed\":16,\"adBirthdate\":\"1986-02-14T08:00:00.000Z\",\"adAge\":34}",
                                    "CreatedDate": "2021-02-03T16:11:02.000+0000",
                                    "LineNumber": "00004345",
                                    "vlocity_ins__SubParentItemId__c": "0QL4x000000lAXhGAM",
                                    "vlocity_ins__ParentItemId__c": "0QL4x000000lAXhGAM",
                                    "vlocity_ins__ParentItemId2__c": "0QL4x000000lAXhGAM",
                                    "vlocity_ins__ItemName__c": "David Flan",
                                    "Product2Id": "01t4x000001y3ZvAAI",
                                    "productId": "01t4x000001y3ZvAAI",
                                    "Id": "0QL4x000000lAXiGAM",
                                    "currencyCode": "USD",
                                    "currencySymbol": "$",
                                    "displaySequence": 0,
                                    "actions": {
                                        "deleteChildLine": {
                                            "client": {
                                                "params": {}
                                            },
                                            "remote": {
                                                "params": {
                                                    "methodName": "deleteChildLine",
                                                    "quoteLineId": "0QL4x000000lAXiGAM",
                                                    "itemRecordType": "InsuredPartySpec",
                                                    "minCount": 1
                                                }
                                            },
                                            "rest": {
                                                "link": null,
                                                "method": null,
                                                "params": {}
                                            }
                                        },
                                        "updateChildLine": {
                                            "client": {
                                                "params": {}
                                            },
                                            "remote": {
                                                "params": {
                                                    "methodName": "updateChildLine",
                                                    "quoteLineId": "0QL4x000000lAXiGAM",
                                                    "reprice": true,
                                                    "quoteId": "0Q04x000000l6zPCAQ"
                                                }
                                            },
                                            "rest": {
                                                "link": null,
                                                "method": null,
                                                "params": {}
                                            }
                                        }
                                    }
                                },
                                {
                                    "childProducts": {
                                        "records": [
                                            {
                                                "attributeCategories": {
                                                    "records": [
                                                        {
                                                            "productAttributes": {
                                                                "records": [
                                                                    {
                                                                        "valueDecoder": "autoBILimClmCov/autoBILimClm/autoPDLimClm",
                                                                        "userValues": "25000/50000/25000",
                                                                        "values": [
                                                                            {
                                                                                "value": "15000/30000/10000",
                                                                                "disabled": false,
                                                                                "readonly": false,
                                                                                "label": "$15000/$30000/$10000",
                                                                                "id": "0"
                                                                            },
                                                                            {
                                                                                "value": "15000/30000/5000",
                                                                                "disabled": false,
                                                                                "readonly": false,
                                                                                "label": "$15000/$30000/$5000",
                                                                                "id": "1"
                                                                            },
                                                                            {
                                                                                "value": "25000/50000/25000",
                                                                                "disabled": false,
                                                                                "readonly": false,
                                                                                "label": "$25000/$50000/$25000",
                                                                                "id": "2"
                                                                            },
                                                                            {
                                                                                "value": "25000/50000/50000",
                                                                                "disabled": false,
                                                                                "readonly": false,
                                                                                "label": "$25000/$50000/$50000",
                                                                                "id": "3"
                                                                            },
                                                                            {
                                                                                "value": "50000/100000/50000",
                                                                                "disabled": false,
                                                                                "readonly": false,
                                                                                "label": "$50000/$100000/$50000",
                                                                                "id": "4"
                                                                            },
                                                                            {
                                                                                "value": "50000/100000/100000",
                                                                                "disabled": false,
                                                                                "readonly": false,
                                                                                "label": "$50000/$100000/$100000",
                                                                                "id": "5"
                                                                            },
                                                                            {
                                                                                "value": "100000/300000/25000",
                                                                                "disabled": false,
                                                                                "readonly": false,
                                                                                "label": "$100000/$300000/$25000",
                                                                                "id": "6"
                                                                            },
                                                                            {
                                                                                "value": "100000/300000/50000",
                                                                                "disabled": false,
                                                                                "readonly": false,
                                                                                "label": "$100000/$300000/$50000",
                                                                                "id": "7"
                                                                            },
                                                                            {
                                                                                "value": "100000/300000/100000",
                                                                                "disabled": false,
                                                                                "readonly": false,
                                                                                "label": "$100000/$300000/$100000",
                                                                                "id": "8"
                                                                            },
                                                                            {
                                                                                "value": "250000/500000/100000",
                                                                                "disabled": false,
                                                                                "readonly": false,
                                                                                "label": "$250000/$500000/$100000",
                                                                                "id": "9"
                                                                            },
                                                                            {
                                                                                "value": "500000/500000/100000",
                                                                                "disabled": false,
                                                                                "readonly": false,
                                                                                "label": "$500000/$500000/100000",
                                                                                "id": "10"
                                                                            },
                                                                            {
                                                                                "value": "500000/500000/500000",
                                                                                "disabled": false,
                                                                                "readonly": false,
                                                                                "label": "$500000/$500000/$500000",
                                                                                "id": "11"
                                                                            },
                                                                            {
                                                                                "value": "500000/1000000/500000",
                                                                                "disabled": false,
                                                                                "readonly": false,
                                                                                "label": "$500000/$1000000/$500000",
                                                                                "id": "12"
                                                                            }
                                                                        ],
                                                                        "isNotTranslatable": false,
                                                                        "cloneable": true,
                                                                        "hidden": false,
                                                                        "hasRules": true,
                                                                        "displaySequence": 0,
                                                                        "label": "BIPD Limit",
                                                                        "attributeId": "a0S4P000009YMK7UAO",
                                                                        "filterable": true,
                                                                        "disabled": false,
                                                                        "readonly": false,
                                                                        "required": false,
                                                                        "multiselect": false,
                                                                        "inputType": "dropdown",
                                                                        "dataType": "text",
                                                                        "code": "autoBIPDLimit"
                                                                    }
                                                                ],
                                                                "totalSize": 1
                                                            },
                                                            "id": "a0R4P00000JWzkZUAT",
                                                            "Name": "Auto Terms",
                                                            "Code__c": "autoTerms",
                                                            "displaySequence": 230
                                                        }
                                                    ],
                                                    "totalSize": 1
                                                },
                                                "pciId": "a484x000000ZhDPAA0",
                                                "isSelected": true,
                                                "ProductCode": "autoBIPD",
                                                "Name": "Bodily Injury & Property Damage",
                                                "productName": "Bodily Injury & Property Damage",
                                                "isOptional": false,
                                                "lineRecordType": "CoverageSpec",
                                                "instanceKey": "2020 Mazda CX-30_autoBIPD",
                                                "quoteLineItemId": "0QL4x000000lAXuGAM",
                                                "vlocity_ins__NeedReprice__c": false,
                                                "needReprice": false,
                                                "vlocity_ins__ProductChildItemSequence__c": 0,
                                                "vlocity_ins__TotalAmount__c": 19.34,
                                                "vlocity_ins__ProductName__c": "Bodily Injury & Property Damage",
                                                "vlocity_ins__PricingSource__c": "premiumBIPD",
                                                "LastModifiedDate": "2021-02-03T16:11:02.000+0000",
                                                "TotalPrice": 19.34,
                                                "vlocity_ins__Type__c": "Auto",
                                                "vlocity_ins__RecordTypeName__c": "CoverageSpec",
                                                "UnitPrice": 19.34,
                                                "Price": 19.34,
                                                "QuoteId": "0Q04x000000l6zPCAQ",
                                                "vlocity_ins__AttributeSelectedValues__c": "{\"autoBIPDLimit.autoPDLimClm\":25000,\"autoBIPDLimit.autoBILimClm\":50000,\"autoBIPDLimit.autoBILimClmCov\":25000,\"autoBIPDLimit\":\"25000/50000/25000\"}",
                                                "CreatedDate": "2021-02-03T16:11:02.000+0000",
                                                "LineNumber": "00004357",
                                                "vlocity_ins__SubParentItemId__c": "0QL4x000000lAXkGAM",
                                                "vlocity_ins__ParentItemId__c": "0QL4x000000lAXhGAM",
                                                "vlocity_ins__ParentItemId2__c": "0QL4x000000lAXhGAM",
                                                "vlocity_ins__ItemName__c": "2020 Mazda CX-30_autoBIPD",
                                                "Product2Id": "01t4x000001y3ZiAAI",
                                                "productId": "01t4x000001y3ZiAAI",
                                                "Id": "0QL4x000000lAXuGAM",
                                                "vlocity_ins__ProductChildItemId__c": "a484x000000ZhDPAA0",
                                                "currencyCode": "USD",
                                                "currencySymbol": "$",
                                                "displaySequence": 0,
                                                "actions": {
                                                    "updateChildLine": {
                                                        "client": {
                                                            "params": {}
                                                        },
                                                        "remote": {
                                                            "params": {
                                                                "methodName": "updateChildLine",
                                                                "quoteLineId": "0QL4x000000lAXuGAM",
                                                                "reprice": true,
                                                                "quoteId": "0Q04x000000l6zPCAQ"
                                                            }
                                                        },
                                                        "rest": {
                                                            "link": null,
                                                            "method": null,
                                                            "params": {}
                                                        }
                                                    }
                                                }
                                            },
                                            {
                                                "attributeCategories": {
                                                    "records": [
                                                        {
                                                            "productAttributes": {
                                                                "records": [
                                                                    {
                                                                        "userValues": 500,
                                                                        "values": [
                                                                            {
                                                                                "value": 250,
                                                                                "disabled": false,
                                                                                "readonly": false,
                                                                                "label": "$250",
                                                                                "id": "0"
                                                                            },
                                                                            {
                                                                                "value": 500,
                                                                                "disabled": false,
                                                                                "readonly": false,
                                                                                "label": "$500",
                                                                                "id": "1"
                                                                            },
                                                                            {
                                                                                "value": 750,
                                                                                "disabled": false,
                                                                                "readonly": false,
                                                                                "label": "$750",
                                                                                "id": "2"
                                                                            },
                                                                            {
                                                                                "value": 1000,
                                                                                "disabled": false,
                                                                                "readonly": false,
                                                                                "label": "$1000",
                                                                                "id": "3"
                                                                            },
                                                                            {
                                                                                "value": 1500,
                                                                                "disabled": false,
                                                                                "readonly": false,
                                                                                "label": "$1500",
                                                                                "id": "4"
                                                                            },
                                                                            {
                                                                                "value": 2500,
                                                                                "disabled": false,
                                                                                "readonly": false,
                                                                                "label": "$2500",
                                                                                "id": "5"
                                                                            }
                                                                        ],
                                                                        "isNotTranslatable": false,
                                                                        "cloneable": true,
                                                                        "hidden": false,
                                                                        "hasRules": false,
                                                                        "displaySequence": 0,
                                                                        "label": "Collision Deductible",
                                                                        "attributeId": "a0S4P000009YMK8UAO",
                                                                        "filterable": true,
                                                                        "disabled": false,
                                                                        "readonly": false,
                                                                        "required": false,
                                                                        "multiselect": false,
                                                                        "inputType": "dropdown",
                                                                        "dataType": "currency",
                                                                        "code": "autoCollDedClmCov"
                                                                    }
                                                                ],
                                                                "totalSize": 1
                                                            },
                                                            "id": "a0R4P00000JWzkZUAT",
                                                            "Name": "Auto Terms",
                                                            "Code__c": "autoTerms",
                                                            "displaySequence": 230
                                                        }
                                                    ],
                                                    "totalSize": 1
                                                },
                                                "pciId": "a484x000000Zh9pAAC",
                                                "isSelected": true,
                                                "ProductCode": "autoCollision",
                                                "Name": "Collision",
                                                "productName": "Collision",
                                                "isOptional": false,
                                                "lineRecordType": "CoverageSpec",
                                                "instanceKey": "2020 Mazda CX-30_autoCollision",
                                                "quoteLineItemId": "0QL4x000000lAXtGAM",
                                                "vlocity_ins__NeedReprice__c": false,
                                                "needReprice": false,
                                                "vlocity_ins__ProductChildItemSequence__c": 1,
                                                "vlocity_ins__TotalAmount__c": 754.5,
                                                "vlocity_ins__ProductName__c": "Collision",
                                                "vlocity_ins__PricingSource__c": "premiumCOLL",
                                                "LastModifiedDate": "2021-02-03T16:11:02.000+0000",
                                                "TotalPrice": 754.5,
                                                "vlocity_ins__Type__c": "Auto",
                                                "vlocity_ins__RecordTypeName__c": "CoverageSpec",
                                                "UnitPrice": 754.5,
                                                "Price": 754.5,
                                                "QuoteId": "0Q04x000000l6zPCAQ",
                                                "vlocity_ins__AttributeSelectedValues__c": "{\"autoCollDedClmCov\":500}",
                                                "CreatedDate": "2021-02-03T16:11:02.000+0000",
                                                "LineNumber": "00004356",
                                                "vlocity_ins__SubParentItemId__c": "0QL4x000000lAXkGAM",
                                                "vlocity_ins__ParentItemId__c": "0QL4x000000lAXhGAM",
                                                "vlocity_ins__ParentItemId2__c": "0QL4x000000lAXhGAM",
                                                "vlocity_ins__ItemName__c": "2020 Mazda CX-30_autoCollision",
                                                "Product2Id": "01t4x000001y3aDAAQ",
                                                "productId": "01t4x000001y3aDAAQ",
                                                "Id": "0QL4x000000lAXtGAM",
                                                "vlocity_ins__ProductChildItemId__c": "a484x000000Zh9pAAC",
                                                "currencyCode": "USD",
                                                "currencySymbol": "$",
                                                "displaySequence": 1,
                                                "actions": {
                                                    "updateChildLine": {
                                                        "client": {
                                                            "params": {}
                                                        },
                                                        "remote": {
                                                            "params": {
                                                                "methodName": "updateChildLine",
                                                                "quoteLineId": "0QL4x000000lAXtGAM",
                                                                "reprice": true,
                                                                "quoteId": "0Q04x000000l6zPCAQ"
                                                            }
                                                        },
                                                        "rest": {
                                                            "link": null,
                                                            "method": null,
                                                            "params": {}
                                                        }
                                                    }
                                                }
                                            },
                                            {
                                                "attributeCategories": {
                                                    "records": [
                                                        {
                                                            "productAttributes": {
                                                                "records": [
                                                                    {
                                                                        "userValues": 100,
                                                                        "values": [
                                                                            {
                                                                                "value": 100,
                                                                                "disabled": false,
                                                                                "readonly": false,
                                                                                "label": "$100",
                                                                                "id": "0"
                                                                            },
                                                                            {
                                                                                "value": 250,
                                                                                "disabled": false,
                                                                                "readonly": false,
                                                                                "label": "$250",
                                                                                "id": "1"
                                                                            },
                                                                            {
                                                                                "value": 500,
                                                                                "disabled": false,
                                                                                "readonly": false,
                                                                                "label": "$500",
                                                                                "id": "2"
                                                                            },
                                                                            {
                                                                                "value": 750,
                                                                                "disabled": false,
                                                                                "readonly": false,
                                                                                "label": "$750",
                                                                                "id": "3"
                                                                            },
                                                                            {
                                                                                "value": 1000,
                                                                                "disabled": false,
                                                                                "readonly": false,
                                                                                "label": "$1000",
                                                                                "id": "4"
                                                                            },
                                                                            {
                                                                                "value": 1500,
                                                                                "disabled": false,
                                                                                "readonly": false,
                                                                                "label": "$1500",
                                                                                "id": "5"
                                                                            },
                                                                            {
                                                                                "value": 2500,
                                                                                "disabled": false,
                                                                                "readonly": false,
                                                                                "label": "$2500",
                                                                                "id": "6"
                                                                            }
                                                                        ],
                                                                        "isNotTranslatable": false,
                                                                        "cloneable": true,
                                                                        "hidden": false,
                                                                        "hasRules": false,
                                                                        "displaySequence": 0,
                                                                        "label": "Comp Deductible",
                                                                        "attributeId": "a0S4P000009YMK9UAO",
                                                                        "filterable": true,
                                                                        "disabled": false,
                                                                        "readonly": false,
                                                                        "required": false,
                                                                        "multiselect": false,
                                                                        "inputType": "dropdown",
                                                                        "dataType": "currency",
                                                                        "code": "autoCompDedClmCov"
                                                                    }
                                                                ],
                                                                "totalSize": 1
                                                            },
                                                            "id": "a0R4P00000JWzkZUAT",
                                                            "Name": "Auto Terms",
                                                            "Code__c": "autoTerms",
                                                            "displaySequence": 230
                                                        }
                                                    ],
                                                    "totalSize": 1
                                                },
                                                "pciId": "a484x000000Zh9nAAC",
                                                "isSelected": true,
                                                "ProductCode": "autoComp",
                                                "Name": "Comprehensive",
                                                "productName": "Comprehensive",
                                                "isOptional": false,
                                                "lineRecordType": "CoverageSpec",
                                                "instanceKey": "2020 Mazda CX-30_autoComp",
                                                "quoteLineItemId": "0QL4x000000lAXsGAM",
                                                "vlocity_ins__NeedReprice__c": false,
                                                "needReprice": false,
                                                "vlocity_ins__ProductChildItemSequence__c": 2,
                                                "vlocity_ins__TotalAmount__c": 248.69,
                                                "vlocity_ins__ProductName__c": "Comprehensive",
                                                "vlocity_ins__PricingSource__c": "premiumCCD",
                                                "LastModifiedDate": "2021-02-03T16:11:02.000+0000",
                                                "TotalPrice": 248.69,
                                                "vlocity_ins__Type__c": "Auto",
                                                "vlocity_ins__RecordTypeName__c": "CoverageSpec",
                                                "UnitPrice": 248.69,
                                                "Price": 248.69,
                                                "QuoteId": "0Q04x000000l6zPCAQ",
                                                "vlocity_ins__AttributeSelectedValues__c": "{\"autoCompDedClmCov\":100}",
                                                "CreatedDate": "2021-02-03T16:11:02.000+0000",
                                                "LineNumber": "00004355",
                                                "vlocity_ins__SubParentItemId__c": "0QL4x000000lAXkGAM",
                                                "vlocity_ins__ParentItemId__c": "0QL4x000000lAXhGAM",
                                                "vlocity_ins__ParentItemId2__c": "0QL4x000000lAXhGAM",
                                                "vlocity_ins__ItemName__c": "2020 Mazda CX-30_autoComp",
                                                "Product2Id": "01t4x000001y3a1AAA",
                                                "productId": "01t4x000001y3a1AAA",
                                                "Id": "0QL4x000000lAXsGAM",
                                                "vlocity_ins__ProductChildItemId__c": "a484x000000Zh9nAAC",
                                                "currencyCode": "USD",
                                                "currencySymbol": "$",
                                                "displaySequence": 2,
                                                "actions": {
                                                    "updateChildLine": {
                                                        "client": {
                                                            "params": {}
                                                        },
                                                        "remote": {
                                                            "params": {
                                                                "methodName": "updateChildLine",
                                                                "quoteLineId": "0QL4x000000lAXsGAM",
                                                                "reprice": true,
                                                                "quoteId": "0Q04x000000l6zPCAQ"
                                                            }
                                                        },
                                                        "rest": {
                                                            "link": null,
                                                            "method": null,
                                                            "params": {}
                                                        }
                                                    }
                                                }
                                            },
                                            {
                                                "attributeCategories": {
                                                    "records": [
                                                        {
                                                            "productAttributes": {
                                                                "records": [
                                                                    {
                                                                        "userValues": 1000,
                                                                        "values": [
                                                                            {
                                                                                "value": 1000,
                                                                                "disabled": false,
                                                                                "readonly": false,
                                                                                "label": "$1000",
                                                                                "id": "0"
                                                                            },
                                                                            {
                                                                                "value": 2000,
                                                                                "disabled": false,
                                                                                "readonly": false,
                                                                                "label": "$2000",
                                                                                "id": "1"
                                                                            },
                                                                            {
                                                                                "value": 5000,
                                                                                "disabled": false,
                                                                                "readonly": false,
                                                                                "label": "$5000",
                                                                                "id": "2"
                                                                            }
                                                                        ],
                                                                        "isNotTranslatable": false,
                                                                        "cloneable": true,
                                                                        "hidden": false,
                                                                        "hasRules": false,
                                                                        "displaySequence": 0,
                                                                        "label": "Med Pay Person Limit",
                                                                        "attributeId": "a0S4P000009YMKCUA4",
                                                                        "filterable": true,
                                                                        "disabled": false,
                                                                        "readonly": false,
                                                                        "required": false,
                                                                        "multiselect": false,
                                                                        "inputType": "dropdown",
                                                                        "dataType": "currency",
                                                                        "code": "autoMedPayLimClmCov"
                                                                    }
                                                                ],
                                                                "totalSize": 1
                                                            },
                                                            "id": "a0R4P00000JWzkZUAT",
                                                            "Name": "Auto Terms",
                                                            "Code__c": "autoTerms",
                                                            "displaySequence": 230
                                                        }
                                                    ],
                                                    "totalSize": 1
                                                },
                                                "pciId": "a484x000000Zh9oAAC",
                                                "isSelected": true,
                                                "ProductCode": "autoMedical",
                                                "Name": "Medical Payments",
                                                "productName": "Medical Payments",
                                                "isOptional": false,
                                                "lineRecordType": "CoverageSpec",
                                                "instanceKey": "2020 Mazda CX-30_autoMedical",
                                                "quoteLineItemId": "0QL4x000000lAXrGAM",
                                                "vlocity_ins__NeedReprice__c": false,
                                                "needReprice": false,
                                                "vlocity_ins__ProductChildItemSequence__c": 3,
                                                "vlocity_ins__TotalAmount__c": 37.32,
                                                "vlocity_ins__ProductName__c": "Medical Payments",
                                                "vlocity_ins__PricingSource__c": "premiumMED",
                                                "LastModifiedDate": "2021-02-03T16:11:02.000+0000",
                                                "TotalPrice": 37.32,
                                                "vlocity_ins__Type__c": "Auto",
                                                "vlocity_ins__RecordTypeName__c": "CoverageSpec",
                                                "UnitPrice": 37.32,
                                                "Price": 37.32,
                                                "QuoteId": "0Q04x000000l6zPCAQ",
                                                "vlocity_ins__AttributeSelectedValues__c": "{\"autoMedPayLimClmCov\":1000}",
                                                "CreatedDate": "2021-02-03T16:11:02.000+0000",
                                                "LineNumber": "00004354",
                                                "vlocity_ins__SubParentItemId__c": "0QL4x000000lAXkGAM",
                                                "vlocity_ins__ParentItemId__c": "0QL4x000000lAXhGAM",
                                                "vlocity_ins__ParentItemId2__c": "0QL4x000000lAXhGAM",
                                                "vlocity_ins__ItemName__c": "2020 Mazda CX-30_autoMedical",
                                                "Product2Id": "01t4x000001y3aKAAQ",
                                                "productId": "01t4x000001y3aKAAQ",
                                                "Id": "0QL4x000000lAXrGAM",
                                                "vlocity_ins__ProductChildItemId__c": "a484x000000Zh9oAAC",
                                                "currencyCode": "USD",
                                                "currencySymbol": "$",
                                                "displaySequence": 3,
                                                "actions": {
                                                    "updateChildLine": {
                                                        "client": {
                                                            "params": {}
                                                        },
                                                        "remote": {
                                                            "params": {
                                                                "methodName": "updateChildLine",
                                                                "quoteLineId": "0QL4x000000lAXrGAM",
                                                                "reprice": true,
                                                                "quoteId": "0Q04x000000l6zPCAQ"
                                                            }
                                                        },
                                                        "rest": {
                                                            "link": null,
                                                            "method": null,
                                                            "params": {}
                                                        }
                                                    }
                                                }
                                            },
                                            {
                                                "attributeCategories": {
                                                    "records": [
                                                        {
                                                            "productAttributes": {
                                                                "records": [
                                                                    {
                                                                        "userValues": "50/100",
                                                                        "values": [
                                                                            {
                                                                                "value": "15/30",
                                                                                "disabled": false,
                                                                                "readonly": false,
                                                                                "label": "$15,000 / $30,000",
                                                                                "id": "0"
                                                                            },
                                                                            {
                                                                                "value": "25/50",
                                                                                "disabled": false,
                                                                                "readonly": false,
                                                                                "label": "$25,000 / $50,000",
                                                                                "id": "1"
                                                                            },
                                                                            {
                                                                                "value": "30/60",
                                                                                "disabled": false,
                                                                                "readonly": false,
                                                                                "label": "$30,000 / $60,000",
                                                                                "id": "2"
                                                                            },
                                                                            {
                                                                                "value": "50/100",
                                                                                "disabled": false,
                                                                                "readonly": false,
                                                                                "label": "$50,000 / $100,000",
                                                                                "id": "3"
                                                                            },
                                                                            {
                                                                                "value": "100/300",
                                                                                "disabled": false,
                                                                                "readonly": false,
                                                                                "label": "$100,000 / $300,000",
                                                                                "id": "4"
                                                                            },
                                                                            {
                                                                                "value": "250/500",
                                                                                "disabled": false,
                                                                                "readonly": false,
                                                                                "label": "$250,000 / $500,000",
                                                                                "id": "5"
                                                                            },
                                                                            {
                                                                                "value": "500/500",
                                                                                "disabled": false,
                                                                                "readonly": false,
                                                                                "label": "$500,000 / $500,000",
                                                                                "id": "6"
                                                                            },
                                                                            {
                                                                                "value": "500/1000",
                                                                                "disabled": false,
                                                                                "readonly": false,
                                                                                "label": "$500,000 / $1,000,000",
                                                                                "id": "7"
                                                                            }
                                                                        ],
                                                                        "isNotTranslatable": false,
                                                                        "cloneable": true,
                                                                        "hidden": false,
                                                                        "hasRules": false,
                                                                        "displaySequence": 0,
                                                                        "label": "UM Limit",
                                                                        "attributeId": "a0S4P000009YMKGUA4",
                                                                        "filterable": true,
                                                                        "disabled": false,
                                                                        "readonly": false,
                                                                        "required": false,
                                                                        "multiselect": false,
                                                                        "inputType": "dropdown",
                                                                        "dataType": "text",
                                                                        "code": "autoUMLimit"
                                                                    }
                                                                ],
                                                                "totalSize": 1
                                                            },
                                                            "id": "a0R4P00000JWzkZUAT",
                                                            "Name": "Auto Terms",
                                                            "Code__c": "autoTerms",
                                                            "displaySequence": 230
                                                        }
                                                    ],
                                                    "totalSize": 1
                                                },
                                                "pciId": "a484x000000Zh9sAAC",
                                                "isSelected": true,
                                                "ProductCode": "autoUM",
                                                "Name": "Uninsured Motorist",
                                                "productName": "Uninsured Motorist",
                                                "isOptional": false,
                                                "lineRecordType": "CoverageSpec",
                                                "instanceKey": "2020 Mazda CX-30_autoUM",
                                                "quoteLineItemId": "0QL4x000000lAXqGAM",
                                                "vlocity_ins__NeedReprice__c": false,
                                                "needReprice": false,
                                                "vlocity_ins__ProductChildItemSequence__c": 4,
                                                "vlocity_ins__TotalAmount__c": 68.22,
                                                "vlocity_ins__ProductName__c": "Uninsured Motorist",
                                                "vlocity_ins__PricingSource__c": "premiumUM",
                                                "LastModifiedDate": "2021-02-03T16:11:02.000+0000",
                                                "TotalPrice": 68.22,
                                                "vlocity_ins__Type__c": "Auto",
                                                "vlocity_ins__RecordTypeName__c": "CoverageSpec",
                                                "UnitPrice": 68.22,
                                                "Price": 68.22,
                                                "QuoteId": "0Q04x000000l6zPCAQ",
                                                "vlocity_ins__AttributeSelectedValues__c": "{\"autoUMLimit\":\"50/100\"}",
                                                "CreatedDate": "2021-02-03T16:11:02.000+0000",
                                                "LineNumber": "00004353",
                                                "vlocity_ins__SubParentItemId__c": "0QL4x000000lAXkGAM",
                                                "vlocity_ins__ParentItemId__c": "0QL4x000000lAXhGAM",
                                                "vlocity_ins__ParentItemId2__c": "0QL4x000000lAXhGAM",
                                                "vlocity_ins__ItemName__c": "2020 Mazda CX-30_autoUM",
                                                "Product2Id": "01t4x000001y3ZzAAI",
                                                "productId": "01t4x000001y3ZzAAI",
                                                "Id": "0QL4x000000lAXqGAM",
                                                "vlocity_ins__ProductChildItemId__c": "a484x000000Zh9sAAC",
                                                "currencyCode": "USD",
                                                "currencySymbol": "$",
                                                "displaySequence": 4,
                                                "actions": {
                                                    "updateChildLine": {
                                                        "client": {
                                                            "params": {}
                                                        },
                                                        "remote": {
                                                            "params": {
                                                                "methodName": "updateChildLine",
                                                                "quoteLineId": "0QL4x000000lAXqGAM",
                                                                "reprice": true,
                                                                "quoteId": "0Q04x000000l6zPCAQ"
                                                            }
                                                        },
                                                        "rest": {
                                                            "link": null,
                                                            "method": null,
                                                            "params": {}
                                                        }
                                                    }
                                                }
                                            },
                                            {
                                                "attributeCategories": {
                                                    "records": [
                                                        {
                                                            "productAttributes": {
                                                                "records": [
                                                                    {
                                                                        "userValues": 2000,
                                                                        "values": [
                                                                            {
                                                                                "disabled": true,
                                                                                "readonly": true
                                                                            }
                                                                        ],
                                                                        "isNotTranslatable": false,
                                                                        "cloneable": true,
                                                                        "hidden": false,
                                                                        "hasRules": false,
                                                                        "displaySequence": 0,
                                                                        "label": "Rental Limit",
                                                                        "attributeId": "a0S4P000009YMKFUA4",
                                                                        "filterable": true,
                                                                        "disabled": true,
                                                                        "readonly": true,
                                                                        "required": false,
                                                                        "multiselect": false,
                                                                        "inputType": "number",
                                                                        "dataType": "currency",
                                                                        "code": "autoRentalLimClmCov"
                                                                    },
                                                                    {
                                                                        "userValues": 30,
                                                                        "values": [
                                                                            {
                                                                                "disabled": true,
                                                                                "readonly": true
                                                                            }
                                                                        ],
                                                                        "isNotTranslatable": false,
                                                                        "cloneable": true,
                                                                        "hidden": false,
                                                                        "hasRules": false,
                                                                        "displaySequence": 1,
                                                                        "label": "Number of Days",
                                                                        "attributeId": "a0S4P000009YMKEUA4",
                                                                        "filterable": true,
                                                                        "disabled": true,
                                                                        "readonly": true,
                                                                        "required": false,
                                                                        "multiselect": false,
                                                                        "inputType": "number",
                                                                        "dataType": "number",
                                                                        "code": "autoRentalDays"
                                                                    }
                                                                ],
                                                                "totalSize": 2
                                                            },
                                                            "id": "a0R4P00000JWzkZUAT",
                                                            "Name": "Auto Terms",
                                                            "Code__c": "autoTerms",
                                                            "displaySequence": 230
                                                        }
                                                    ],
                                                    "totalSize": 1
                                                },
                                                "vlocity_ins__Type__c": "Auto",
                                                "vlocity_ins__PricingSource__c": "premiumRental",
                                                "recordType": "CoverageSpec",
                                                "vlocity_ins__RecordTypeName__c": "CoverageSpec",
                                                "pciId": "a484x000000Zh9tAAC",
                                                "isSelected": false,
                                                "isOptional": true,
                                                "Name": "Rental Car",
                                                "ProductCode": "autoRental",
                                                "productName": "Rental Car",
                                                "productId": "01t4x000001y3aRAAQ",
                                                "displaySequence": 5
                                            }
                                        ],
                                        "totalSize": 6
                                    },
                                    "attributeCategories": {
                                        "records": [
                                            {
                                                "productAttributes": {
                                                    "records": [
                                                        {
                                                            "userValues": 26200,
                                                            "values": [
                                                                {
                                                                    "disabled": true,
                                                                    "readonly": true
                                                                }
                                                            ],
                                                            "isNotTranslatable": false,
                                                            "cloneable": true,
                                                            "hidden": false,
                                                            "hasRules": false,
                                                            "displaySequence": 0,
                                                            "label": "Value",
                                                            "attributeId": "a0S4P000004VofbUAC",
                                                            "filterable": true,
                                                            "disabled": true,
                                                            "readonly": true,
                                                            "required": false,
                                                            "multiselect": false,
                                                            "inputType": "number",
                                                            "dataType": "currency",
                                                            "code": "avValue"
                                                        },
                                                        {
                                                            "userValues": false,
                                                            "values": [
                                                                {
                                                                    "disabled": true,
                                                                    "readonly": true
                                                                }
                                                            ],
                                                            "isNotTranslatable": false,
                                                            "cloneable": true,
                                                            "hidden": false,
                                                            "hasRules": false,
                                                            "displaySequence": 1,
                                                            "label": "Alternative Fuel",
                                                            "attributeId": "a0S4P000004VofCUAS",
                                                            "filterable": true,
                                                            "disabled": true,
                                                            "readonly": true,
                                                            "required": false,
                                                            "multiselect": false,
                                                            "inputType": "checkbox",
                                                            "dataType": "text",
                                                            "code": "avAltFuel"
                                                        },
                                                        {
                                                            "userValues": true,
                                                            "values": [
                                                                {
                                                                    "disabled": true,
                                                                    "readonly": true
                                                                }
                                                            ],
                                                            "isNotTranslatable": false,
                                                            "cloneable": true,
                                                            "hidden": false,
                                                            "hasRules": false,
                                                            "displaySequence": 2,
                                                            "label": "Anti Theft",
                                                            "attributeId": "a0S4P000004VofDUAS",
                                                            "filterable": true,
                                                            "disabled": true,
                                                            "readonly": true,
                                                            "required": false,
                                                            "multiselect": false,
                                                            "inputType": "checkbox",
                                                            "dataType": "text",
                                                            "code": "avAntiTheft"
                                                        },
                                                        {
                                                            "userValues": false,
                                                            "values": [
                                                                {
                                                                    "disabled": true,
                                                                    "readonly": true
                                                                }
                                                            ],
                                                            "isNotTranslatable": false,
                                                            "cloneable": true,
                                                            "hidden": false,
                                                            "hasRules": false,
                                                            "displaySequence": 3,
                                                            "label": "Brakes",
                                                            "attributeId": "a0S4P000004VofFUAS",
                                                            "filterable": true,
                                                            "disabled": true,
                                                            "readonly": true,
                                                            "required": false,
                                                            "multiselect": false,
                                                            "inputType": "checkbox",
                                                            "dataType": "text",
                                                            "code": "avBrakes"
                                                        },
                                                        {
                                                            "userValues": null,
                                                            "values": [
                                                                {
                                                                    "disabled": true,
                                                                    "readonly": true
                                                                }
                                                            ],
                                                            "isNotTranslatable": false,
                                                            "cloneable": true,
                                                            "hidden": false,
                                                            "hasRules": false,
                                                            "displaySequence": 4,
                                                            "label": "Claim Frequency",
                                                            "attributeId": "a0S4P000004VofGUAS",
                                                            "filterable": true,
                                                            "disabled": true,
                                                            "readonly": true,
                                                            "required": false,
                                                            "multiselect": false,
                                                            "inputType": "number",
                                                            "dataType": "number",
                                                            "code": "avClaimFreq"
                                                        },
                                                        {
                                                            "userValues": null,
                                                            "values": [
                                                                {
                                                                    "disabled": true,
                                                                    "readonly": true
                                                                }
                                                            ],
                                                            "isNotTranslatable": false,
                                                            "cloneable": true,
                                                            "hidden": false,
                                                            "hasRules": false,
                                                            "displaySequence": 5,
                                                            "label": "Claim Severity",
                                                            "attributeId": "a0S4P000004VofHUAS",
                                                            "filterable": true,
                                                            "disabled": true,
                                                            "readonly": true,
                                                            "required": false,
                                                            "multiselect": false,
                                                            "inputType": "number",
                                                            "dataType": "number",
                                                            "code": "avClaimSev"
                                                        },
                                                        {
                                                            "userValues": null,
                                                            "values": [
                                                                {
                                                                    "disabled": true,
                                                                    "readonly": true
                                                                }
                                                            ],
                                                            "isNotTranslatable": false,
                                                            "cloneable": true,
                                                            "hidden": false,
                                                            "hasRules": false,
                                                            "displaySequence": 6,
                                                            "label": "License Number",
                                                            "attributeId": "a0S4P000004VofLUAS",
                                                            "filterable": true,
                                                            "disabled": true,
                                                            "readonly": true,
                                                            "required": false,
                                                            "multiselect": false,
                                                            "inputType": "text",
                                                            "dataType": "text",
                                                            "code": "avLicNum"
                                                        },
                                                        {
                                                            "userValues": null,
                                                            "values": [
                                                                {
                                                                    "disabled": true,
                                                                    "readonly": true
                                                                }
                                                            ],
                                                            "isNotTranslatable": false,
                                                            "cloneable": true,
                                                            "hidden": false,
                                                            "hasRules": false,
                                                            "displaySequence": 7,
                                                            "label": "License State",
                                                            "attributeId": "a0S4P000004VofMUAS",
                                                            "filterable": true,
                                                            "disabled": true,
                                                            "readonly": true,
                                                            "required": false,
                                                            "multiselect": false,
                                                            "inputType": "text",
                                                            "dataType": "text",
                                                            "code": "avLicState"
                                                        },
                                                        {
                                                            "userValues": "Mazda",
                                                            "values": [
                                                                {
                                                                    "disabled": true,
                                                                    "readonly": true
                                                                }
                                                            ],
                                                            "isNotTranslatable": false,
                                                            "cloneable": true,
                                                            "hidden": false,
                                                            "hasRules": false,
                                                            "displaySequence": 8,
                                                            "label": "Make",
                                                            "attributeId": "a0S4P000004VofNUAS",
                                                            "filterable": true,
                                                            "disabled": true,
                                                            "readonly": true,
                                                            "required": false,
                                                            "multiselect": false,
                                                            "inputType": "text",
                                                            "dataType": "text",
                                                            "code": "avMake"
                                                        },
                                                        {
                                                            "userValues": "CX-30",
                                                            "values": [
                                                                {
                                                                    "disabled": true,
                                                                    "readonly": true
                                                                }
                                                            ],
                                                            "isNotTranslatable": false,
                                                            "cloneable": true,
                                                            "hidden": false,
                                                            "hasRules": false,
                                                            "displaySequence": 9,
                                                            "label": "Model",
                                                            "attributeId": "a0S4P000004VofPUAS",
                                                            "filterable": true,
                                                            "disabled": true,
                                                            "readonly": true,
                                                            "required": false,
                                                            "multiselect": false,
                                                            "inputType": "text",
                                                            "dataType": "text",
                                                            "code": "avModel"
                                                        },
                                                        {
                                                            "userValues": null,
                                                            "values": [
                                                                {
                                                                    "disabled": true,
                                                                    "readonly": true
                                                                }
                                                            ],
                                                            "isNotTranslatable": false,
                                                            "cloneable": true,
                                                            "hidden": false,
                                                            "hasRules": false,
                                                            "displaySequence": 10,
                                                            "label": "Rated Driver - BIPD",
                                                            "attributeId": "a0S4P000004VofQUAS",
                                                            "filterable": true,
                                                            "disabled": true,
                                                            "readonly": true,
                                                            "required": false,
                                                            "multiselect": false,
                                                            "inputType": "number",
                                                            "dataType": "number",
                                                            "code": "avRatedDriver-BIPD"
                                                        },
                                                        {
                                                            "userValues": null,
                                                            "values": [
                                                                {
                                                                    "disabled": true,
                                                                    "readonly": true
                                                                }
                                                            ],
                                                            "isNotTranslatable": false,
                                                            "cloneable": true,
                                                            "hidden": false,
                                                            "hasRules": false,
                                                            "displaySequence": 11,
                                                            "label": "Rated Driver - Comprehensive",
                                                            "attributeId": "a0S4P000004VofSUAS",
                                                            "filterable": true,
                                                            "disabled": true,
                                                            "readonly": true,
                                                            "required": false,
                                                            "multiselect": false,
                                                            "inputType": "number",
                                                            "dataType": "number",
                                                            "code": "avRatedDriver-COMP"
                                                        },
                                                        {
                                                            "userValues": null,
                                                            "values": [
                                                                {
                                                                    "disabled": true,
                                                                    "readonly": true
                                                                }
                                                            ],
                                                            "isNotTranslatable": false,
                                                            "cloneable": true,
                                                            "hidden": false,
                                                            "hasRules": false,
                                                            "displaySequence": 12,
                                                            "label": "Rated Driver - Medical Payments",
                                                            "attributeId": "a0S4P000004VofTUAS",
                                                            "filterable": true,
                                                            "disabled": true,
                                                            "readonly": true,
                                                            "required": false,
                                                            "multiselect": false,
                                                            "inputType": "number",
                                                            "dataType": "number",
                                                            "code": "avRatedDriver-MED"
                                                        },
                                                        {
                                                            "userValues": null,
                                                            "values": [
                                                                {
                                                                    "disabled": true,
                                                                    "readonly": true
                                                                }
                                                            ],
                                                            "isNotTranslatable": false,
                                                            "cloneable": true,
                                                            "hidden": false,
                                                            "hasRules": false,
                                                            "displaySequence": 13,
                                                            "label": "Rated Driver - Uninsured Motorist",
                                                            "attributeId": "a0S4P000004VofUUAS",
                                                            "filterable": true,
                                                            "disabled": true,
                                                            "readonly": true,
                                                            "required": false,
                                                            "multiselect": false,
                                                            "inputType": "number",
                                                            "dataType": "number",
                                                            "code": "avRatedDriver-UM"
                                                        },
                                                        {
                                                            "userValues": null,
                                                            "values": [
                                                                {
                                                                    "disabled": true,
                                                                    "readonly": true
                                                                }
                                                            ],
                                                            "isNotTranslatable": false,
                                                            "cloneable": true,
                                                            "hidden": false,
                                                            "hasRules": false,
                                                            "displaySequence": 14,
                                                            "label": "Rated Driver Name",
                                                            "attributeId": "a0S4P000004VofVUAS",
                                                            "filterable": true,
                                                            "disabled": true,
                                                            "readonly": true,
                                                            "required": false,
                                                            "multiselect": false,
                                                            "inputType": "text",
                                                            "dataType": "text",
                                                            "code": "avRatedDriverName"
                                                        },
                                                        {
                                                            "userValues": false,
                                                            "values": [
                                                                {
                                                                    "disabled": true,
                                                                    "readonly": true
                                                                }
                                                            ],
                                                            "isNotTranslatable": false,
                                                            "cloneable": true,
                                                            "hidden": false,
                                                            "hasRules": false,
                                                            "displaySequence": 15,
                                                            "label": "Restraints",
                                                            "attributeId": "a0S4P000004VofWUAS",
                                                            "filterable": true,
                                                            "disabled": true,
                                                            "readonly": true,
                                                            "required": false,
                                                            "multiselect": false,
                                                            "inputType": "checkbox",
                                                            "dataType": "text",
                                                            "code": "avRestraints"
                                                        },
                                                        {
                                                            "userValues": true,
                                                            "values": [
                                                                {
                                                                    "disabled": true,
                                                                    "readonly": true
                                                                }
                                                            ],
                                                            "isNotTranslatable": false,
                                                            "cloneable": true,
                                                            "hidden": false,
                                                            "hasRules": false,
                                                            "displaySequence": 16,
                                                            "label": "Stablization",
                                                            "attributeId": "a0S4P000004VofXUAS",
                                                            "filterable": true,
                                                            "disabled": true,
                                                            "readonly": true,
                                                            "required": false,
                                                            "multiselect": false,
                                                            "inputType": "checkbox",
                                                            "dataType": "text",
                                                            "code": "avStabilization"
                                                        },
                                                        {
                                                            "userValues": false,
                                                            "values": [
                                                                {
                                                                    "disabled": false,
                                                                    "readonly": false
                                                                }
                                                            ],
                                                            "isNotTranslatable": false,
                                                            "cloneable": true,
                                                            "hidden": false,
                                                            "hasRules": false,
                                                            "displaySequence": 17,
                                                            "label": "Historic",
                                                            "attributeId": "a0S4P000004VofKUAS",
                                                            "filterable": true,
                                                            "disabled": false,
                                                            "readonly": false,
                                                            "required": false,
                                                            "multiselect": false,
                                                            "inputType": "checkbox",
                                                            "dataType": "text",
                                                            "code": "avHistoric"
                                                        },
                                                        {
                                                            "userValues": null,
                                                            "values": [
                                                                {
                                                                    "disabled": true,
                                                                    "readonly": true
                                                                }
                                                            ],
                                                            "isNotTranslatable": false,
                                                            "cloneable": true,
                                                            "hidden": false,
                                                            "hasRules": false,
                                                            "displaySequence": 18,
                                                            "label": "Style",
                                                            "attributeId": "a0S4P000004VofYUAS",
                                                            "filterable": true,
                                                            "disabled": true,
                                                            "readonly": true,
                                                            "required": false,
                                                            "multiselect": false,
                                                            "inputType": "text",
                                                            "dataType": "text",
                                                            "code": "avStyle"
                                                        },
                                                        {
                                                            "userValues": null,
                                                            "values": [
                                                                {
                                                                    "disabled": true,
                                                                    "readonly": true
                                                                }
                                                            ],
                                                            "isNotTranslatable": false,
                                                            "cloneable": true,
                                                            "hidden": false,
                                                            "hasRules": false,
                                                            "displaySequence": 19,
                                                            "label": "Symbol",
                                                            "attributeId": "a0S4P000004VofZUAS",
                                                            "filterable": true,
                                                            "disabled": true,
                                                            "readonly": true,
                                                            "required": false,
                                                            "multiselect": false,
                                                            "inputType": "text",
                                                            "dataType": "text",
                                                            "code": "avSymbol"
                                                        },
                                                        {
                                                            "userValues": null,
                                                            "values": [
                                                                {
                                                                    "disabled": true,
                                                                    "readonly": true
                                                                }
                                                            ],
                                                            "isNotTranslatable": false,
                                                            "cloneable": true,
                                                            "hidden": false,
                                                            "hasRules": false,
                                                            "displaySequence": 20,
                                                            "label": "Color",
                                                            "attributeId": "a0S4P000004VofIUAS",
                                                            "filterable": true,
                                                            "disabled": true,
                                                            "readonly": true,
                                                            "required": false,
                                                            "multiselect": false,
                                                            "inputType": "text",
                                                            "dataType": "text",
                                                            "code": "avColor"
                                                        },
                                                        {
                                                            "userValues": null,
                                                            "values": [
                                                                {
                                                                    "disabled": true,
                                                                    "readonly": true
                                                                }
                                                            ],
                                                            "isNotTranslatable": false,
                                                            "cloneable": true,
                                                            "hidden": false,
                                                            "hasRules": false,
                                                            "displaySequence": 21,
                                                            "label": "VIN",
                                                            "attributeId": "a0S4P000004VofaUAC",
                                                            "filterable": true,
                                                            "disabled": true,
                                                            "readonly": true,
                                                            "required": false,
                                                            "multiselect": false,
                                                            "inputType": "text",
                                                            "dataType": "text",
                                                            "code": "avVIN"
                                                        },
                                                        {
                                                            "userValues": "2020",
                                                            "values": [
                                                                {
                                                                    "disabled": true,
                                                                    "readonly": true
                                                                }
                                                            ],
                                                            "isNotTranslatable": false,
                                                            "cloneable": true,
                                                            "hidden": false,
                                                            "hasRules": false,
                                                            "displaySequence": 22,
                                                            "label": "Year",
                                                            "attributeId": "a0S4P000004VofcUAC",
                                                            "filterable": true,
                                                            "disabled": true,
                                                            "readonly": true,
                                                            "required": false,
                                                            "multiselect": false,
                                                            "inputType": "text",
                                                            "dataType": "text",
                                                            "code": "avYear"
                                                        },
                                                        {
                                                            "userValues": 15000,
                                                            "values": [
                                                                {
                                                                    "disabled": true,
                                                                    "readonly": true
                                                                }
                                                            ],
                                                            "isNotTranslatable": false,
                                                            "cloneable": true,
                                                            "hidden": false,
                                                            "hasRules": false,
                                                            "displaySequence": 23,
                                                            "label": "Annual Mileage",
                                                            "attributeId": "a0S4P000004VofOUAS",
                                                            "filterable": true,
                                                            "disabled": true,
                                                            "readonly": true,
                                                            "required": false,
                                                            "multiselect": false,
                                                            "inputType": "number",
                                                            "dataType": "number",
                                                            "code": "avMileage"
                                                        },
                                                        {
                                                            "userValues": "Sedan/SUV",
                                                            "values": [
                                                                {
                                                                    "disabled": true,
                                                                    "readonly": true
                                                                }
                                                            ],
                                                            "isNotTranslatable": false,
                                                            "cloneable": true,
                                                            "hidden": false,
                                                            "hasRules": false,
                                                            "displaySequence": 24,
                                                            "label": "Body Type",
                                                            "attributeId": "a0S4P000004VofEUAS",
                                                            "filterable": true,
                                                            "disabled": true,
                                                            "readonly": true,
                                                            "required": false,
                                                            "multiselect": false,
                                                            "inputType": "text",
                                                            "dataType": "text",
                                                            "code": "avBodyType"
                                                        },
                                                        {
                                                            "userValues": "94110",
                                                            "values": [
                                                                {
                                                                    "disabled": true,
                                                                    "readonly": true
                                                                }
                                                            ],
                                                            "isNotTranslatable": false,
                                                            "cloneable": true,
                                                            "hidden": false,
                                                            "hasRules": false,
                                                            "displaySequence": 25,
                                                            "label": "Garage Location (Postal Code)",
                                                            "attributeId": "a0S4P000004VofJUAS",
                                                            "filterable": true,
                                                            "disabled": true,
                                                            "readonly": true,
                                                            "required": false,
                                                            "multiselect": false,
                                                            "inputType": "text",
                                                            "dataType": "text",
                                                            "code": "avGaragePostalCode"
                                                        },
                                                        {
                                                            "userValues": null,
                                                            "values": [
                                                                {
                                                                    "disabled": true,
                                                                    "readonly": true
                                                                }
                                                            ],
                                                            "isNotTranslatable": false,
                                                            "cloneable": true,
                                                            "hidden": false,
                                                            "hasRules": false,
                                                            "displaySequence": 26,
                                                            "label": "Rated Driver - Collision",
                                                            "attributeId": "a0S4P000004VofRUAS",
                                                            "filterable": true,
                                                            "disabled": true,
                                                            "readonly": true,
                                                            "required": false,
                                                            "multiselect": false,
                                                            "inputType": "number",
                                                            "dataType": "number",
                                                            "code": "avRatedDriver-COLL"
                                                        }
                                                    ],
                                                    "totalSize": 27
                                                },
                                                "id": "a0R4P00000J2MJyUAN",
                                                "Name": "Auto Vehicle",
                                                "Code__c": "autoVehicle",
                                                "displaySequence": 210
                                            }
                                        ],
                                        "totalSize": 1
                                    },
                                    "hasCoverages": true,
                                    "pciId": "a484x000000Zh9qAAC",
                                    "lineRecordType": "InsuredItemSpec",
                                    "vlocity_ins__PricingFormula__c": "premiumBIPD + premiumCOLL + premiumCCD + premiumMED + premiumUM+premiumRental",
                                    "isPrimary": true,
                                    "instanceKey": "2020 Mazda CX-30",
                                    "Name": "2020 Mazda CX-30",
                                    "quoteLineItemId": "0QL4x000000lAXkGAM",
                                    "ProductCode": "autoVehicle",
                                    "hasAttributes": true,
                                    "needCustomProcess": false,
                                    "productName": "Vehicle",
                                    "maxCount": 1,
                                    "minCount": 1,
                                    "vlocity_ins__NeedReprice__c": false,
                                    "needReprice": false,
                                    "vlocity_ins__ProductChildItemSequence__c": 1,
                                    "vlocity_ins__TotalAmount__c": 1128.07,
                                    "vlocity_ins__ProductName__c": "Vehicle",
                                    "LastModifiedDate": "2021-02-03T16:11:02.000+0000",
                                    "TotalPrice": 1128.07,
                                    "vlocity_ins__Type__c": "Auto",
                                    "vlocity_ins__RecordTypeName__c": "InsuredItemSpec",
                                    "UnitPrice": 1128.07,
                                    "Price": 1128.07,
                                    "QuoteId": "0Q04x000000l6zPCAQ",
                                    "vlocity_ins__AttributeSelectedValues__c": "{\"avAltFuel\":false,\"avAntiTheft\":true,\"avYear\":\"2020\",\"avMileage\":15000,\"avValue\":26200,\"avMake\":\"Mazda\",\"isParent\":true,\"avGaragePostalCode\":\"94110\",\"avStabilization\":true,\"avModel\":\"CX-30\",\"avHistoric\":false,\"avBrakes\":false,\"avBodyType\":\"Sedan/SUV\",\"ProductCode\":\"autoVehicle\",\"avRestraints\":false}",
                                    "CreatedDate": "2021-02-03T16:11:02.000+0000",
                                    "LineNumber": "00004347",
                                    "vlocity_ins__SubParentItemId__c": "0QL4x000000lAXhGAM",
                                    "vlocity_ins__ParentItemId__c": "0QL4x000000lAXhGAM",
                                    "vlocity_ins__ParentItemId2__c": "0QL4x000000lAXhGAM",
                                    "vlocity_ins__ItemName__c": "2020 Mazda CX-30",
                                    "Product2Id": "01t4x000001y3a0AAA",
                                    "productId": "01t4x000001y3a0AAA",
                                    "Id": "0QL4x000000lAXkGAM",
                                    "vlocity_ins__ProductChildItemId__c": "a484x000000Zh9qAAC",
                                    "currencyCode": "USD",
                                    "currencySymbol": "$",
                                    "displaySequence": 1,
                                    "actions": {
                                        "deleteChildLine": {
                                            "client": {
                                                "params": {}
                                            },
                                            "remote": {
                                                "params": {
                                                    "methodName": "deleteChildLine",
                                                    "quoteLineId": "0QL4x000000lAXkGAM",
                                                    "itemRecordType": "InsuredItemSpec",
                                                    "minCount": 1
                                                }
                                            },
                                            "rest": {
                                                "link": null,
                                                "method": null,
                                                "params": {}
                                            }
                                        },
                                        "updateChildLine": {
                                            "client": {
                                                "params": {}
                                            },
                                            "remote": {
                                                "params": {
                                                    "methodName": "updateChildLine",
                                                    "quoteLineId": "0QL4x000000lAXkGAM",
                                                    "reprice": true,
                                                    "quoteId": "0Q04x000000l6zPCAQ"
                                                }
                                            },
                                            "rest": {
                                                "link": null,
                                                "method": null,
                                                "params": {}
                                            }
                                        }
                                    }
                                },
                                {
                                    "childProducts": {
                                        "records": [
                                            {
                                                "attributeCategories": {
                                                    "records": [
                                                        {
                                                            "productAttributes": {
                                                                "records": [
                                                                    {
                                                                        "valueDecoder": "autoBILimClmCov/autoBILimClm/autoPDLimClm",
                                                                        "userValues": "25000/50000/25000",
                                                                        "values": [
                                                                            {
                                                                                "value": "15000/30000/10000",
                                                                                "disabled": false,
                                                                                "readonly": false,
                                                                                "label": "$15000/$30000/$10000",
                                                                                "id": "0"
                                                                            },
                                                                            {
                                                                                "value": "15000/30000/5000",
                                                                                "disabled": false,
                                                                                "readonly": false,
                                                                                "label": "$15000/$30000/$5000",
                                                                                "id": "1"
                                                                            },
                                                                            {
                                                                                "value": "25000/50000/25000",
                                                                                "disabled": false,
                                                                                "readonly": false,
                                                                                "label": "$25000/$50000/$25000",
                                                                                "id": "2"
                                                                            },
                                                                            {
                                                                                "value": "25000/50000/50000",
                                                                                "disabled": false,
                                                                                "readonly": false,
                                                                                "label": "$25000/$50000/$50000",
                                                                                "id": "3"
                                                                            },
                                                                            {
                                                                                "value": "50000/100000/50000",
                                                                                "disabled": false,
                                                                                "readonly": false,
                                                                                "label": "$50000/$100000/$50000",
                                                                                "id": "4"
                                                                            },
                                                                            {
                                                                                "value": "50000/100000/100000",
                                                                                "disabled": false,
                                                                                "readonly": false,
                                                                                "label": "$50000/$100000/$100000",
                                                                                "id": "5"
                                                                            },
                                                                            {
                                                                                "value": "100000/300000/25000",
                                                                                "disabled": false,
                                                                                "readonly": false,
                                                                                "label": "$100000/$300000/$25000",
                                                                                "id": "6"
                                                                            },
                                                                            {
                                                                                "value": "100000/300000/50000",
                                                                                "disabled": false,
                                                                                "readonly": false,
                                                                                "label": "$100000/$300000/$50000",
                                                                                "id": "7"
                                                                            },
                                                                            {
                                                                                "value": "100000/300000/100000",
                                                                                "disabled": false,
                                                                                "readonly": false,
                                                                                "label": "$100000/$300000/$100000",
                                                                                "id": "8"
                                                                            },
                                                                            {
                                                                                "value": "250000/500000/100000",
                                                                                "disabled": false,
                                                                                "readonly": false,
                                                                                "label": "$250000/$500000/$100000",
                                                                                "id": "9"
                                                                            },
                                                                            {
                                                                                "value": "500000/500000/100000",
                                                                                "disabled": false,
                                                                                "readonly": false,
                                                                                "label": "$500000/$500000/100000",
                                                                                "id": "10"
                                                                            },
                                                                            {
                                                                                "value": "500000/500000/500000",
                                                                                "disabled": false,
                                                                                "readonly": false,
                                                                                "label": "$500000/$500000/$500000",
                                                                                "id": "11"
                                                                            },
                                                                            {
                                                                                "value": "500000/1000000/500000",
                                                                                "disabled": false,
                                                                                "readonly": false,
                                                                                "label": "$500000/$1000000/$500000",
                                                                                "id": "12"
                                                                            }
                                                                        ],
                                                                        "isNotTranslatable": false,
                                                                        "cloneable": true,
                                                                        "hidden": false,
                                                                        "hasRules": true,
                                                                        "displaySequence": 0,
                                                                        "label": "BIPD Limit",
                                                                        "attributeId": "a0S4P000009YMK7UAO",
                                                                        "filterable": true,
                                                                        "disabled": false,
                                                                        "readonly": false,
                                                                        "required": false,
                                                                        "multiselect": false,
                                                                        "inputType": "dropdown",
                                                                        "dataType": "text",
                                                                        "code": "autoBIPDLimit"
                                                                    }
                                                                ],
                                                                "totalSize": 1
                                                            },
                                                            "id": "a0R4P00000JWzkZUAT",
                                                            "Name": "Auto Terms",
                                                            "Code__c": "autoTerms",
                                                            "displaySequence": 230
                                                        }
                                                    ],
                                                    "totalSize": 1
                                                },
                                                "pciId": "a484x000000ZhDPAA0",
                                                "isSelected": true,
                                                "ProductCode": "autoBIPD",
                                                "Name": "Bodily Injury & Property Damage",
                                                "productName": "Bodily Injury & Property Damage",
                                                "isOptional": false,
                                                "lineRecordType": "CoverageSpec",
                                                "instanceKey": "2019 BMW M3_autoBIPD",
                                                "quoteLineItemId": "0QL4x000000lAXpGAM",
                                                "vlocity_ins__NeedReprice__c": false,
                                                "needReprice": false,
                                                "vlocity_ins__ProductChildItemSequence__c": 0,
                                                "vlocity_ins__TotalAmount__c": 16.5,
                                                "vlocity_ins__ProductName__c": "Bodily Injury & Property Damage",
                                                "vlocity_ins__PricingSource__c": "premiumBIPD",
                                                "LastModifiedDate": "2021-02-03T16:11:02.000+0000",
                                                "TotalPrice": 16.5,
                                                "vlocity_ins__Type__c": "Auto",
                                                "vlocity_ins__RecordTypeName__c": "CoverageSpec",
                                                "UnitPrice": 16.5,
                                                "Price": 16.5,
                                                "QuoteId": "0Q04x000000l6zPCAQ",
                                                "vlocity_ins__AttributeSelectedValues__c": "{\"autoBIPDLimit.autoPDLimClm\":25000,\"autoBIPDLimit.autoBILimClm\":50000,\"autoBIPDLimit.autoBILimClmCov\":25000,\"autoBIPDLimit\":\"25000/50000/25000\"}",
                                                "CreatedDate": "2021-02-03T16:11:02.000+0000",
                                                "LineNumber": "00004352",
                                                "vlocity_ins__SubParentItemId__c": "0QL4x000000lAXjGAM",
                                                "vlocity_ins__ParentItemId__c": "0QL4x000000lAXhGAM",
                                                "vlocity_ins__ParentItemId2__c": "0QL4x000000lAXhGAM",
                                                "vlocity_ins__ItemName__c": "2019 BMW M3_autoBIPD",
                                                "Product2Id": "01t4x000001y3ZiAAI",
                                                "productId": "01t4x000001y3ZiAAI",
                                                "Id": "0QL4x000000lAXpGAM",
                                                "vlocity_ins__ProductChildItemId__c": "a484x000000ZhDPAA0",
                                                "currencyCode": "USD",
                                                "currencySymbol": "$",
                                                "displaySequence": 0,
                                                "actions": {
                                                    "updateChildLine": {
                                                        "client": {
                                                            "params": {}
                                                        },
                                                        "remote": {
                                                            "params": {
                                                                "methodName": "updateChildLine",
                                                                "quoteLineId": "0QL4x000000lAXpGAM",
                                                                "reprice": true,
                                                                "quoteId": "0Q04x000000l6zPCAQ"
                                                            }
                                                        },
                                                        "rest": {
                                                            "link": null,
                                                            "method": null,
                                                            "params": {}
                                                        }
                                                    }
                                                }
                                            },
                                            {
                                                "attributeCategories": {
                                                    "records": [
                                                        {
                                                            "productAttributes": {
                                                                "records": [
                                                                    {
                                                                        "userValues": 500,
                                                                        "values": [
                                                                            {
                                                                                "value": 250,
                                                                                "disabled": false,
                                                                                "readonly": false,
                                                                                "label": "$250",
                                                                                "id": "0"
                                                                            },
                                                                            {
                                                                                "value": 500,
                                                                                "disabled": false,
                                                                                "readonly": false,
                                                                                "label": "$500",
                                                                                "id": "1"
                                                                            },
                                                                            {
                                                                                "value": 750,
                                                                                "disabled": false,
                                                                                "readonly": false,
                                                                                "label": "$750",
                                                                                "id": "2"
                                                                            },
                                                                            {
                                                                                "value": 1000,
                                                                                "disabled": false,
                                                                                "readonly": false,
                                                                                "label": "$1000",
                                                                                "id": "3"
                                                                            },
                                                                            {
                                                                                "value": 1500,
                                                                                "disabled": false,
                                                                                "readonly": false,
                                                                                "label": "$1500",
                                                                                "id": "4"
                                                                            },
                                                                            {
                                                                                "value": 2500,
                                                                                "disabled": false,
                                                                                "readonly": false,
                                                                                "label": "$2500",
                                                                                "id": "5"
                                                                            }
                                                                        ],
                                                                        "isNotTranslatable": false,
                                                                        "cloneable": true,
                                                                        "hidden": false,
                                                                        "hasRules": false,
                                                                        "displaySequence": 0,
                                                                        "label": "Collision Deductible",
                                                                        "attributeId": "a0S4P000009YMK8UAO",
                                                                        "filterable": true,
                                                                        "disabled": false,
                                                                        "readonly": false,
                                                                        "required": false,
                                                                        "multiselect": false,
                                                                        "inputType": "dropdown",
                                                                        "dataType": "currency",
                                                                        "code": "autoCollDedClmCov"
                                                                    }
                                                                ],
                                                                "totalSize": 1
                                                            },
                                                            "id": "a0R4P00000JWzkZUAT",
                                                            "Name": "Auto Terms",
                                                            "Code__c": "autoTerms",
                                                            "displaySequence": 230
                                                        }
                                                    ],
                                                    "totalSize": 1
                                                },
                                                "pciId": "a484x000000Zh9pAAC",
                                                "isSelected": true,
                                                "ProductCode": "autoCollision",
                                                "Name": "Collision",
                                                "productName": "Collision",
                                                "isOptional": false,
                                                "lineRecordType": "CoverageSpec",
                                                "instanceKey": "2019 BMW M3_autoCollision",
                                                "quoteLineItemId": "0QL4x000000lAXoGAM",
                                                "vlocity_ins__NeedReprice__c": false,
                                                "needReprice": false,
                                                "vlocity_ins__ProductChildItemSequence__c": 1,
                                                "vlocity_ins__TotalAmount__c": 851.4,
                                                "vlocity_ins__ProductName__c": "Collision",
                                                "vlocity_ins__PricingSource__c": "premiumCOLL",
                                                "LastModifiedDate": "2021-02-03T16:11:02.000+0000",
                                                "TotalPrice": 851.4,
                                                "vlocity_ins__Type__c": "Auto",
                                                "vlocity_ins__RecordTypeName__c": "CoverageSpec",
                                                "UnitPrice": 851.4,
                                                "Price": 851.4,
                                                "QuoteId": "0Q04x000000l6zPCAQ",
                                                "vlocity_ins__AttributeSelectedValues__c": "{\"autoCollDedClmCov\":500}",
                                                "CreatedDate": "2021-02-03T16:11:02.000+0000",
                                                "LineNumber": "00004351",
                                                "vlocity_ins__SubParentItemId__c": "0QL4x000000lAXjGAM",
                                                "vlocity_ins__ParentItemId__c": "0QL4x000000lAXhGAM",
                                                "vlocity_ins__ParentItemId2__c": "0QL4x000000lAXhGAM",
                                                "vlocity_ins__ItemName__c": "2019 BMW M3_autoCollision",
                                                "Product2Id": "01t4x000001y3aDAAQ",
                                                "productId": "01t4x000001y3aDAAQ",
                                                "Id": "0QL4x000000lAXoGAM",
                                                "vlocity_ins__ProductChildItemId__c": "a484x000000Zh9pAAC",
                                                "currencyCode": "USD",
                                                "currencySymbol": "$",
                                                "displaySequence": 1,
                                                "actions": {
                                                    "updateChildLine": {
                                                        "client": {
                                                            "params": {}
                                                        },
                                                        "remote": {
                                                            "params": {
                                                                "methodName": "updateChildLine",
                                                                "quoteLineId": "0QL4x000000lAXoGAM",
                                                                "reprice": true,
                                                                "quoteId": "0Q04x000000l6zPCAQ"
                                                            }
                                                        },
                                                        "rest": {
                                                            "link": null,
                                                            "method": null,
                                                            "params": {}
                                                        }
                                                    }
                                                }
                                            },
                                            {
                                                "attributeCategories": {
                                                    "records": [
                                                        {
                                                            "productAttributes": {
                                                                "records": [
                                                                    {
                                                                        "userValues": 100,
                                                                        "values": [
                                                                            {
                                                                                "value": 100,
                                                                                "disabled": false,
                                                                                "readonly": false,
                                                                                "label": "$100",
                                                                                "id": "0"
                                                                            },
                                                                            {
                                                                                "value": 250,
                                                                                "disabled": false,
                                                                                "readonly": false,
                                                                                "label": "$250",
                                                                                "id": "1"
                                                                            },
                                                                            {
                                                                                "value": 500,
                                                                                "disabled": false,
                                                                                "readonly": false,
                                                                                "label": "$500",
                                                                                "id": "2"
                                                                            },
                                                                            {
                                                                                "value": 750,
                                                                                "disabled": false,
                                                                                "readonly": false,
                                                                                "label": "$750",
                                                                                "id": "3"
                                                                            },
                                                                            {
                                                                                "value": 1000,
                                                                                "disabled": false,
                                                                                "readonly": false,
                                                                                "label": "$1000",
                                                                                "id": "4"
                                                                            },
                                                                            {
                                                                                "value": 1500,
                                                                                "disabled": false,
                                                                                "readonly": false,
                                                                                "label": "$1500",
                                                                                "id": "5"
                                                                            },
                                                                            {
                                                                                "value": 2500,
                                                                                "disabled": false,
                                                                                "readonly": false,
                                                                                "label": "$2500",
                                                                                "id": "6"
                                                                            }
                                                                        ],
                                                                        "isNotTranslatable": false,
                                                                        "cloneable": true,
                                                                        "hidden": false,
                                                                        "hasRules": false,
                                                                        "displaySequence": 0,
                                                                        "label": "Comp Deductible",
                                                                        "attributeId": "a0S4P000009YMK9UAO",
                                                                        "filterable": true,
                                                                        "disabled": false,
                                                                        "readonly": false,
                                                                        "required": false,
                                                                        "multiselect": false,
                                                                        "inputType": "dropdown",
                                                                        "dataType": "currency",
                                                                        "code": "autoCompDedClmCov"
                                                                    }
                                                                ],
                                                                "totalSize": 1
                                                            },
                                                            "id": "a0R4P00000JWzkZUAT",
                                                            "Name": "Auto Terms",
                                                            "Code__c": "autoTerms",
                                                            "displaySequence": 230
                                                        }
                                                    ],
                                                    "totalSize": 1
                                                },
                                                "pciId": "a484x000000Zh9nAAC",
                                                "isSelected": true,
                                                "ProductCode": "autoComp",
                                                "Name": "Comprehensive",
                                                "productName": "Comprehensive",
                                                "isOptional": false,
                                                "lineRecordType": "CoverageSpec",
                                                "instanceKey": "2019 BMW M3_autoComp",
                                                "quoteLineItemId": "0QL4x000000lAXnGAM",
                                                "vlocity_ins__NeedReprice__c": false,
                                                "needReprice": false,
                                                "vlocity_ins__ProductChildItemSequence__c": 2,
                                                "vlocity_ins__TotalAmount__c": 412.8,
                                                "vlocity_ins__ProductName__c": "Comprehensive",
                                                "vlocity_ins__PricingSource__c": "premiumCCD",
                                                "LastModifiedDate": "2021-02-03T16:11:02.000+0000",
                                                "TotalPrice": 412.8,
                                                "vlocity_ins__Type__c": "Auto",
                                                "vlocity_ins__RecordTypeName__c": "CoverageSpec",
                                                "UnitPrice": 412.8,
                                                "Price": 412.8,
                                                "QuoteId": "0Q04x000000l6zPCAQ",
                                                "vlocity_ins__AttributeSelectedValues__c": "{\"autoCompDedClmCov\":100}",
                                                "CreatedDate": "2021-02-03T16:11:02.000+0000",
                                                "LineNumber": "00004350",
                                                "vlocity_ins__SubParentItemId__c": "0QL4x000000lAXjGAM",
                                                "vlocity_ins__ParentItemId__c": "0QL4x000000lAXhGAM",
                                                "vlocity_ins__ParentItemId2__c": "0QL4x000000lAXhGAM",
                                                "vlocity_ins__ItemName__c": "2019 BMW M3_autoComp",
                                                "Product2Id": "01t4x000001y3a1AAA",
                                                "productId": "01t4x000001y3a1AAA",
                                                "Id": "0QL4x000000lAXnGAM",
                                                "vlocity_ins__ProductChildItemId__c": "a484x000000Zh9nAAC",
                                                "currencyCode": "USD",
                                                "currencySymbol": "$",
                                                "displaySequence": 2,
                                                "actions": {
                                                    "updateChildLine": {
                                                        "client": {
                                                            "params": {}
                                                        },
                                                        "remote": {
                                                            "params": {
                                                                "methodName": "updateChildLine",
                                                                "quoteLineId": "0QL4x000000lAXnGAM",
                                                                "reprice": true,
                                                                "quoteId": "0Q04x000000l6zPCAQ"
                                                            }
                                                        },
                                                        "rest": {
                                                            "link": null,
                                                            "method": null,
                                                            "params": {}
                                                        }
                                                    }
                                                }
                                            },
                                            {
                                                "attributeCategories": {
                                                    "records": [
                                                        {
                                                            "productAttributes": {
                                                                "records": [
                                                                    {
                                                                        "userValues": 1000,
                                                                        "values": [
                                                                            {
                                                                                "value": 1000,
                                                                                "disabled": false,
                                                                                "readonly": false,
                                                                                "label": "$1000",
                                                                                "id": "0"
                                                                            },
                                                                            {
                                                                                "value": 2000,
                                                                                "disabled": false,
                                                                                "readonly": false,
                                                                                "label": "$2000",
                                                                                "id": "1"
                                                                            },
                                                                            {
                                                                                "value": 5000,
                                                                                "disabled": false,
                                                                                "readonly": false,
                                                                                "label": "$5000",
                                                                                "id": "2"
                                                                            }
                                                                        ],
                                                                        "isNotTranslatable": false,
                                                                        "cloneable": true,
                                                                        "hidden": false,
                                                                        "hasRules": false,
                                                                        "displaySequence": 0,
                                                                        "label": "Med Pay Person Limit",
                                                                        "attributeId": "a0S4P000009YMKCUA4",
                                                                        "filterable": true,
                                                                        "disabled": false,
                                                                        "readonly": false,
                                                                        "required": false,
                                                                        "multiselect": false,
                                                                        "inputType": "dropdown",
                                                                        "dataType": "currency",
                                                                        "code": "autoMedPayLimClmCov"
                                                                    }
                                                                ],
                                                                "totalSize": 1
                                                            },
                                                            "id": "a0R4P00000JWzkZUAT",
                                                            "Name": "Auto Terms",
                                                            "Code__c": "autoTerms",
                                                            "displaySequence": 230
                                                        }
                                                    ],
                                                    "totalSize": 1
                                                },
                                                "pciId": "a484x000000Zh9oAAC",
                                                "isSelected": true,
                                                "ProductCode": "autoMedical",
                                                "Name": "Medical Payments",
                                                "productName": "Medical Payments",
                                                "isOptional": false,
                                                "lineRecordType": "CoverageSpec",
                                                "instanceKey": "2019 BMW M3_autoMedical",
                                                "quoteLineItemId": "0QL4x000000lAXmGAM",
                                                "vlocity_ins__NeedReprice__c": false,
                                                "needReprice": false,
                                                "vlocity_ins__ProductChildItemSequence__c": 3,
                                                "vlocity_ins__TotalAmount__c": 37.37,
                                                "vlocity_ins__ProductName__c": "Medical Payments",
                                                "vlocity_ins__PricingSource__c": "premiumMED",
                                                "LastModifiedDate": "2021-02-03T16:11:02.000+0000",
                                                "TotalPrice": 37.37,
                                                "vlocity_ins__Type__c": "Auto",
                                                "vlocity_ins__RecordTypeName__c": "CoverageSpec",
                                                "UnitPrice": 37.37,
                                                "Price": 37.37,
                                                "QuoteId": "0Q04x000000l6zPCAQ",
                                                "vlocity_ins__AttributeSelectedValues__c": "{\"autoMedPayLimClmCov\":1000}",
                                                "CreatedDate": "2021-02-03T16:11:02.000+0000",
                                                "LineNumber": "00004349",
                                                "vlocity_ins__SubParentItemId__c": "0QL4x000000lAXjGAM",
                                                "vlocity_ins__ParentItemId__c": "0QL4x000000lAXhGAM",
                                                "vlocity_ins__ParentItemId2__c": "0QL4x000000lAXhGAM",
                                                "vlocity_ins__ItemName__c": "2019 BMW M3_autoMedical",
                                                "Product2Id": "01t4x000001y3aKAAQ",
                                                "productId": "01t4x000001y3aKAAQ",
                                                "Id": "0QL4x000000lAXmGAM",
                                                "vlocity_ins__ProductChildItemId__c": "a484x000000Zh9oAAC",
                                                "currencyCode": "USD",
                                                "currencySymbol": "$",
                                                "displaySequence": 3,
                                                "actions": {
                                                    "updateChildLine": {
                                                        "client": {
                                                            "params": {}
                                                        },
                                                        "remote": {
                                                            "params": {
                                                                "methodName": "updateChildLine",
                                                                "quoteLineId": "0QL4x000000lAXmGAM",
                                                                "reprice": true,
                                                                "quoteId": "0Q04x000000l6zPCAQ"
                                                            }
                                                        },
                                                        "rest": {
                                                            "link": null,
                                                            "method": null,
                                                            "params": {}
                                                        }
                                                    }
                                                }
                                            },
                                            {
                                                "attributeCategories": {
                                                    "records": [
                                                        {
                                                            "productAttributes": {
                                                                "records": [
                                                                    {
                                                                        "userValues": "50/100",
                                                                        "values": [
                                                                            {
                                                                                "value": "15/30",
                                                                                "disabled": false,
                                                                                "readonly": false,
                                                                                "label": "$15,000 / $30,000",
                                                                                "id": "0"
                                                                            },
                                                                            {
                                                                                "value": "25/50",
                                                                                "disabled": false,
                                                                                "readonly": false,
                                                                                "label": "$25,000 / $50,000",
                                                                                "id": "1"
                                                                            },
                                                                            {
                                                                                "value": "30/60",
                                                                                "disabled": false,
                                                                                "readonly": false,
                                                                                "label": "$30,000 / $60,000",
                                                                                "id": "2"
                                                                            },
                                                                            {
                                                                                "value": "50/100",
                                                                                "disabled": false,
                                                                                "readonly": false,
                                                                                "label": "$50,000 / $100,000",
                                                                                "id": "3"
                                                                            },
                                                                            {
                                                                                "value": "100/300",
                                                                                "disabled": false,
                                                                                "readonly": false,
                                                                                "label": "$100,000 / $300,000",
                                                                                "id": "4"
                                                                            },
                                                                            {
                                                                                "value": "250/500",
                                                                                "disabled": false,
                                                                                "readonly": false,
                                                                                "label": "$250,000 / $500,000",
                                                                                "id": "5"
                                                                            },
                                                                            {
                                                                                "value": "500/500",
                                                                                "disabled": false,
                                                                                "readonly": false,
                                                                                "label": "$500,000 / $500,000",
                                                                                "id": "6"
                                                                            },
                                                                            {
                                                                                "value": "500/1000",
                                                                                "disabled": false,
                                                                                "readonly": false,
                                                                                "label": "$500,000 / $1,000,000",
                                                                                "id": "7"
                                                                            }
                                                                        ],
                                                                        "isNotTranslatable": false,
                                                                        "cloneable": true,
                                                                        "hidden": false,
                                                                        "hasRules": false,
                                                                        "displaySequence": 0,
                                                                        "label": "UM Limit",
                                                                        "attributeId": "a0S4P000009YMKGUA4",
                                                                        "filterable": true,
                                                                        "disabled": false,
                                                                        "readonly": false,
                                                                        "required": false,
                                                                        "multiselect": false,
                                                                        "inputType": "dropdown",
                                                                        "dataType": "text",
                                                                        "code": "autoUMLimit"
                                                                    }
                                                                ],
                                                                "totalSize": 1
                                                            },
                                                            "id": "a0R4P00000JWzkZUAT",
                                                            "Name": "Auto Terms",
                                                            "Code__c": "autoTerms",
                                                            "displaySequence": 230
                                                        }
                                                    ],
                                                    "totalSize": 1
                                                },
                                                "pciId": "a484x000000Zh9sAAC",
                                                "isSelected": true,
                                                "ProductCode": "autoUM",
                                                "Name": "Uninsured Motorist",
                                                "productName": "Uninsured Motorist",
                                                "isOptional": false,
                                                "lineRecordType": "CoverageSpec",
                                                "instanceKey": "2019 BMW M3_autoUM",
                                                "quoteLineItemId": "0QL4x000000lAXlGAM",
                                                "vlocity_ins__NeedReprice__c": false,
                                                "needReprice": false,
                                                "vlocity_ins__ProductChildItemSequence__c": 4,
                                                "vlocity_ins__TotalAmount__c": 68.22,
                                                "vlocity_ins__ProductName__c": "Uninsured Motorist",
                                                "vlocity_ins__PricingSource__c": "premiumUM",
                                                "LastModifiedDate": "2021-02-03T16:11:02.000+0000",
                                                "TotalPrice": 68.22,
                                                "vlocity_ins__Type__c": "Auto",
                                                "vlocity_ins__RecordTypeName__c": "CoverageSpec",
                                                "UnitPrice": 68.22,
                                                "Price": 68.22,
                                                "QuoteId": "0Q04x000000l6zPCAQ",
                                                "vlocity_ins__AttributeSelectedValues__c": "{\"autoUMLimit\":\"50/100\"}",
                                                "CreatedDate": "2021-02-03T16:11:02.000+0000",
                                                "LineNumber": "00004348",
                                                "vlocity_ins__SubParentItemId__c": "0QL4x000000lAXjGAM",
                                                "vlocity_ins__ParentItemId__c": "0QL4x000000lAXhGAM",
                                                "vlocity_ins__ParentItemId2__c": "0QL4x000000lAXhGAM",
                                                "vlocity_ins__ItemName__c": "2019 BMW M3_autoUM",
                                                "Product2Id": "01t4x000001y3ZzAAI",
                                                "productId": "01t4x000001y3ZzAAI",
                                                "Id": "0QL4x000000lAXlGAM",
                                                "vlocity_ins__ProductChildItemId__c": "a484x000000Zh9sAAC",
                                                "currencyCode": "USD",
                                                "currencySymbol": "$",
                                                "displaySequence": 4,
                                                "actions": {
                                                    "updateChildLine": {
                                                        "client": {
                                                            "params": {}
                                                        },
                                                        "remote": {
                                                            "params": {
                                                                "methodName": "updateChildLine",
                                                                "quoteLineId": "0QL4x000000lAXlGAM",
                                                                "reprice": true,
                                                                "quoteId": "0Q04x000000l6zPCAQ"
                                                            }
                                                        },
                                                        "rest": {
                                                            "link": null,
                                                            "method": null,
                                                            "params": {}
                                                        }
                                                    }
                                                }
                                            },
                                            {
                                                "attributeCategories": {
                                                    "records": [
                                                        {
                                                            "productAttributes": {
                                                                "records": [
                                                                    {
                                                                        "userValues": 2000,
                                                                        "values": [
                                                                            {
                                                                                "disabled": true,
                                                                                "readonly": true
                                                                            }
                                                                        ],
                                                                        "isNotTranslatable": false,
                                                                        "cloneable": true,
                                                                        "hidden": false,
                                                                        "hasRules": false,
                                                                        "displaySequence": 0,
                                                                        "label": "Rental Limit",
                                                                        "attributeId": "a0S4P000009YMKFUA4",
                                                                        "filterable": true,
                                                                        "disabled": true,
                                                                        "readonly": true,
                                                                        "required": false,
                                                                        "multiselect": false,
                                                                        "inputType": "number",
                                                                        "dataType": "currency",
                                                                        "code": "autoRentalLimClmCov"
                                                                    },
                                                                    {
                                                                        "userValues": 30,
                                                                        "values": [
                                                                            {
                                                                                "disabled": true,
                                                                                "readonly": true
                                                                            }
                                                                        ],
                                                                        "isNotTranslatable": false,
                                                                        "cloneable": true,
                                                                        "hidden": false,
                                                                        "hasRules": false,
                                                                        "displaySequence": 1,
                                                                        "label": "Number of Days",
                                                                        "attributeId": "a0S4P000009YMKEUA4",
                                                                        "filterable": true,
                                                                        "disabled": true,
                                                                        "readonly": true,
                                                                        "required": false,
                                                                        "multiselect": false,
                                                                        "inputType": "number",
                                                                        "dataType": "number",
                                                                        "code": "autoRentalDays"
                                                                    }
                                                                ],
                                                                "totalSize": 2
                                                            },
                                                            "id": "a0R4P00000JWzkZUAT",
                                                            "Name": "Auto Terms",
                                                            "Code__c": "autoTerms",
                                                            "displaySequence": 230
                                                        }
                                                    ],
                                                    "totalSize": 1
                                                },
                                                "vlocity_ins__Type__c": "Auto",
                                                "vlocity_ins__PricingSource__c": "premiumRental",
                                                "recordType": "CoverageSpec",
                                                "vlocity_ins__RecordTypeName__c": "CoverageSpec",
                                                "pciId": "a484x000000Zh9tAAC",
                                                "isSelected": false,
                                                "isOptional": true,
                                                "Name": "Rental Car",
                                                "ProductCode": "autoRental",
                                                "productName": "Rental Car",
                                                "productId": "01t4x000001y3aRAAQ",
                                                "displaySequence": 5
                                            }
                                        ],
                                        "totalSize": 6
                                    },
                                    "attributeCategories": {
                                        "records": [
                                            {
                                                "productAttributes": {
                                                    "records": [
                                                        {
                                                            "userValues": 45000,
                                                            "values": [
                                                                {
                                                                    "disabled": true,
                                                                    "readonly": true
                                                                }
                                                            ],
                                                            "isNotTranslatable": false,
                                                            "cloneable": true,
                                                            "hidden": false,
                                                            "hasRules": false,
                                                            "displaySequence": 0,
                                                            "label": "Value",
                                                            "attributeId": "a0S4P000004VofbUAC",
                                                            "filterable": true,
                                                            "disabled": true,
                                                            "readonly": true,
                                                            "required": false,
                                                            "multiselect": false,
                                                            "inputType": "number",
                                                            "dataType": "currency",
                                                            "code": "avValue"
                                                        },
                                                        {
                                                            "userValues": false,
                                                            "values": [
                                                                {
                                                                    "disabled": true,
                                                                    "readonly": true
                                                                }
                                                            ],
                                                            "isNotTranslatable": false,
                                                            "cloneable": true,
                                                            "hidden": false,
                                                            "hasRules": false,
                                                            "displaySequence": 1,
                                                            "label": "Alternative Fuel",
                                                            "attributeId": "a0S4P000004VofCUAS",
                                                            "filterable": true,
                                                            "disabled": true,
                                                            "readonly": true,
                                                            "required": false,
                                                            "multiselect": false,
                                                            "inputType": "checkbox",
                                                            "dataType": "text",
                                                            "code": "avAltFuel"
                                                        },
                                                        {
                                                            "userValues": false,
                                                            "values": [
                                                                {
                                                                    "disabled": true,
                                                                    "readonly": true
                                                                }
                                                            ],
                                                            "isNotTranslatable": false,
                                                            "cloneable": true,
                                                            "hidden": false,
                                                            "hasRules": false,
                                                            "displaySequence": 2,
                                                            "label": "Anti Theft",
                                                            "attributeId": "a0S4P000004VofDUAS",
                                                            "filterable": true,
                                                            "disabled": true,
                                                            "readonly": true,
                                                            "required": false,
                                                            "multiselect": false,
                                                            "inputType": "checkbox",
                                                            "dataType": "text",
                                                            "code": "avAntiTheft"
                                                        },
                                                        {
                                                            "userValues": false,
                                                            "values": [
                                                                {
                                                                    "disabled": true,
                                                                    "readonly": true
                                                                }
                                                            ],
                                                            "isNotTranslatable": false,
                                                            "cloneable": true,
                                                            "hidden": false,
                                                            "hasRules": false,
                                                            "displaySequence": 3,
                                                            "label": "Brakes",
                                                            "attributeId": "a0S4P000004VofFUAS",
                                                            "filterable": true,
                                                            "disabled": true,
                                                            "readonly": true,
                                                            "required": false,
                                                            "multiselect": false,
                                                            "inputType": "checkbox",
                                                            "dataType": "text",
                                                            "code": "avBrakes"
                                                        },
                                                        {
                                                            "userValues": null,
                                                            "values": [
                                                                {
                                                                    "disabled": true,
                                                                    "readonly": true
                                                                }
                                                            ],
                                                            "isNotTranslatable": false,
                                                            "cloneable": true,
                                                            "hidden": false,
                                                            "hasRules": false,
                                                            "displaySequence": 4,
                                                            "label": "Claim Frequency",
                                                            "attributeId": "a0S4P000004VofGUAS",
                                                            "filterable": true,
                                                            "disabled": true,
                                                            "readonly": true,
                                                            "required": false,
                                                            "multiselect": false,
                                                            "inputType": "number",
                                                            "dataType": "number",
                                                            "code": "avClaimFreq"
                                                        },
                                                        {
                                                            "userValues": null,
                                                            "values": [
                                                                {
                                                                    "disabled": true,
                                                                    "readonly": true
                                                                }
                                                            ],
                                                            "isNotTranslatable": false,
                                                            "cloneable": true,
                                                            "hidden": false,
                                                            "hasRules": false,
                                                            "displaySequence": 5,
                                                            "label": "Claim Severity",
                                                            "attributeId": "a0S4P000004VofHUAS",
                                                            "filterable": true,
                                                            "disabled": true,
                                                            "readonly": true,
                                                            "required": false,
                                                            "multiselect": false,
                                                            "inputType": "number",
                                                            "dataType": "number",
                                                            "code": "avClaimSev"
                                                        },
                                                        {
                                                            "userValues": null,
                                                            "values": [
                                                                {
                                                                    "disabled": true,
                                                                    "readonly": true
                                                                }
                                                            ],
                                                            "isNotTranslatable": false,
                                                            "cloneable": true,
                                                            "hidden": false,
                                                            "hasRules": false,
                                                            "displaySequence": 6,
                                                            "label": "License Number",
                                                            "attributeId": "a0S4P000004VofLUAS",
                                                            "filterable": true,
                                                            "disabled": true,
                                                            "readonly": true,
                                                            "required": false,
                                                            "multiselect": false,
                                                            "inputType": "text",
                                                            "dataType": "text",
                                                            "code": "avLicNum"
                                                        },
                                                        {
                                                            "userValues": null,
                                                            "values": [
                                                                {
                                                                    "disabled": true,
                                                                    "readonly": true
                                                                }
                                                            ],
                                                            "isNotTranslatable": false,
                                                            "cloneable": true,
                                                            "hidden": false,
                                                            "hasRules": false,
                                                            "displaySequence": 7,
                                                            "label": "License State",
                                                            "attributeId": "a0S4P000004VofMUAS",
                                                            "filterable": true,
                                                            "disabled": true,
                                                            "readonly": true,
                                                            "required": false,
                                                            "multiselect": false,
                                                            "inputType": "text",
                                                            "dataType": "text",
                                                            "code": "avLicState"
                                                        },
                                                        {
                                                            "userValues": "BMW",
                                                            "values": [
                                                                {
                                                                    "disabled": true,
                                                                    "readonly": true
                                                                }
                                                            ],
                                                            "isNotTranslatable": false,
                                                            "cloneable": true,
                                                            "hidden": false,
                                                            "hasRules": false,
                                                            "displaySequence": 8,
                                                            "label": "Make",
                                                            "attributeId": "a0S4P000004VofNUAS",
                                                            "filterable": true,
                                                            "disabled": true,
                                                            "readonly": true,
                                                            "required": false,
                                                            "multiselect": false,
                                                            "inputType": "text",
                                                            "dataType": "text",
                                                            "code": "avMake"
                                                        },
                                                        {
                                                            "userValues": "M3",
                                                            "values": [
                                                                {
                                                                    "disabled": true,
                                                                    "readonly": true
                                                                }
                                                            ],
                                                            "isNotTranslatable": false,
                                                            "cloneable": true,
                                                            "hidden": false,
                                                            "hasRules": false,
                                                            "displaySequence": 9,
                                                            "label": "Model",
                                                            "attributeId": "a0S4P000004VofPUAS",
                                                            "filterable": true,
                                                            "disabled": true,
                                                            "readonly": true,
                                                            "required": false,
                                                            "multiselect": false,
                                                            "inputType": "text",
                                                            "dataType": "text",
                                                            "code": "avModel"
                                                        },
                                                        {
                                                            "userValues": null,
                                                            "values": [
                                                                {
                                                                    "disabled": true,
                                                                    "readonly": true
                                                                }
                                                            ],
                                                            "isNotTranslatable": false,
                                                            "cloneable": true,
                                                            "hidden": false,
                                                            "hasRules": false,
                                                            "displaySequence": 10,
                                                            "label": "Rated Driver - BIPD",
                                                            "attributeId": "a0S4P000004VofQUAS",
                                                            "filterable": true,
                                                            "disabled": true,
                                                            "readonly": true,
                                                            "required": false,
                                                            "multiselect": false,
                                                            "inputType": "number",
                                                            "dataType": "number",
                                                            "code": "avRatedDriver-BIPD"
                                                        },
                                                        {
                                                            "userValues": null,
                                                            "values": [
                                                                {
                                                                    "disabled": true,
                                                                    "readonly": true
                                                                }
                                                            ],
                                                            "isNotTranslatable": false,
                                                            "cloneable": true,
                                                            "hidden": false,
                                                            "hasRules": false,
                                                            "displaySequence": 11,
                                                            "label": "Rated Driver - Comprehensive",
                                                            "attributeId": "a0S4P000004VofSUAS",
                                                            "filterable": true,
                                                            "disabled": true,
                                                            "readonly": true,
                                                            "required": false,
                                                            "multiselect": false,
                                                            "inputType": "number",
                                                            "dataType": "number",
                                                            "code": "avRatedDriver-COMP"
                                                        },
                                                        {
                                                            "userValues": null,
                                                            "values": [
                                                                {
                                                                    "disabled": true,
                                                                    "readonly": true
                                                                }
                                                            ],
                                                            "isNotTranslatable": false,
                                                            "cloneable": true,
                                                            "hidden": false,
                                                            "hasRules": false,
                                                            "displaySequence": 12,
                                                            "label": "Rated Driver - Medical Payments",
                                                            "attributeId": "a0S4P000004VofTUAS",
                                                            "filterable": true,
                                                            "disabled": true,
                                                            "readonly": true,
                                                            "required": false,
                                                            "multiselect": false,
                                                            "inputType": "number",
                                                            "dataType": "number",
                                                            "code": "avRatedDriver-MED"
                                                        },
                                                        {
                                                            "userValues": null,
                                                            "values": [
                                                                {
                                                                    "disabled": true,
                                                                    "readonly": true
                                                                }
                                                            ],
                                                            "isNotTranslatable": false,
                                                            "cloneable": true,
                                                            "hidden": false,
                                                            "hasRules": false,
                                                            "displaySequence": 13,
                                                            "label": "Rated Driver - Uninsured Motorist",
                                                            "attributeId": "a0S4P000004VofUUAS",
                                                            "filterable": true,
                                                            "disabled": true,
                                                            "readonly": true,
                                                            "required": false,
                                                            "multiselect": false,
                                                            "inputType": "number",
                                                            "dataType": "number",
                                                            "code": "avRatedDriver-UM"
                                                        },
                                                        {
                                                            "userValues": null,
                                                            "values": [
                                                                {
                                                                    "disabled": true,
                                                                    "readonly": true
                                                                }
                                                            ],
                                                            "isNotTranslatable": false,
                                                            "cloneable": true,
                                                            "hidden": false,
                                                            "hasRules": false,
                                                            "displaySequence": 14,
                                                            "label": "Rated Driver Name",
                                                            "attributeId": "a0S4P000004VofVUAS",
                                                            "filterable": true,
                                                            "disabled": true,
                                                            "readonly": true,
                                                            "required": false,
                                                            "multiselect": false,
                                                            "inputType": "text",
                                                            "dataType": "text",
                                                            "code": "avRatedDriverName"
                                                        },
                                                        {
                                                            "userValues": false,
                                                            "values": [
                                                                {
                                                                    "disabled": true,
                                                                    "readonly": true
                                                                }
                                                            ],
                                                            "isNotTranslatable": false,
                                                            "cloneable": true,
                                                            "hidden": false,
                                                            "hasRules": false,
                                                            "displaySequence": 15,
                                                            "label": "Restraints",
                                                            "attributeId": "a0S4P000004VofWUAS",
                                                            "filterable": true,
                                                            "disabled": true,
                                                            "readonly": true,
                                                            "required": false,
                                                            "multiselect": false,
                                                            "inputType": "checkbox",
                                                            "dataType": "text",
                                                            "code": "avRestraints"
                                                        },
                                                        {
                                                            "userValues": true,
                                                            "values": [
                                                                {
                                                                    "disabled": true,
                                                                    "readonly": true
                                                                }
                                                            ],
                                                            "isNotTranslatable": false,
                                                            "cloneable": true,
                                                            "hidden": false,
                                                            "hasRules": false,
                                                            "displaySequence": 16,
                                                            "label": "Stablization",
                                                            "attributeId": "a0S4P000004VofXUAS",
                                                            "filterable": true,
                                                            "disabled": true,
                                                            "readonly": true,
                                                            "required": false,
                                                            "multiselect": false,
                                                            "inputType": "checkbox",
                                                            "dataType": "text",
                                                            "code": "avStabilization"
                                                        },
                                                        {
                                                            "userValues": false,
                                                            "values": [
                                                                {
                                                                    "disabled": false,
                                                                    "readonly": false
                                                                }
                                                            ],
                                                            "isNotTranslatable": false,
                                                            "cloneable": true,
                                                            "hidden": false,
                                                            "hasRules": false,
                                                            "displaySequence": 17,
                                                            "label": "Historic",
                                                            "attributeId": "a0S4P000004VofKUAS",
                                                            "filterable": true,
                                                            "disabled": false,
                                                            "readonly": false,
                                                            "required": false,
                                                            "multiselect": false,
                                                            "inputType": "checkbox",
                                                            "dataType": "text",
                                                            "code": "avHistoric"
                                                        },
                                                        {
                                                            "userValues": null,
                                                            "values": [
                                                                {
                                                                    "disabled": true,
                                                                    "readonly": true
                                                                }
                                                            ],
                                                            "isNotTranslatable": false,
                                                            "cloneable": true,
                                                            "hidden": false,
                                                            "hasRules": false,
                                                            "displaySequence": 18,
                                                            "label": "Style",
                                                            "attributeId": "a0S4P000004VofYUAS",
                                                            "filterable": true,
                                                            "disabled": true,
                                                            "readonly": true,
                                                            "required": false,
                                                            "multiselect": false,
                                                            "inputType": "text",
                                                            "dataType": "text",
                                                            "code": "avStyle"
                                                        },
                                                        {
                                                            "userValues": null,
                                                            "values": [
                                                                {
                                                                    "disabled": true,
                                                                    "readonly": true
                                                                }
                                                            ],
                                                            "isNotTranslatable": false,
                                                            "cloneable": true,
                                                            "hidden": false,
                                                            "hasRules": false,
                                                            "displaySequence": 19,
                                                            "label": "Symbol",
                                                            "attributeId": "a0S4P000004VofZUAS",
                                                            "filterable": true,
                                                            "disabled": true,
                                                            "readonly": true,
                                                            "required": false,
                                                            "multiselect": false,
                                                            "inputType": "text",
                                                            "dataType": "text",
                                                            "code": "avSymbol"
                                                        },
                                                        {
                                                            "userValues": null,
                                                            "values": [
                                                                {
                                                                    "disabled": true,
                                                                    "readonly": true
                                                                }
                                                            ],
                                                            "isNotTranslatable": false,
                                                            "cloneable": true,
                                                            "hidden": false,
                                                            "hasRules": false,
                                                            "displaySequence": 20,
                                                            "label": "Color",
                                                            "attributeId": "a0S4P000004VofIUAS",
                                                            "filterable": true,
                                                            "disabled": true,
                                                            "readonly": true,
                                                            "required": false,
                                                            "multiselect": false,
                                                            "inputType": "text",
                                                            "dataType": "text",
                                                            "code": "avColor"
                                                        },
                                                        {
                                                            "userValues": null,
                                                            "values": [
                                                                {
                                                                    "disabled": true,
                                                                    "readonly": true
                                                                }
                                                            ],
                                                            "isNotTranslatable": false,
                                                            "cloneable": true,
                                                            "hidden": false,
                                                            "hasRules": false,
                                                            "displaySequence": 21,
                                                            "label": "VIN",
                                                            "attributeId": "a0S4P000004VofaUAC",
                                                            "filterable": true,
                                                            "disabled": true,
                                                            "readonly": true,
                                                            "required": false,
                                                            "multiselect": false,
                                                            "inputType": "text",
                                                            "dataType": "text",
                                                            "code": "avVIN"
                                                        },
                                                        {
                                                            "userValues": "2019",
                                                            "values": [
                                                                {
                                                                    "disabled": true,
                                                                    "readonly": true
                                                                }
                                                            ],
                                                            "isNotTranslatable": false,
                                                            "cloneable": true,
                                                            "hidden": false,
                                                            "hasRules": false,
                                                            "displaySequence": 22,
                                                            "label": "Year",
                                                            "attributeId": "a0S4P000004VofcUAC",
                                                            "filterable": true,
                                                            "disabled": true,
                                                            "readonly": true,
                                                            "required": false,
                                                            "multiselect": false,
                                                            "inputType": "text",
                                                            "dataType": "text",
                                                            "code": "avYear"
                                                        },
                                                        {
                                                            "userValues": 10000,
                                                            "values": [
                                                                {
                                                                    "disabled": true,
                                                                    "readonly": true
                                                                }
                                                            ],
                                                            "isNotTranslatable": false,
                                                            "cloneable": true,
                                                            "hidden": false,
                                                            "hasRules": false,
                                                            "displaySequence": 23,
                                                            "label": "Annual Mileage",
                                                            "attributeId": "a0S4P000004VofOUAS",
                                                            "filterable": true,
                                                            "disabled": true,
                                                            "readonly": true,
                                                            "required": false,
                                                            "multiselect": false,
                                                            "inputType": "number",
                                                            "dataType": "number",
                                                            "code": "avMileage"
                                                        },
                                                        {
                                                            "userValues": "Sedan/Saloon",
                                                            "values": [
                                                                {
                                                                    "disabled": true,
                                                                    "readonly": true
                                                                }
                                                            ],
                                                            "isNotTranslatable": false,
                                                            "cloneable": true,
                                                            "hidden": false,
                                                            "hasRules": false,
                                                            "displaySequence": 24,
                                                            "label": "Body Type",
                                                            "attributeId": "a0S4P000004VofEUAS",
                                                            "filterable": true,
                                                            "disabled": true,
                                                            "readonly": true,
                                                            "required": false,
                                                            "multiselect": false,
                                                            "inputType": "text",
                                                            "dataType": "text",
                                                            "code": "avBodyType"
                                                        },
                                                        {
                                                            "userValues": "94110",
                                                            "values": [
                                                                {
                                                                    "disabled": true,
                                                                    "readonly": true
                                                                }
                                                            ],
                                                            "isNotTranslatable": false,
                                                            "cloneable": true,
                                                            "hidden": false,
                                                            "hasRules": false,
                                                            "displaySequence": 25,
                                                            "label": "Garage Location (Postal Code)",
                                                            "attributeId": "a0S4P000004VofJUAS",
                                                            "filterable": true,
                                                            "disabled": true,
                                                            "readonly": true,
                                                            "required": false,
                                                            "multiselect": false,
                                                            "inputType": "text",
                                                            "dataType": "text",
                                                            "code": "avGaragePostalCode"
                                                        },
                                                        {
                                                            "userValues": null,
                                                            "values": [
                                                                {
                                                                    "disabled": true,
                                                                    "readonly": true
                                                                }
                                                            ],
                                                            "isNotTranslatable": false,
                                                            "cloneable": true,
                                                            "hidden": false,
                                                            "hasRules": false,
                                                            "displaySequence": 26,
                                                            "label": "Rated Driver - Collision",
                                                            "attributeId": "a0S4P000004VofRUAS",
                                                            "filterable": true,
                                                            "disabled": true,
                                                            "readonly": true,
                                                            "required": false,
                                                            "multiselect": false,
                                                            "inputType": "number",
                                                            "dataType": "number",
                                                            "code": "avRatedDriver-COLL"
                                                        }
                                                    ],
                                                    "totalSize": 27
                                                },
                                                "id": "a0R4P00000J2MJyUAN",
                                                "Name": "Auto Vehicle",
                                                "Code__c": "autoVehicle",
                                                "displaySequence": 210
                                            }
                                        ],
                                        "totalSize": 1
                                    },
                                    "hasCoverages": true,
                                    "pciId": "a484x000000Zh9qAAC",
                                    "lineRecordType": "InsuredItemSpec",
                                    "vlocity_ins__PricingFormula__c": "premiumBIPD + premiumCOLL + premiumCCD + premiumMED + premiumUM+premiumRental",
                                    "isPrimary": true,
                                    "instanceKey": "2019 BMW M3",
                                    "Name": "2019 BMW M3",
                                    "quoteLineItemId": "0QL4x000000lAXjGAM",
                                    "ProductCode": "autoVehicle",
                                    "hasAttributes": true,
                                    "needCustomProcess": false,
                                    "productName": "Vehicle",
                                    "maxCount": 1,
                                    "minCount": 1,
                                    "vlocity_ins__NeedReprice__c": false,
                                    "needReprice": false,
                                    "vlocity_ins__ProductChildItemSequence__c": 1,
                                    "vlocity_ins__TotalAmount__c": 1386.29,
                                    "vlocity_ins__ProductName__c": "Vehicle",
                                    "LastModifiedDate": "2021-02-03T16:11:02.000+0000",
                                    "TotalPrice": 1386.29,
                                    "vlocity_ins__Type__c": "Auto",
                                    "vlocity_ins__RecordTypeName__c": "InsuredItemSpec",
                                    "UnitPrice": 1386.29,
                                    "Price": 1386.29,
                                    "QuoteId": "0Q04x000000l6zPCAQ",
                                    "vlocity_ins__AttributeSelectedValues__c": "{\"avAltFuel\":false,\"avAntiTheft\":false,\"avYear\":\"2019\",\"avMileage\":10000,\"avValue\":45000,\"avMake\":\"BMW\",\"isParent\":true,\"avGaragePostalCode\":\"94110\",\"avStabilization\":true,\"avModel\":\"M3\",\"avHistoric\":false,\"avBrakes\":false,\"avBodyType\":\"Sedan/Saloon\",\"ProductCode\":\"autoVehicle\",\"avRestraints\":false}",
                                    "CreatedDate": "2021-02-03T16:11:02.000+0000",
                                    "LineNumber": "00004346",
                                    "vlocity_ins__SubParentItemId__c": "0QL4x000000lAXhGAM",
                                    "vlocity_ins__ParentItemId__c": "0QL4x000000lAXhGAM",
                                    "vlocity_ins__ParentItemId2__c": "0QL4x000000lAXhGAM",
                                    "vlocity_ins__ItemName__c": "2019 BMW M3",
                                    "Product2Id": "01t4x000001y3a0AAA",
                                    "productId": "01t4x000001y3a0AAA",
                                    "Id": "0QL4x000000lAXjGAM",
                                    "vlocity_ins__ProductChildItemId__c": "a484x000000Zh9qAAC",
                                    "currencyCode": "USD",
                                    "currencySymbol": "$",
                                    "displaySequence": 1,
                                    "actions": {
                                        "deleteChildLine": {
                                            "client": {
                                                "params": {}
                                            },
                                            "remote": {
                                                "params": {
                                                    "methodName": "deleteChildLine",
                                                    "quoteLineId": "0QL4x000000lAXjGAM",
                                                    "itemRecordType": "InsuredItemSpec",
                                                    "minCount": 1
                                                }
                                            },
                                            "rest": {
                                                "link": null,
                                                "method": null,
                                                "params": {}
                                            }
                                        },
                                        "updateChildLine": {
                                            "client": {
                                                "params": {}
                                            },
                                            "remote": {
                                                "params": {
                                                    "methodName": "updateChildLine",
                                                    "quoteLineId": "0QL4x000000lAXjGAM",
                                                    "reprice": true,
                                                    "quoteId": "0Q04x000000l6zPCAQ"
                                                }
                                            },
                                            "rest": {
                                                "link": null,
                                                "method": null,
                                                "params": {}
                                            }
                                        }
                                    }
                                }
                            ],
                            "actions": {
                                "updateAllCoverageAttribute": {
                                    "client": {
                                        "params": {}
                                    },
                                    "remote": {
                                        "params": {
                                            "methodName": "updateAllChildLines",
                                            "quoteId": "0Q04x000000l6zPCAQ",
                                            "reprice": true
                                        }
                                    },
                                    "rest": {
                                        "link": null,
                                        "method": null,
                                        "params": {}
                                    }
                                },
                                "getCandidateChildProducts": {
                                    "client": {
                                        "params": {}
                                    },
                                    "remote": {
                                        "params": {
                                            "methodName": "getListChildProducts",
                                            "quoteId": "0Q04x000000l6zPCAQ",
                                            "prodRecordType": "InsuredItemSpec"
                                        }
                                    },
                                    "rest": {
                                        "link": null,
                                        "method": null,
                                        "params": {}
                                    }
                                }
                            },
                            "totalSize": 3
                        },
                        "hasCoverages": false,
                        "coverageCount": 0,
                        "totalTaxFeeAmount": 65.4218,
                        "feeAmount": 25,
                        "taxAmount": 40.4218,
                        "taxesAndFees": [
                            {
                                "Id": "a4d4x000000szpuAAA",
                                "AdjustmentType__c": "Fee",
                                "Amount__c": 25,
                                "PriceListEntryId__c": "a3u4x000000cabtAAA",
                                "PriceListEntryName__c": "573608e0-7b1c-9b66-a435-d584218c5305",
                                "calculatedAmount": 25,
                                "currencyCode": "USD",
                                "currencySymbol": "$"
                            },
                            {
                                "Id": "a4d4x000000szpvAAA",
                                "AdjustmentType__c": "Tax",
                                "Amount__c": 27.85,
                                "PriceListEntryId__c": "a3u4x000000cabuAAA",
                                "PriceListEntryName__c": "7457f382-f935-3308-3429-24d9dfac88f4",
                                "calculatedAmount": 27.85,
                                "currencyCode": "USD",
                                "currencySymbol": "$"
                            },
                            {
                                "Id": "a4d4x000000szpwAAA",
                                "AdjustmentType__c": "Tax",
                                "Amount__c": 0,
                                "PriceListEntryId__c": "a3u4x000000cabvAAA",
                                "PriceListEntryName__c": "7eee88c5-37d5-3991-02db-37ef3343982f",
                                "calculatedAmount": 0,
                                "currencyCode": "USD",
                                "currencySymbol": "$"
                            },
                            {
                                "Id": "a4d4x000000szpxAAA",
                                "AdjustmentType__c": "Tax",
                                "Amount__c": 12.5718,
                                "PriceListEntryId__c": "a3u4x000000cabwAAA",
                                "PriceListEntryName__c": "93b485fc-a7ce-a358-929d-e0381289b239",
                                "calculatedAmount": 12.5718,
                                "currencyCode": "USD",
                                "currencySymbol": "$"
                            }
                        ],
                        "hasAttributes": false,
                        "Name": "Multi Auto",
                        "lineRecordType": "Product",
                        "recordType": "Product",
                        "ProductCode": "autoMulti",
                        "productName": "Multi Auto",
                        "instanceKey": "Multi Auto",
                        "vlocity_ins__PricingFormula__c": "SUM(premiumBIPD + premiumCOLL + premiumCCD + premiumMED + premiumUM+premiumRental)",
                        "quoteLineItemId": "0QL4x000000lAXhGAM",
                        "vlocity_ins__NeedReprice__c": false,
                        "needReprice": false,
                        "vlocity_ins__ProductChildItemSequence__c": 0,
                        "vlocity_ins__TotalAmount__c": 2579.78,
                        "vlocity_ins__FeeAmount__c": 25,
                        "vlocity_ins__TaxAmount__c": 40.4218,
                        "vlocity_ins__ProductName__c": "Multi Auto",
                        "LastModifiedDate": "2021-02-03T16:11:01.000+0000",
                        "TotalPrice": 2514.36,
                        "vlocity_ins__Type__c": "Auto",
                        "vlocity_ins__RecordTypeName__c": "Product",
                        "UnitPrice": 2514.36,
                        "Price": 2514.36,
                        "QuoteId": "0Q04x000000l6zPCAQ",
                        "CreatedDate": "2021-02-03T16:11:01.000+0000",
                        "LineNumber": "00004344",
                        "vlocity_ins__ItemName__c": "Multi Auto",
                        "Product2Id": "01t4x000001y3bEAAQ",
                        "productId": "01t4x000001y3bEAAQ",
                        "Id": "0QL4x000000lAXhGAM",
                        "currencyCode": "USD",
                        "currencySymbol": "$",
                        "displaySequence": 0
                    }
                ],
                "totalSize": 1
            },
            "insuredItems": {
                "autoVehicle": [
                    {
                        "instanceKey": "2019 BMW M3",
                        "avRestraints": false,
                        "ProductCode": "autoVehicle",
                        "avBodyType": "Sedan/Saloon",
                        "avBrakes": false,
                        "avHistoric": false,
                        "avModel": "M3",
                        "avStabilization": true,
                        "avGaragePostalCode": "94110",
                        "isParent": true,
                        "avMake": "BMW",
                        "avValue": 45000,
                        "avMileage": 10000,
                        "avYear": "2019",
                        "avAntiTheft": false,
                        "avAltFuel": false
                    },
                    {
                        "instanceKey": "2020 Mazda CX-30",
                        "avRestraints": false,
                        "ProductCode": "autoVehicle",
                        "avBodyType": "Sedan/SUV",
                        "avBrakes": false,
                        "avHistoric": false,
                        "avModel": "CX-30",
                        "avStabilization": true,
                        "avGaragePostalCode": "94110",
                        "isParent": true,
                        "avMake": "Mazda",
                        "avValue": 26200,
                        "avMileage": 15000,
                        "avYear": "2020",
                        "avAntiTheft": true,
                        "avAltFuel": false
                    }
                ],
                "autoDriver": [
                    {
                        "instanceKey": "David Flan",
                        "adAge": 34,
                        "adBirthdate": "1986-02-14T08:00:00.000Z",
                        "adAgeLicensed": 16,
                        "adFirstName": "David",
                        "adGender": "M",
                        "adLastName": "Flan",
                        "adMiddle": "M",
                        "adMaritalStatus": "M",
                        "isParent": false
                    }
                ]
            },
            "quoteDetail": {
                "attributes": {
                    "type": "Quote",
                    "url": "/services/data/v50.0/sobjects/Quote/0Q04x000000l6zPCAQ"
                },
                "vlocity_ins__EffectiveDate__c": "2021-02-03",
                "vlocity_ins__EndDate__c": "2022-02-02",
                "vlocity_ins__Term__c": "Annual",
                "vlocity_ins__TotalSumInsured__c": 0,
                "vlocity_ins__TotalPremiumforTerm__c": 2514.36,
                "AccountId": "0014x00000DahxfAAB",
                "vlocity_ins__RootItemTotal__c": 2514.36,
                "vlocity_ins__TotalAmount__c": 2579.78,
                "vlocity_ins__TotalTaxAmount__c": 40.4218,
                "vlocity_ins__TotalFeeAmount__c": 25,
                "vlocity_ins__DaysRemaining__c": 365,
                "vlocity_ins__TotalAmountTermDifference__c": 2514.36,
                "vlocity_ins__TotalFeeTermDifference__c": 0,
                "vlocity_ins__TotalPremiumTermDifference__c": 2514.36,
                "vlocity_ins__TotalTaxTermDifference__c": 0,
                "vlocity_ins__Type__c": "New Business",
                "RecordTypeId": "0124x000001OZrNAAW",
                "vlocity_ins__RecordTypeName__c": "Quote",
                "Id": "0Q04x000000l6zPCAQ"
            },
            "errorCode": "INVOKE-200",
            "error": "OK"
        };
        return {
            statusCode: 200,
            statusMessage: 'Success',
            text: JSON.stringify(obj)
        };
    }
};

module.exports = serviceDefinition;
