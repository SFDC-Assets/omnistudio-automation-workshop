'use strict';

/**
 * @namespace CheckoutServices
 */

var server = require('server');
server.extend(module.superModule);

/**
 *  Handle Ajax payment (and billing) form submit - if not shipping address, use billinga address as placeholder
 */
/**
 * CheckoutServices-SubmitPayment : The CheckoutServices-SubmitPayment endpoint will submit the payment information and render the checkout place order page allowing the shopper to confirm and place the order
 * @name Base/CheckoutServices-SubmitPayment
 * @function
 * @memberof CheckoutServices
 * @param {middleware} - server.middleware.https
 * @param {middleware} - csrfProtection.validateAjaxRequest
 * @param {category} - sensitive
 * @param {serverfunction} - post
 */
server.append(
    'SubmitPayment',
    server.middleware.https,
    function (req, res, next) {
        
        var BasketMgr = require('dw/order/BasketMgr');
        var Transaction = require('dw/system/Transaction');
        var collections = require('*/cartridge/scripts/util/collections');

        var currentBasket = BasketMgr.getCurrentBasket();
        var billingData = res.getViewData();
        var shipments = currentBasket.shipments;
        collections.forEach(shipments, function (shipment) {
            if (!shipment.shippingAddress) {
                Transaction.wrap(function () {
                    shipment.createShippingAddress();
                    shipment.shippingAddress.setFirstName(billingData.address.firstName.value);
                    shipment.shippingAddress.setLastName(billingData.address.lastName.value);
                    shipment.shippingAddress.setAddress1(billingData.address.address1.value);
                    shipment.shippingAddress.setAddress2(billingData.address.address2.value);
                    shipment.shippingAddress.setCity(billingData.address.city.value);
                    shipment.shippingAddress.setPostalCode(billingData.address.postalCode.value);
                    if (Object.prototype.hasOwnProperty.call(billingData.address, 'stateCode')) {
                        shipment.shippingAddress.setStateCode(billingData.address.stateCode.value);
                    }
                    shipment.shippingAddress.setCountryCode(billingData.address.countryCode.value);
    
                    shipment.shippingAddress.setPhone(billingData.phone.value);
                });
            }
        });
        
        return next();
    }
);

module.exports = server.exports();