'use strict';

/**
 * This function is to handle the post payment authorization customizations
 * @param {Object} result - Authorization Result
 * @param {Object} order - Order being that is being paid for
 * @param {object} options - 
 */
function postAuthorization(result, order, options) { // eslint-disable-line no-unused-vars
    var API = require('*/cartridge/scripts/VlocityService');
    
    // Get quote IDs from order product line items
    var quoteIds = [];
    var productLineItems = order.getAllProductLineItems().iterator();
    while (productLineItems.hasNext()) {
        var productLineItem = productLineItems.next();

        if (productLineItem.custom.sfiInsQuoteId) {
            quoteIds.push(productLineItem.custom.sfiInsQuoteId);
        }
    }

    // make api call to the createMultiplePolicies integration procedure service
    var callResult = API.INSAPI.createMultiplePolicies(quoteIds);
    
    var parsedResponse = JSON.parse(callResult.object.responseObj);
    if (parsedResponse && parsedResponse.vlcIPData && parsedResponse.vlcStatus === 'InProgress') {
        // Save vlcIPData value to order so that scheduled job can attempt to complete later
        order.custom.sfiVlcIpData = parsedResponse.vlcIPData;
    }
    
    return;
}

exports.postAuthorization = postAuthorization;
